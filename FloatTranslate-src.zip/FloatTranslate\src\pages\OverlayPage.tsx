import { useEffect, useRef, useState } from 'react'
import type { CaptureImagePayload } from '../types'

type Drag = { active: boolean; x0: number; y0: number; x1: number; y1: number }

export function OverlayPage() {
  const [payload, setPayload] = useState<CaptureImagePayload | null>(null)
  const imgRef = useRef<HTMLImageElement | null>(null)
  const [drag, setDrag] = useState<Drag | null>(null)
  const dragRef = useRef<Drag | null>(null)
  dragRef.current = drag

  useEffect(() => {
    void (async () => {
      try {
        const p = (await window.ft.invoke('overlay:ready')) as CaptureImagePayload | null
        if (p?.dataUrl) {
          setPayload(p)
          setDrag(null)
        }
      } catch {
        /* ignore */
      }
    })()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') void window.ft.invoke('capture:cancel')
    }
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('keydown', onKey)
    }
  }, [])

  const onMouseDown = (e: React.MouseEvent) => {
    setDrag({ active: true, x0: e.clientX, y0: e.clientY, x1: e.clientX, y1: e.clientY })
  }

  useEffect(() => {
    if (!drag?.active) return
    const move = (e: MouseEvent) => {
      setDrag((d) => (d?.active ? { ...d, x1: e.clientX, y1: e.clientY } : d))
    }
    const up = () => void finishSelection()
    window.addEventListener('mousemove', move)
    window.addEventListener('mouseup', up)
    return () => {
      window.removeEventListener('mousemove', move)
      window.removeEventListener('mouseup', up)
    }
  }, [drag?.active])

  async function finishSelection() {
    const d = dragRef.current
    const img = imgRef.current
    const p = payload
    if (!d?.active || !img || !p) return
    setDrag({ ...d, active: false })
    const ir = img.getBoundingClientRect()
    const rx = Math.min(d.x0, d.x1)
    const ry = Math.min(d.y0, d.y1)
    const rw = Math.abs(d.x1 - d.x0)
    const rh = Math.abs(d.y1 - d.y0)
    if (rw < 4 || rh < 4) {
      void window.ft.invoke('capture:cancel')
      return
    }
    try {
      await window.ft.invoke('capture:complete', {
        imgLeft: ir.left,
        imgTop: ir.top,
        imgW: ir.width,
        imgH: ir.height,
        rx,
        ry,
        rw,
        rh
      })
    } catch (e) {
      console.error('[overlay] capture:complete', e)
      void window.ft.invoke('capture:cancel')
    }
  }

  const box =
    drag && payload
      ? {
          left: Math.min(drag.x0, drag.x1),
          top: Math.min(drag.y0, drag.y1),
          width: Math.abs(drag.x1 - drag.x0),
          height: Math.abs(drag.y1 - drag.y0)
        }
      : null

  if (!payload) {
    return (
      <div style={{ width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.55)', color: '#fff' }}>
        <div style={{ padding: 16 }}>准备截图…</div>
      </div>
    )
  }

  return (
    <div
      style={{ width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.35)', cursor: 'crosshair' }}
      onMouseDown={onMouseDown}
    >
      <div style={{ width: '100%', height: '100%', display: 'grid', placeItems: 'center' }}>
        <img
          ref={imgRef}
          alt="capture"
          src={payload.dataUrl}
          draggable={false}
          style={{ maxWidth: '100vw', maxHeight: '100vh', width: 'auto', height: 'auto', objectFit: 'contain' }}
        />
      </div>
      {box ? (
        <div
          style={{
            position: 'fixed',
            left: box.left,
            top: box.top,
            width: box.width,
            height: box.height,
            border: '2px solid #38bdf8',
            boxShadow: '0 0 0 9999px rgba(0,0,0,0.35)',
            pointerEvents: 'none'
          }}
        />
      ) : null}
      <div
        style={{
          position: 'fixed',
          left: 12,
          bottom: 12,
          color: '#e5e7eb',
          fontSize: 12,
          background: 'rgba(0,0,0,0.55)',
          padding: '8px 10px',
          borderRadius: 8,
          pointerEvents: 'none'
        }}
      >
        拖拽框选区域 · Esc 取消
      </div>
    </div>
  )
}
