export type CaptureImagePayload = {
  dataUrl: string
  capW: number
  capH: number
}

export type ResultPayload = {
  sourceText: string
  translatedText: string
  error?: string
}
