import { useEffect, useRef, useState } from 'react'

type Form = {
  fromLang: string
  toLang: string
  baiduAppId: string
  baiduSecret: string
  hotkey: string
  floatOpacity: number
  resultAutoHideSec: number
  loginOpenAtBoot: boolean
  ocrEngine: 'local' | 'online'
}

type SaveState = 'idle' | 'saving' | 'saved' | 'error'

export function SettingsPage() {
  const [form, setForm] = useState<Form | null>(null)
  const [usage, setUsage] = useState<{ used: number; limit: number } | null>(null)
  const [loadErr, setLoadErr] = useState<string | null>(null)
  const [saveState, setSaveState] = useState<SaveState>('idle')
  const [saveErr, setSaveErr] = useState<string | null>(null)
  const savedTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    void (async () => {
      try {
        const s = (await window.ft.invoke('settings:get')) as Form
        const u = (await window.ft.invoke('usage:get')) as { used: number; limit: number }
        setForm(s)
        setUsage(u)
        setLoadErr(null)
      } catch (e) {
        setLoadErr(e instanceof Error ? e.message : String(e))
      }
    })()
  }, [])

  useEffect(() => {
    return () => {
      if (savedTimerRef.current) clearTimeout(savedTimerRef.current)
    }
  }, [])

  async function onSave() {
    if (!form) return
    setSaveState('saving')
    setSaveErr(null)
    if (savedTimerRef.current) clearTimeout(savedTimerRef.current)
    try {
      await window.ft.invoke('settings:set', form)
      const u = (await window.ft.invoke('usage:get')) as { used: number; limit: number }
      setUsage(u)
      setSaveState('saved')
      savedTimerRef.current = setTimeout(() => {
        setSaveState('idle')
        savedTimerRef.current = null
      }, 2600)
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e)
      setSaveErr(msg)
      setSaveState('error')
      savedTimerRef.current = setTimeout(() => {
        setSaveState('idle')
        setSaveErr(null)
        savedTimerRef.current = null
      }, 4000)
    }
  }

  if (loadErr) {
    return (
      <div className="settings-root" style={{ padding: 24 }}>
        <div
          style={{
            maxWidth: 420,
            margin: '0 auto',
            padding: 20,
            borderRadius: 14,
            background: '#fef2f2',
            border: '1px solid #fecaca',
            color: '#991b1b'
          }}
        >
          <p style={{ marginTop: 0, fontWeight: 600 }}>设置加载失败</p>
          <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12, margin: 0, opacity: 0.95 }}>{loadErr}</pre>
        </div>
      </div>
    )
  }

  if (!form) {
    return (
      <div className="settings-root settings-loading">
        <span className="settings-spinner" aria-hidden />
        正在加载设置…
      </div>
    )
  }

  const showToast = saveState === 'saved' || saveState === 'error'
  const toastTone = saveState === 'error' ? 'settings-toast--error' : 'settings-toast--success'
  const toastClass = `settings-toast ${showToast ? `settings-toast--visible ${toastTone}` : ''}`

  return (
    <div className="settings-root">
      <div className={toastClass} role="status" aria-live="polite">
        {saveState === 'saved' ? '✓ 已保存，设置已生效' : null}
        {saveState === 'error' ? `保存失败：${saveErr ?? '未知错误'}` : null}
      </div>

      <div className="settings-card">
        <header className="settings-hero">
          <h1>设置</h1>
          <p>翻译接口、快捷键与外观。修改后请点击底部保存。</p>
        </header>

        {usage ? (
          <div className="settings-usage" style={{ marginTop: 4 }}>
            <span>翻译 API 成功调用次数</span>
            <strong>
              {usage.used} / {usage.limit}
            </strong>
          </div>
        ) : null}

        <section className="settings-section">
          <div className="settings-section-title">翻译</div>
          <div className="settings-field">
            <label className="settings-label" htmlFor="fromLang">
              源语言（from）
            </label>
            <input
              id="fromLang"
              className="settings-input"
              value={form.fromLang}
              onChange={(e) => setForm({ ...form, fromLang: e.target.value })}
            />
          </div>
          <div className="settings-field">
            <label className="settings-label" htmlFor="toLang">
              目标语言（to）
            </label>
            <input
              id="toLang"
              className="settings-input"
              value={form.toLang}
              onChange={(e) => setForm({ ...form, toLang: e.target.value })}
            />
          </div>
          <div className="settings-field">
            <label className="settings-label" htmlFor="baiduAppId">
              百度翻译 AppId
            </label>
            <input
              id="baiduAppId"
              className="settings-input"
              value={form.baiduAppId}
              onChange={(e) => setForm({ ...form, baiduAppId: e.target.value })}
              autoComplete="off"
            />
          </div>
          <div className="settings-field">
            <label className="settings-label" htmlFor="baiduSecret">
              百度翻译密钥（Secret）
            </label>
            <input
              id="baiduSecret"
              className="settings-input"
              type="password"
              value={form.baiduSecret}
              onChange={(e) => setForm({ ...form, baiduSecret: e.target.value })}
              autoComplete="off"
            />
          </div>
        </section>

        <section className="settings-section">
          <div className="settings-section-title">行为</div>
          <div className="settings-field">
            <label className="settings-label" htmlFor="hotkey">
              全局快捷键（Electron accelerator）
            </label>
            <input
              id="hotkey"
              className="settings-input"
              value={form.hotkey}
              onChange={(e) => setForm({ ...form, hotkey: e.target.value })}
            />
          </div>
          <div className="settings-field">
            <label className="settings-label" htmlFor="resultAutoHideSec">
              结果窗自动隐藏（秒，0 为不隐藏）
            </label>
            <input
              id="resultAutoHideSec"
              className="settings-input"
              type="number"
              min={0}
              max={600}
              value={form.resultAutoHideSec}
              onChange={(e) => setForm({ ...form, resultAutoHideSec: Number(e.target.value) })}
            />
          </div>
          <div className="settings-field">
            <label className="settings-label" htmlFor="ocrEngine">
              OCR 引擎
            </label>
            <select
              id="ocrEngine"
              className="settings-select"
              value={form.ocrEngine}
              onChange={(e) => setForm({ ...form, ocrEngine: e.target.value as Form['ocrEngine'] })}
            >
              <option value="local">本地 Tesseract</option>
              <option value="online">在线（未接入）</option>
            </select>
          </div>
          <label className="settings-checkbox-row">
            <input
              type="checkbox"
              checked={form.loginOpenAtBoot}
              onChange={(e) => setForm({ ...form, loginOpenAtBoot: e.target.checked })}
            />
            <span style={{ fontSize: 14, color: '#334155' }}>开机自启动</span>
          </label>
        </section>

        <section className="settings-section">
          <div className="settings-section-title">外观</div>
          <div className="settings-field">
            <label className="settings-label" htmlFor="floatOpacity">
              浮标透明度（0.2 ~ 1）
            </label>
            <input
              id="floatOpacity"
              className="settings-input"
              type="number"
              step={0.05}
              min={0.2}
              max={1}
              value={form.floatOpacity}
              onChange={(e) => setForm({ ...form, floatOpacity: Number(e.target.value) })}
            />
          </div>
        </section>

        <div className="settings-save-wrap">
          <button
            type="button"
            disabled={saveState === 'saving'}
            className={
              'settings-save ' +
              (saveState === 'saved' ? 'settings-save--saved' : 'settings-save--primary')
            }
            onClick={() => void onSave()}
          >
            {saveState === 'saving' ? (
              <>
                <span className="settings-spinner" style={{ width: 16, height: 16, borderWidth: 2 }} />
                正在保存…
              </>
            ) : saveState === 'saved' ? (
              <>✓ 已保存</>
            ) : (
              <>保存设置</>
            )}
          </button>
        </div>

        <p className="settings-footnote">
          密钥仅保存在本机用户目录（electron-store）。请勿将真实密钥提交到 Git；若曾在聊天中泄露，请在百度控制台尽快轮换密钥。
        </p>
      </div>
    </div>
  )
}
