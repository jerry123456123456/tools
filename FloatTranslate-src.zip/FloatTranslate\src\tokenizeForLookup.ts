/** 将文本拆成可点击片段：英文整词、日文等 CJK 单字、连续数字 */
export type LookupTok = { kind: 'text' | 'word'; text: string }

export function tokenizeForLookup(input: string): LookupTok[] {
  if (!input) return [{ kind: 'text', text: '' }]
  const out: LookupTok[] = []
  const re = /([A-Za-z]+(?:'[A-Za-z]+)?|[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]|[0-9]+)/g
  let last = 0
  let m: RegExpExecArray | null
  while ((m = re.exec(input)) !== null) {
    if (m.index > last) out.push({ kind: 'text', text: input.slice(last, m.index) })
    out.push({ kind: 'word', text: m[0] })
    last = m.index + m[0].length
  }
  if (last < input.length) out.push({ kind: 'text', text: input.slice(last) })
  return out.length ? out : [{ kind: 'text', text: input }]
}
