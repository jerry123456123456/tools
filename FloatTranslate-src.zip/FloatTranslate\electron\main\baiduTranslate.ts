import crypto from 'node:crypto'

const ENDPOINT = 'https://fanyi-api.baidu.com/api/trans/vip/translate'

export type BaiduTranslateResult =
  | { ok: true; translatedText: string }
  | { ok: false; error: string }

function md5(s: string): string {
  return crypto.createHash('md5').update(s, 'utf8').digest('hex')
}

export async function baiduTranslate(params: {
  q: string
  from: string
  to: string
  appid: string
  secret: string
}): Promise<BaiduTranslateResult> {
  const { q, from, to, appid, secret } = params
  if (!appid || !secret) {
    return { ok: false, error: '未配置百度翻译 AppId 或密钥，请在设置中填写。' }
  }
  const salt = Date.now()
  const sign = md5(`${appid}${q}${salt}${secret}`)
  const body = new URLSearchParams({
    q,
    from,
    to,
    appid,
    salt: String(salt),
    sign
  })
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  })
  const json = (await res.json()) as Record<string, unknown>
  if (!res.ok) {
    return { ok: false, error: `网络错误：HTTP ${res.status}` }
  }
  if (json.error_code) {
    return { ok: false, error: `百度 API 错误：${String(json.error_code)} ${String(json.error_msg ?? '')}` }
  }
  const result = json.trans_result as Array<{ dst: string }> | undefined
  if (!result?.length) {
    return { ok: false, error: '百度 API 返回空结果。' }
  }
  const translatedText = result.map((r) => r.dst).join('\n')
  return { ok: true, translatedText }
}
