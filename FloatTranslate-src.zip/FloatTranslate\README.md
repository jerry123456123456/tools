# FloatTranslate（浮标翻译）原型

跨平台桌面翻译工具原型：常驻浮标、区域截图、本地 OCR（Tesseract）、百度通用翻译 API、结果窗与设置。完整设计见 `docs/SDD.md`。

## 安全提示（必读）

- **不要把真实 API 密钥写进仓库或发给他人。** 你曾在对话里粘贴过密钥，建议在百度翻译控制台**立即轮换**密钥。
- 本原型将密钥保存在本机用户目录（`electron-store`），可通过**设置页**或环境变量注入（见 `.env.example`）。

## 给他人安装（压缩包 + 命令）

适合：**对方愿意装 Node.js**，用源码方式跑（与开发环境相同）。

### 你在本机打包压缩包

1. 在项目根目录**不要**打进压缩包（体积大且无必要）：`node_modules`、`out`、`release`、`.git`（若不需要历史）。
2. **必须**包含：`package.json`、`package-lock.json`（若有）、`electron/`、`src/`、`index.html`、`electron.vite.config.ts`、`tsconfig.json`、`tsconfig.node.json`、`resources/tray.png`、`docs/`（可选）、`.env.example`（不要带真实密钥）。

在资源管理器中全选上述内容 → 右键「压缩为 zip」即可；或用 PowerShell（在项目**上一级**目录执行，把路径改成你的实际路径）：

```powershell
Compress-Archive -Path "c:\Users\jerry\Desktop\trans\*" -DestinationPath "c:\Users\jerry\Desktop\FloatTranslate-src.zip" -Force
```

若已存在 `node_modules`，建议仍用资源管理器**手动勾选**要打包的文件夹，避免把 `node_modules` 打进去。

### 对方电脑上（需已安装 [Node.js](https://nodejs.org/) LTS，并勾选 npm）

解压 zip 到任意目录，例如 `D:\FloatTranslate`，在该文件夹里打开 **PowerShell** 或 **cmd**，执行：

```powershell
cd D:\FloatTranslate
npm install
npm run dev
```

首次 `npm install` 会下载依赖，需联网；启动后按 README 配置百度翻译即可。

---

### 不想让对方装 Node：发安装包

你在本机执行 `npm run pack:win`，把生成的 **`release` 文件夹里的 `.exe` 安装程序**（或整个 `release` 里对方需要的那份）发给对方安装即可，**无需** Node 与上述压缩包命令。

## 开发运行

```bash
cd c:\Users\jerry\Desktop\trans
npm install
npm run dev
```

首次 OCR 会下载 Tesseract 语言包，可能较慢。

## 配置百度翻译

1. 启动应用后打开浮标菜单 → **设置**。
2. 填写 **AppId** 与 **密钥（Secret）**（用于签名 `sign = MD5(appid + q + salt + secret)`）。
3. 也可在启动前设置环境变量（仅本机）：

```powershell
$env:BAIDU_APP_ID="你的AppId"
$env:BAIDU_SECRET="你的Secret"
npm run dev
```

## 用量熔断

主进程会累计**成功**的翻译 API 调用次数；达到 **900000** 后拒绝继续翻译并在 UI 提示（见 `electron/main/index.ts` 的 `QUOTA_LIMIT`）。

## 打包 Windows exe

```bash
npm run pack:win
```

产物在 `release/`。如需自定义安装图标，可在 `package.json` 的 `build.win` 增加 `icon` 字段指向 `.ico`。

### 打包时无法下载 Electron（连接 GitHub 超时）

在国内或受限网络下，`electron-builder` 会从 GitHub 拉取 `electron-v*.zip`，容易出现 `connectex ... failed`。

**做法一（推荐）：** 使用已配置国内镜像的脚本（需先 `npm install` 以安装 `cross-env`）：

```powershell
npm install
npm run pack:win:cn
```

**做法二：** 在当前 PowerShell 会话里设置环境变量后再打包：

```powershell
$env:ELECTRON_MIRROR="https://cdn.npmmirror.com/binaries/electron/"
$env:ELECTRON_BUILDER_BINARIES_MIRROR="https://cdn.npmmirror.com/binaries/electron-builder-binaries/"
npm run pack:win
```

若仍失败，可换手机热点、代理或 VPN 后再试。

## 快捷键

默认：`Ctrl+Shift+T`（Electron accelerator：`CommandOrControl+Shift+T`）。可在设置页修改。

## 已知限制（原型）

- 截图翻译当前以**主显示器**截图为基准；多显示器与部分全屏游戏场景见 `docs/SDD.md`。
- 「在线 OCR」为占位，实际仍使用本地 Tesseract。
- 单词卡片中的音标/例句为占位说明；释义走翻译 API。

## 托盘图标

仓库内需存在 `resources/tray.png`（开发/打包脚本会复制到安装目录）。若托盘显示空白，请确认该文件未被删除。

## 项目结构

- `electron/main/`：主进程（截图、OCR、翻译、配额、窗口）
- `electron/preload/`：`contextBridge` IPC
- `src/pages/`：浮标 / 遮罩选区 / 结果 / 设置
