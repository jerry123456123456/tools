import { existsSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  app,
  BrowserWindow,
  clipboard,
  dialog,
  globalShortcut,
  ipcMain,
  nativeImage,
  screen,
  Tray,
  Menu
} from 'electron'
import Store from 'electron-store'
import screenshot from 'screenshot-desktop'
import Tesseract from 'tesseract.js'
import { baiduTranslate } from './baiduTranslate'

const __dirname = dirname(fileURLToPath(import.meta.url))

export const QUOTA_LIMIT = 900_000

type AppStore = {
  fromLang: string
  toLang: string
  baiduAppId: string
  baiduSecret: string
  hotkey: string
  floatOpacity: number
  floatBounds: { x: number; y: number } | null
  resultAutoHideSec: number
  translateApiCalls: number
  loginOpenAtBoot: boolean
  ocrEngine: 'local' | 'online'
}

const store = new Store<AppStore>({
  defaults: {
    fromLang: 'auto',
    toLang: 'zh',
    baiduAppId: '',
    baiduSecret: '',
    hotkey: 'CommandOrControl+Shift+T',
    floatOpacity: 0.92,
    floatBounds: null,
    resultAutoHideSec: 0,
    translateApiCalls: 0,
    loginOpenAtBoot: false,
    ocrEngine: 'local'
  }
})

let floatWin: BrowserWindow | null = null
let overlayWin: BrowserWindow | null = null
let resultWin: BrowserWindow | null = null
let settingsWin: BrowserWindow | null = null
let tray: Tray | null = null

let pendingCapture: { ni: Electron.NativeImage; capW: number; capH: number } | null = null

let pendingOverlayPayload: { dataUrl: string; capW: number; capH: number } | null = null

let lastResultSnapshot: { sourceText: string; translatedText: string; error?: string } | null = null

let floatDrag: { sx: number; sy: number; wx: number; wy: number } | null = null

function clampFloatToVisible(win: BrowserWindow): void {
  const b = win.getBounds()
  const pt = { x: b.x + Math.floor(b.width / 2), y: b.y + Math.floor(b.height / 2) }
  const wa = screen.getDisplayNearestPoint(pt).workArea
  const nx = Math.max(wa.x, Math.min(b.x, wa.x + wa.width - b.width))
  const ny = Math.max(wa.y, Math.min(b.y, wa.y + wa.height - b.height))
  if (nx !== b.x || ny !== b.y) win.setPosition(Math.round(nx), Math.round(ny))
}

function placeFloatDefault(win: BrowserWindow): void {
  const b = win.getBounds()
  const { workArea } = screen.getPrimaryDisplay()
  const x = workArea.x + workArea.width - b.width - 16
  const y = workArea.y + workArea.height - b.height - 16
  win.setPosition(Math.floor(x), Math.floor(y))
  clampFloatToVisible(win)
}

function devRendererUrl(): string | undefined {
  return process.env['ELECTRON_RENDERER_URL']
}

function loadRoute(win: BrowserWindow, route: string): void {
  const url = devRendererUrl()
  if (url) {
    void win.loadURL(`${url}#${route}`)
  } else {
    void win.loadFile(join(__dirname, '../renderer/index.html'), { hash: route.replace(/^#/, '') })
  }
}

function preloadPath(): string {
  const mjs = join(__dirname, '../preload/index.mjs')
  if (existsSync(mjs)) return mjs
  return join(__dirname, '../preload/index.js')
}

function trayIcon(): Electron.NativeImage {
  const candidates = [
    join(__dirname, '../../resources/tray.png'),
    join(process.cwd(), 'resources', 'tray.png'),
    join(process.resourcesPath, 'tray.png')
  ]
  for (const p of candidates) {
    if (existsSync(p)) return nativeImage.createFromPath(p)
  }
  throw new Error('FloatTranslate: resources/tray.png not found (expected at project resources/tray.png).')
}

function createFloatWindow(): BrowserWindow {
  const w = new BrowserWindow({
    width: 72,
    height: 88,
    show: true,
    frame: false,
    transparent: true,
    resizable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    hasShadow: false,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: preloadPath(),
      contextIsolation: true,
      sandbox: false
    }
  })
  loadRoute(w, '/float')
  const saved = store.get('floatBounds')
  if (saved) w.setPosition(Math.round(saved.x), Math.round(saved.y))
  else placeFloatDefault(w)
  clampFloatToVisible(w)
  w.setOpacity(store.get('floatOpacity'))
  w.on('moved', () => {
    const [x, y] = w.getPosition()
    store.set('floatBounds', { x: Math.round(x), y: Math.round(y) })
  })
  return w
}

function ensureResultWindow(): BrowserWindow {
  if (resultWin && !resultWin.isDestroyed()) return resultWin
  const w = new BrowserWindow({
    width: 420,
    height: 320,
    show: false,
    frame: false,
    transparent: false,
    backgroundColor: '#0b1220',
    resizable: true,
    alwaysOnTop: true,
    webPreferences: {
      preload: preloadPath(),
      contextIsolation: true,
      sandbox: false
    }
  })
  loadRoute(w, '/result')
  w.on('closed', () => {
    resultWin = null
  })
  resultWin = w
  return w
}

function openSettings(): void {
  if (settingsWin && !settingsWin.isDestroyed()) {
    settingsWin.show()
    settingsWin.focus()
    return
  }
  const w = new BrowserWindow({
    width: 520,
    height: 640,
    show: true,
    title: 'FloatTranslate 设置',
    backgroundColor: '#ffffff',
    autoHideMenuBar: true,
    webPreferences: {
      preload: preloadPath(),
      contextIsolation: true,
      sandbox: false
    }
  })
  loadRoute(w, '/settings')
  settingsWin = w
  w.on('closed', () => {
    settingsWin = null
    registerHotkey()
  })
}

function closeOverlay(): void {
  pendingOverlayPayload = null
  if (overlayWin && !overlayWin.isDestroyed()) overlayWin.close()
  overlayWin = null
}

function showOverlay(dataUrl: string, capW: number, capH: number): void {
  closeOverlay()
  pendingOverlayPayload = { dataUrl, capW, capH }
  const d = screen.getPrimaryDisplay()
  const { x, y, width, height } = d.bounds
  overlayWin = new BrowserWindow({
    x: Math.round(x),
    y: Math.round(y),
    width: Math.round(width),
    height: Math.round(height),
    show: false,
    frame: false,
    transparent: false,
    backgroundColor: '#0f172a',
    fullscreen: false,
    resizable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    hasShadow: false,
    webPreferences: {
      preload: preloadPath(),
      contextIsolation: true,
      sandbox: false
    }
  })
  loadRoute(overlayWin, '/overlay')
  overlayWin.setIgnoreMouseEvents(false)
  overlayWin.on('closed', () => {
    overlayWin = null
  })
  overlayWin.once('ready-to-show', () => {
    overlayWin?.show()
    overlayWin?.focus()
    overlayWin?.moveTop()
  })
}

async function runTranslate(sourceText: string): Promise<{ translatedText: string; error?: string }> {
  const used = store.get('translateApiCalls')
  if (used >= QUOTA_LIMIT) {
    return {
      translatedText: '',
      error: `已达到本机翻译 API 调用上限（${QUOTA_LIMIT}），已停止服务。`
    }
  }
  const appid = store.get('baiduAppId')
  const secret = store.get('baiduSecret')
  const from = store.get('fromLang')
  const to = store.get('toLang')
  const r = await baiduTranslate({ q: sourceText, from, to, appid, secret })
  if (!r.ok) return { translatedText: '', error: r.error }
  store.set('translateApiCalls', used + 1)
  return { translatedText: r.translatedText }
}

async function runOcr(png: Buffer): Promise<string> {
  if (store.get('ocrEngine') === 'online') {
    throw new Error('在线 OCR 尚未接入，请在设置中选择「本地 Tesseract」。')
  }
  const r = await Tesseract.recognize(png, 'eng+chi_sim', { logger: () => undefined })
  return String(r.data.text ?? '').trim()
}

async function runOcrWithTimeout(png: Buffer, timeoutMs: number): Promise<string> {
  let timer: ReturnType<typeof setTimeout> | undefined
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(
      () =>
        reject(
          new Error(
            `OCR 超过 ${Math.round(timeoutMs / 1000)} 秒未完成。可尝试缩小选区、检查网络（首次会下载语言包）或重启应用。`
          )
        ),
      timeoutMs
    )
  })
  try {
    return await Promise.race([runOcr(png), timeout])
  } finally {
    if (timer) clearTimeout(timer)
  }
}

function pushResult(payload: { sourceText: string; translatedText: string; error?: string }): void {
  lastResultSnapshot = { ...payload }
  const w = ensureResultWindow()
  const flush = (): void => {
    if (w.isDestroyed()) return
    w.webContents.send('result:show', payload)
  }
  w.show()
  w.focus()
  if (w.webContents.isLoading()) {
    w.webContents.once('did-finish-load', () => setTimeout(flush, 100))
  } else {
    setTimeout(flush, 100)
  }
  setTimeout(() => {
    if (!w.isDestroyed()) {
      w.moveTop()
      w.focus()
    }
  }, 220)
}

function registerHotkey(): void {
  globalShortcut.unregisterAll()
  const hk = store.get('hotkey')
  if (!hk) return
  const ok = globalShortcut.register(hk, () => {
    void Promise.resolve(startCaptureFlow()).catch((e) => trayErr('截图翻译失败', e))
  })
  if (!ok) console.warn('[FloatTranslate] 全局快捷键注册失败:', hk)
}

async function startCaptureFlow(): Promise<void> {
  pendingCapture = null
  floatWin?.hide()
  resultWin?.hide()
  await new Promise((r) => setTimeout(r, 180))
  let buf: Buffer
  try {
    buf = await screenshot({ format: 'png' })
  } catch (e) {
    floatWin?.show()
    pushResult({
      sourceText: '',
      translatedText: '',
      error: `截图失败：${e instanceof Error ? e.message : String(e)}`
    })
    return
  }
  const ni = nativeImage.createFromBuffer(buf)
  const { width: capW, height: capH } = ni.getSize()
  pendingCapture = { ni, capW, capH }
  const dataUrl = ni.toDataURL()
  showOverlay(dataUrl, capW, capH)
}

ipcMain.handle('capture:start', async () => {
  await startCaptureFlow()
  return true
})

ipcMain.handle('capture:cancel', async () => {
  closeOverlay()
  pendingCapture = null
  floatWin?.show()
  return true
})

ipcMain.handle(
  'capture:complete',
  async (
    _e,
    box: { imgLeft: number; imgTop: number; imgW: number; imgH: number; rx: number; ry: number; rw: number; rh: number }
  ) => {
    const snap = pendingCapture
    if (!snap) {
      closeOverlay()
      floatWin?.show()
      return { ok: false as const, error: '无可用截图' }
    }
    pendingCapture = null
    const { ni, capW, capH } = snap
    const imgW = Number(box.imgW)
    const imgH = Number(box.imgH)
    if (!Number.isFinite(imgW) || !Number.isFinite(imgH) || imgW < 1 || imgH < 1) {
      closeOverlay()
      floatWin?.show()
      pushResult({
        sourceText: '',
        translatedText: '',
        error: '选区坐标无效（请重试截图翻译）。'
      })
      return { ok: false as const, error: 'bad image rect' }
    }
    const ix = Math.floor(((box.rx - box.imgLeft) / imgW) * capW)
    const iy = Math.floor(((box.ry - box.imgTop) / imgH) * capH)
    const iw = Math.max(2, Math.ceil((box.rw / imgW) * capW))
    const ih = Math.max(2, Math.ceil((box.rh / imgH) * capH))
    const x = Math.max(0, Math.min(capW - 2, ix))
    const y = Math.max(0, Math.min(capH - 2, iy))
    const width = Math.min(capW - x, iw)
    const height = Math.min(capH - y, ih)
    if (width < 2 || height < 2) {
      closeOverlay()
      pushResult({
        sourceText: '',
        translatedText: '',
        error: '选区过小，请拖大一点再试。'
      })
      floatWin?.show()
      return { ok: false as const, error: 'crop too small' }
    }
    closeOverlay()
    try {
      pushResult({
        sourceText: '（正在 OCR，首次可能需下载语言包，请稍候…）',
        translatedText: ''
      })
      const cropped = ni.crop({ x, y, width, height })
      const png = cropped.toPNG()
      const sourceText = await runOcrWithTimeout(png, 120_000)
      if (!sourceText) {
        pushResult({ sourceText: '', translatedText: '', error: '未识别到文字，请扩大选区或检查语言。' })
        return { ok: true as const }
      }
      const tr = await runTranslate(sourceText)
      pushResult({
        sourceText,
        translatedText: tr.translatedText,
        error: tr.error
      })
      return { ok: true as const }
    } catch (e) {
      pushResult({
        sourceText: '',
        translatedText: '',
        error: e instanceof Error ? e.message : String(e)
      })
      return { ok: false as const, error: String(e) }
    } finally {
      floatWin?.show()
    }
  }
)

ipcMain.handle('settings:get', async () => ({
  fromLang: store.get('fromLang'),
  toLang: store.get('toLang'),
  baiduAppId: store.get('baiduAppId'),
  baiduSecret: store.get('baiduSecret'),
  hotkey: store.get('hotkey'),
  floatOpacity: store.get('floatOpacity'),
  resultAutoHideSec: store.get('resultAutoHideSec'),
  loginOpenAtBoot: store.get('loginOpenAtBoot'),
  ocrEngine: store.get('ocrEngine')
}))

ipcMain.handle('result:get-snapshot', async () => lastResultSnapshot)

ipcMain.handle('settings:set', async (_e, patch: Partial<AppStore>) => {
  for (const key of Object.keys(patch) as Array<keyof AppStore>) {
    const v = patch[key]
    if (v !== undefined) store.set(key, v as never)
  }
  app.setLoginItemSettings({ openAtLogin: Boolean(store.get('loginOpenAtBoot')) })
  floatWin?.setOpacity(store.get('floatOpacity'))
  registerHotkey()
  return true
})

ipcMain.handle('usage:get', async () => ({
  used: store.get('translateApiCalls'),
  limit: QUOTA_LIMIT
}))

ipcMain.handle('translate:clipboard', async () => {
  const t = clipboard.readText().trim()
  if (!t) {
    pushResult({ sourceText: '', translatedText: '', error: '剪贴板为空。' })
    return false
  }
  const tr = await runTranslate(t)
  pushResult({ sourceText: t, translatedText: tr.translatedText, error: tr.error })
  return true
})

ipcMain.handle('translate:word', async (_e, word: unknown) => {
  const w = typeof word === 'string' ? word.trim() : String(word ?? '').trim()
  if (!w) return { ok: false as const, error: '空词' }
  const tr = await runTranslate(w)
  if (tr.error) return { ok: false as const, error: tr.error }
  return { ok: true as const, translatedText: tr.translatedText }
})

ipcMain.handle('app:quit', async () => {
  app.quit()
  return true
})

ipcMain.handle('settings:open', async () => {
  openSettings()
  return true
})

ipcMain.handle('result:close', async () => {
  resultWin?.hide()
  return true
})

ipcMain.handle('float:set-bounds', async (_e, payload: { width: number; height: number }) => {
  if (!floatWin || floatWin.isDestroyed()) return false
  const cur = floatWin.getBounds()
  const width = Math.max(1, Math.round(Number(payload.width)))
  const height = Math.max(1, Math.round(Number(payload.height)))
  floatWin.setBounds({
    x: Math.round(cur.x),
    y: Math.round(cur.y),
    width,
    height
  })
  clampFloatToVisible(floatWin)
  return true
})

ipcMain.handle('float:reset-position', async () => {
  store.delete('floatBounds')
  if (!floatWin || floatWin.isDestroyed()) return false
  placeFloatDefault(floatWin)
  return true
})

ipcMain.handle('float:drag-start', async (_e, p: { sx?: number; sy?: number }) => {
  if (!floatWin || floatWin.isDestroyed()) return
  const sx = Math.round(Number(p?.sx))
  const sy = Math.round(Number(p?.sy))
  if (!Number.isFinite(sx) || !Number.isFinite(sy)) return
  const [wx, wy] = floatWin.getPosition()
  floatDrag = { sx, sy, wx: Math.round(wx), wy: Math.round(wy) }
})

ipcMain.handle('float:drag-move', async (_e, p: { sx?: number; sy?: number }) => {
  if (!floatWin || floatWin.isDestroyed() || !floatDrag) return
  const sx = Math.round(Number(p?.sx))
  const sy = Math.round(Number(p?.sy))
  if (!Number.isFinite(sx) || !Number.isFinite(sy)) return
  const nx = Math.round(floatDrag.wx + sx - floatDrag.sx)
  const ny = Math.round(floatDrag.wy + sy - floatDrag.sy)
  if (!Number.isFinite(nx) || !Number.isFinite(ny)) return
  floatWin.setPosition(nx, ny)
})

ipcMain.handle('float:drag-end', async () => {
  floatDrag = null
  if (floatWin && !floatWin.isDestroyed()) {
    clampFloatToVisible(floatWin)
    const [x, y] = floatWin.getPosition()
    store.set('floatBounds', { x: Math.round(x), y: Math.round(y) })
  }
})

ipcMain.handle('overlay:ready', async () => {
  const p = pendingOverlayPayload
  return p
})

function mergeEnvIntoStore(): void {
  const aid = process.env.BAIDU_APP_ID
  const sec = process.env.BAIDU_SECRET
  if (!store.get('baiduAppId') && aid) store.set('baiduAppId', aid)
  if (!store.get('baiduSecret') && sec) store.set('baiduSecret', sec)
}

function trayErr(title: string, err: unknown): void {
  dialog.showErrorBox(title, err instanceof Error ? err.message : String(err))
}

function createTray(): void {
  tray = new Tray(trayIcon())
  tray.setToolTip('FloatTranslate')
  tray.setContextMenu(
    Menu.buildFromTemplate([
      {
        label: '显示浮标',
        click: () => {
          if (!floatWin || floatWin.isDestroyed()) return
          floatWin.show()
          clampFloatToVisible(floatWin)
          floatWin.focus()
        }
      },
      {
        label: '重置浮标位置',
        click: () => {
          store.delete('floatBounds')
          if (floatWin && !floatWin.isDestroyed()) placeFloatDefault(floatWin)
        }
      },
      {
        label: '截图翻译',
        click: () => {
          void Promise.resolve(startCaptureFlow()).catch((e) => trayErr('截图翻译失败', e))
        }
      },
      { type: 'separator' },
      { label: '退出', click: () => app.quit() }
    ])
  )
}

app.whenReady().then(() => {
  if (process.platform === 'win32' || process.platform === 'linux') {
    Menu.setApplicationMenu(null)
  }
  mergeEnvIntoStore()
  floatWin = createFloatWindow()
  createTray()
  registerHotkey()
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) floatWin = createFloatWindow()
  })
})

app.on('will-quit', () => {
  globalShortcut.unregisterAll()
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})
