import { useEffect, useMemo, useState } from 'react'
import type { ResultPayload } from '../types'
import { tokenizeForLookup, type LookupTok } from '../tokenizeForLookup'

export function ResultPage() {
  const [data, setData] = useState<ResultPayload | null>(null)
  const [wordTip, setWordTip] = useState<{ word: string; text: string; error?: string } | null>(null)
  const [wordBusy, setWordBusy] = useState(false)

  useEffect(() => {
    void (async () => {
      try {
        const snap = (await window.ft.invoke('result:get-snapshot')) as ResultPayload | null
        if (snap && (snap.sourceText || snap.translatedText || snap.error)) {
          setData(snap)
        }
      } catch {
        /* ignore */
      }
    })()
    return window.ft.on('result:show', (p) => {
      setData(p as ResultPayload)
      setWordTip(null)
    })
  }, [])

  useEffect(() => {
    if (!data) return
    let t: ReturnType<typeof setTimeout> | undefined
    void (async () => {
      const s = (await window.ft.invoke('settings:get')) as { resultAutoHideSec?: number }
      const sec = Number(s.resultAutoHideSec ?? 0)
      if (sec > 0) t = setTimeout(() => void window.ft.invoke('result:close'), sec * 1000)
    })()
    return () => {
      if (t) clearTimeout(t)
    }
  }, [data])

  const sourceToks = useMemo(() => tokenizeForLookup(data?.sourceText ?? ''), [data?.sourceText])
  const targetToks = useMemo(() => tokenizeForLookup(data?.translatedText ?? ''), [data?.translatedText])

  async function onWord(word: string) {
    const w = word.trim()
    if (!w) return
    setWordBusy(true)
    try {
      const r = (await window.ft.invoke('translate:word', w)) as
        | { ok: true; translatedText: string }
        | { ok: false; error: string }
      if (r.ok) setWordTip({ word: w, text: r.translatedText })
      else setWordTip({ word: w, text: '', error: r.error })
    } finally {
      setWordBusy(false)
    }
  }

  function renderLine(tokens: LookupTok[], keyPrefix: string) {
    return tokens.map((t, i) =>
      t.kind === 'word' ? (
        <span
          key={`${keyPrefix}-${i}`}
          role="button"
          tabIndex={0}
          style={{
            cursor: wordBusy ? 'wait' : 'pointer',
            textDecoration: 'underline',
            textUnderlineOffset: 3,
            opacity: wordBusy ? 0.6 : 1
          }}
          onClick={() => void onWord(t.text)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') void onWord(t.text)
          }}
        >
          {t.text}
        </span>
      ) : (
        <span key={`${keyPrefix}-${i}`}>{t.text}</span>
      )
    )
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#0b1220', color: '#e5e7eb' }}>
      <header
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '10px 12px',
          borderBottom: '1px solid #1f2937',
          WebkitAppRegion: 'drag'
        }}
      >
        <div style={{ fontWeight: 600 }}>翻译结果</div>
        <button
          type="button"
          onClick={() => void window.ft.invoke('result:close')}
          style={{
            WebkitAppRegion: 'no-drag',
            border: '1px solid #334155',
            background: '#111827',
            color: '#e5e7eb',
            borderRadius: 8,
            padding: '6px 10px'
          }}
        >
          关闭
        </button>
      </header>
      <main style={{ padding: 12, gap: 12, display: 'grid', flex: 1, overflow: 'auto' }}>
        {!data ? (
          <div style={{ opacity: 0.75 }}>等待识别…</div>
        ) : (
          <>
            {data.error ? (
              <div
                style={{
                  color: '#fecaca',
                  background: 'rgba(127,29,29,0.35)',
                  border: '1px solid #7f1d1d',
                  borderRadius: 8,
                  padding: '10px 12px',
                  fontSize: 13,
                  lineHeight: 1.5
                }}
              >
                {data.error}
              </div>
            ) : null}
            {(data.sourceText || data.translatedText) && (
              <>
                <section>
                  <div style={{ fontSize: 12, opacity: 0.7, marginBottom: 6 }}>原文</div>
                  <div style={{ lineHeight: 1.65, fontSize: 14, userSelect: 'text' }}>
                    {renderLine(sourceToks, 's')}
                  </div>
                </section>
                <section>
                  <div style={{ fontSize: 12, opacity: 0.7, marginBottom: 6 }}>译文</div>
                  <div style={{ lineHeight: 1.65, fontSize: 14, userSelect: 'text', whiteSpace: 'pre-wrap' }}>
                    {renderLine(targetToks, 't')}
                  </div>
                  <div style={{ marginTop: 10 }}>
                    <button
                      type="button"
                      onClick={async () => {
                        await navigator.clipboard.writeText(data.translatedText ?? '')
                      }}
                      style={{
                        border: '1px solid #334155',
                        background: '#111827',
                        color: '#e5e7eb',
                        borderRadius: 8,
                        padding: '8px 10px'
                      }}
                    >
                      复制译文
                    </button>
                  </div>
                </section>
              </>
            )}
            {!data.error && !data.sourceText && !data.translatedText ? (
              <div style={{ opacity: 0.75 }}>无内容</div>
            ) : null}
            <div style={{ fontSize: 12, opacity: 0.65, marginTop: 4 }}>
              提示：点击原文或译文中的英文词、数字或单个汉字/假名，可单独调用翻译（消耗 API 配额）。
            </div>
          </>
        )}
      </main>
      {wordTip ? (
        <div
          style={{
            position: 'fixed',
            left: 12,
            right: 12,
            bottom: 12,
            background: '#111827',
            border: '1px solid #334155',
            borderRadius: 10,
            padding: 12,
            boxShadow: '0 12px 30px rgba(0,0,0,0.45)'
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
            <div style={{ fontWeight: 600 }}>{wordTip.word}</div>
            <button
              type="button"
              onClick={() => setWordTip(null)}
              style={{ border: 'none', background: 'transparent', color: '#93c5fd', cursor: 'pointer' }}
            >
              关闭
            </button>
          </div>
          <div style={{ marginTop: 8, fontSize: 12, opacity: 0.75 }}>音标 / 词性 / 例句（占位，可后续接词典 API）</div>
          <div style={{ marginTop: 8, fontSize: 13, lineHeight: 1.5 }}>
            {wordTip.error ? <span style={{ color: '#fca5a5' }}>{wordTip.error}</span> : wordTip.text}
          </div>
        </div>
      ) : null}
    </div>
  )
}
