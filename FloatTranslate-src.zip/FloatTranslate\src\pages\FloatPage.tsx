import { useEffect, useMemo, useRef, useState } from 'react'

type Settings = {
  floatOpacity: number
}

export function FloatPage() {
  const [open, setOpen] = useState(false)
  const [opacity, setOpacity] = useState(0.92)
  const [dragging, setDragging] = useState(false)
  const stripRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    void (async () => {
      const s = (await window.ft.invoke('settings:get')) as Settings
      setOpacity(Number(s.floatOpacity ?? 0.92))
    })()
  }, [])

  useEffect(() => {
    const w = open ? 200 : 72
    const h = open ? 292 : 88
    void window.ft.invoke('float:set-bounds', { width: w, height: h })
  }, [open])

  useEffect(() => {
    if (!dragging) return
    const raf = { id: 0 }
    const last = { sx: 0, sy: 0 }
    const move = (e: PointerEvent) => {
      if ((e.buttons & 1) === 0) return
      last.sx = e.screenX
      last.sy = e.screenY
      if (raf.id) return
      raf.id = requestAnimationFrame(() => {
        raf.id = 0
        void window.ft.invoke('float:drag-move', { sx: last.sx, sy: last.sy })
      })
    }
    const up = (e: PointerEvent) => {
      try {
        stripRef.current?.releasePointerCapture(e.pointerId)
      } catch {
        /* ignore */
      }
      void window.ft.invoke('float:drag-end')
      setDragging(false)
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
    return () => {
      if (raf.id) cancelAnimationFrame(raf.id)
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', up)
    }
  }, [dragging])

  const shell = useMemo(
    () => ({
      opacity,
      borderRadius: 999,
      width: 56,
      height: 56,
      background: 'linear-gradient(145deg, #1f6feb, #0d3a7a)',
      boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
      display: 'grid',
      placeItems: 'center',
      color: '#fff',
      fontSize: 22,
      userSelect: 'none' as const
    }),
    [opacity]
  )

  const onStripPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId)
    setDragging(true)
    void window.ft.invoke('float:drag-start', { sx: e.screenX, sy: e.screenY })
  }

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        background: 'transparent',
        color: '#e5e7eb'
      }}
    >
      <div
        ref={stripRef}
        onPointerDown={onStripPointerDown}
        style={{
          width: '100%',
          height: 14,
          flexShrink: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 10,
          letterSpacing: 1,
          cursor: 'move',
          userSelect: 'none',
          background: 'rgba(15, 23, 42, 0.92)',
          color: 'rgba(226,232,240,0.85)'
        }}
        title="按住拖动窗口"
      >
        ⋮⋮
      </div>

      <div
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'flex-start',
          paddingBottom: 8,
          gap: 8,
          width: '100%'
        }}
      >
        <div style={shell} title="点击打开菜单">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            style={{
              all: 'unset',
              cursor: 'pointer',
              width: 48,
              height: 48,
              display: 'grid',
              placeItems: 'center',
              borderRadius: 999
            }}
          >
            🌐
          </button>
        </div>

        {open ? (
          <div
            style={{
              width: 180,
              background: '#111827',
              color: '#e5e7eb',
              borderRadius: 10,
              padding: 8,
              boxShadow: '0 12px 30px rgba(0,0,0,0.45)',
              border: '1px solid #1f2937'
            }}
          >
            <MenuBtn
              label="截图翻译"
              onClick={async () => {
                setOpen(false)
                await window.ft.invoke('capture:start')
              }}
            />
            <MenuBtn
              label="剪贴板翻译"
              onClick={async () => {
                setOpen(false)
                await window.ft.invoke('translate:clipboard')
              }}
            />
            <MenuBtn
              label="设置"
              onClick={async () => {
                setOpen(false)
                await window.ft.invoke('settings:open')
              }}
            />
            <MenuBtn
              label="重置位置"
              onClick={async () => {
                await window.ft.invoke('float:reset-position')
              }}
            />
            <MenuBtn
              label="退出"
              onClick={async () => {
                await window.ft.invoke('app:quit')
              }}
            />
          </div>
        ) : null}
      </div>
    </div>
  )
}

function MenuBtn({ label, onClick }: { label: string; onClick: () => void | Promise<void> }) {
  return (
    <button
      type="button"
      onClick={() => void onClick()}
      style={{
        width: '100%',
        textAlign: 'left',
        padding: '10px 10px',
        borderRadius: 8,
        border: 'none',
        background: 'transparent',
        color: 'inherit',
        cursor: 'pointer'
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.background = '#1f2937'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = 'transparent'
      }}
    >
      {label}
    </button>
  )
}
