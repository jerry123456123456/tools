export const colors = {
  background: '#F4F6F8',
  surface: '#FFFFFF',
  primary: '#1B365D',
  primaryMuted: '#2C5282',
  accent: '#C6A24A',
  text: '#1A202C',
  textSecondary: '#4A5568',
  border: '#E2E8F0',
  danger: '#C53030',
  success: '#276749',
  waveform: '#2C5282',
};
