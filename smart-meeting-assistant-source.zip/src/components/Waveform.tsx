import { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import { colors } from '../theme/colors';

const BARS = 28;

function dbToHeight(db: number): number {
  const clamped = Math.max(-160, Math.min(0, db));
  const n = (clamped + 160) / 160;
  return 4 + n * 36;
}

export function Waveform({ metering }: { metering: number }) {
  const heights = useMemo(() => {
    const h = dbToHeight(metering);
    return Array.from({ length: BARS }, (_, i) => {
      const spread = ((i * 17) % 10) - 5;
      return Math.max(4, Math.min(44, h + spread));
    });
  }, [metering]);

  return (
    <View style={styles.row}>
      {heights.map((h, i) => (
        <View key={i} style={[styles.bar, { height: h }]} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    gap: 3,
    height: 48,
    paddingHorizontal: 8,
  },
  bar: {
    width: 5,
    borderRadius: 2,
    backgroundColor: colors.waveform,
    opacity: 0.85,
  },
});
