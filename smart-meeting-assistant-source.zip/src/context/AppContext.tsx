import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { defaultSettings, type AppSettings } from '../types';
import { initDatabase } from '../db/database';

const STORAGE_KEY = 'app_settings_v1';

type AppContextValue = {
  ready: boolean;
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  saveSettings: (s: AppSettings) => Promise<void>;
  refreshSettings: () => Promise<void>;
};

const AppContext = createContext<AppContextValue | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [settings, setSettingsState] = useState<AppSettings>(defaultSettings);

  const refreshSettings = useCallback(async () => {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw) as Partial<AppSettings> & { openaiApiKey?: string };
        const dashscopeApiKey =
          parsed.dashscopeApiKey?.trim() ||
          (typeof parsed.openaiApiKey === 'string' ? parsed.openaiApiKey.trim() : '');
        const { openaiApiKey: _drop, ...rest } = parsed;
        setSettingsState({ ...defaultSettings, ...rest, dashscopeApiKey });
      } catch {
        setSettingsState(defaultSettings);
      }
    } else {
      setSettingsState(defaultSettings);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      await initDatabase();
      await refreshSettings();
      if (!cancelled) setReady(true);
    })();
    return () => {
      cancelled = true;
    };
  }, [refreshSettings]);

  const setSettings = useCallback((s: AppSettings) => {
    setSettingsState(s);
  }, []);

  const saveSettings = useCallback(async (s: AppSettings) => {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(s));
    setSettingsState(s);
  }, []);

  const value = useMemo(
    () => ({ ready, settings, setSettings, saveSettings, refreshSettings }),
    [ready, settings, setSettings, saveSettings, refreshSettings]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp outside AppProvider');
  return ctx;
}
