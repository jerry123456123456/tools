import { Audio, type AVPlaybackStatus } from 'expo-av';
import {
  AndroidAudioEncoder,
  AndroidOutputFormat,
  IOSAudioQuality,
  IOSOutputFormat,
  type RecordingOptions,
} from 'expo-av/build/Audio';
import * as FileSystem from 'expo-file-system/legacy';
import { Platform } from 'react-native';

type ActiveRecording = InstanceType<typeof Audio.Recording>;

let active: ActiveRecording | undefined;

const HQ = Audio.RecordingOptionsPresets.HIGH_QUALITY;

/**
 * 百炼 Qwen3-ASR 兼容接口的 Data URL 仅稳定支持 WAV / MP3。
 * iOS：16kHz 单声道 PCM WAV；Android：AAC-ADTS（.aac），上传时使用 audio/aac。
 */
export function cloudAsrRecordingOptions(): RecordingOptions {
  if (Platform.OS === 'ios') {
    return {
      isMeteringEnabled: true,
      android: HQ.android,
      ios: {
        extension: '.wav',
        outputFormat: IOSOutputFormat.LINEARPCM,
        audioQuality: IOSAudioQuality.HIGH,
        sampleRate: 16000,
        numberOfChannels: 1,
        bitRate: 128000,
        linearPCMBitDepth: 16,
        linearPCMIsBigEndian: false,
        linearPCMIsFloat: false,
      },
      web: HQ.web,
    };
  }
  return {
    isMeteringEnabled: true,
    android: {
      extension: '.aac',
      outputFormat: AndroidOutputFormat.AAC_ADTS,
      audioEncoder: AndroidAudioEncoder.AAC,
      sampleRate: 16000,
      numberOfChannels: 1,
      bitRate: 64000,
    },
    ios: HQ.ios,
    web: HQ.web,
  };
}

export async function prepareAudioModeForRecord(): Promise<void> {
  const perm = await Audio.requestPermissionsAsync();
  if (perm.status !== 'granted') {
    throw new Error('MIC_DENIED');
  }
  await Audio.setAudioModeAsync({
    allowsRecordingIOS: true,
    playsInSilentModeIOS: true,
    shouldDuckAndroid: true,
    playThroughEarpieceAndroid: false,
    staysActiveInBackground: true,
  });
}

export async function startRecording(onMetering?: (db: number) => void): Promise<ActiveRecording> {
  await prepareAudioModeForRecord();
  const { recording } = await Audio.Recording.createAsync(
    {
      ...cloudAsrRecordingOptions(),
      isMeteringEnabled: true,
    },
    (status) => {
      if (status.isRecording && status.metering != null && onMetering) {
        onMetering(status.metering);
      }
    },
    120
  );
  active = recording;
  return recording;
}

export function getActiveRecording(): ActiveRecording | undefined {
  return active;
}

export async function pauseRecording(): Promise<void> {
  if (active) await active.pauseAsync();
}

export async function resumeRecording(): Promise<void> {
  if (active) await active.startAsync();
}

export async function stopRecording(): Promise<{ uri: string | null; durationMillis: number }> {
  if (!active) return { uri: null, durationMillis: 0 };
  const rec = active;
  active = undefined;
  const pre = await rec.getStatusAsync();
  const durationMillis = pre.durationMillis ?? 0;
  await rec.stopAndUnloadAsync();
  await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
  const uri = rec.getURI() ?? null;
  return { uri, durationMillis };
}

export async function persistRecording(localUri: string | null, meetingId: string): Promise<string | null> {
  if (!localUri) return null;
  const root = FileSystem.documentDirectory;
  if (!root) return localUri;
  const dir = `${root}recordings/`;
  await FileSystem.makeDirectoryAsync(dir, { intermediates: true }).catch(() => undefined);
  const extMatch = localUri.match(/\.[a-z0-9]+$/i);
  const ext = extMatch ? extMatch[0].toLowerCase() : '.m4a';
  const dest = `${dir}${meetingId}${ext}`;
  await FileSystem.copyAsync({ from: localUri, to: dest });
  return dest;
}

export async function playUri(uri: string, onStatus?: (s: AVPlaybackStatus) => void): Promise<Audio.Sound> {
  await Audio.setAudioModeAsync({
    allowsRecordingIOS: false,
    playsInSilentModeIOS: true,
    shouldDuckAndroid: true,
    playThroughEarpieceAndroid: false,
  });
  const { sound } = await Audio.Sound.createAsync(
    { uri },
    { shouldPlay: true },
    onStatus
      ? (s) => {
          if (s.isLoaded) onStatus(s);
        }
      : null
  );
  return sound;
}
