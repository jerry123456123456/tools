import type { AiStyle, MeetingLanguage, MinutesStructure, TodoDraft } from '../types';

function formatLocalContextDate(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day} (device local date; use this for 今天/明天 in suggestedTime)`;
}

const CHAT_URL = 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions';
const CHAT_MODEL = 'qwen-turbo-latest';

const systemPrompt = (style: AiStyle, lang: MeetingLanguage) => {
  const styleHint =
    style === 'concise'
      ? 'Use concise bullets suitable for executives.'
      : style === 'detailed'
        ? 'Include supporting context and rationale where helpful.'
        : 'Use formal business language suitable for external stakeholders.';
  const langHint =
    lang === 'en' ? 'Write in English.' : lang === 'zh' ? 'Write in Chinese.' : 'Match the transcript language.';
  return `You are a meeting assistant. ${styleHint} ${langHint}
Return ONLY valid JSON with keys: summary (string), outline (array of strings numbered 1.2.3. in text), conclusions, decisions, issues, highlights (all arrays of strings), diarizedTranscript (string, format lines like "说话人1: ..." / "Speaker 1: ..." inferring speakers from context — heuristic split is acceptable), todos (array of {content, priority: "low"|"medium"|"high", suggestedTime: string}).
For each todo, suggestedTime MUST be either empty "" (unknown / no specific time) OR a LOCAL datetime WITHOUT timezone suffix Z: format "YYYY-MM-DDTHH:mm:ss" using the SAME local calendar date as in the user message (今天=today, 明天=tomorrow from context). Never invent a random past year (e.g. 2024). Never use trailing Z.
For purely relative phrases like "in 10 seconds" / "10秒后", set suggestedTime to empty "" (the app parses seconds/minutes from todo content and adds to current time when syncing).
If the user asks for a clock alarm or timer (闹钟/定时器/秒表/叫醒), include those words in the todo content so the app can set "闹钟提醒". If they explicitly want notification-only calendar alerts, include "仅通知" in the content.`;
};

export type AiBundle = {
  minutes: MinutesStructure;
  todos: TodoDraft[];
};

export async function generateMinutesAndTodos(params: {
  apiKey: string;
  transcript: string;
  style: AiStyle;
  meetingLanguage: MeetingLanguage;
}): Promise<AiBundle> {
  const { apiKey, transcript, style, meetingLanguage } = params;
  const body = {
    model: CHAT_MODEL,
    messages: [
      { role: 'system', content: systemPrompt(style, meetingLanguage) },
      {
        role: 'user',
        content: `Recording local "today" is: ${formatLocalContextDate()}\nTranscript:\n${transcript.slice(0, 120000)}`,
      },
    ],
    response_format: { type: 'json_object' },
    temperature: 0.3,
  };

  const res = await fetch(CHAT_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Chat HTTP ${res.status}: ${errText.slice(0, 200)}`);
  }
  const data = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const raw = data.choices?.[0]?.message?.content;
  if (!raw) throw new Error('Empty AI response');
  const parsed = JSON.parse(raw) as Record<string, unknown>;
  const minutes: MinutesStructure = {
    summary: String(parsed.summary ?? ''),
    outline: Array.isArray(parsed.outline) ? parsed.outline.map(String) : [],
    conclusions: Array.isArray(parsed.conclusions) ? parsed.conclusions.map(String) : [],
    decisions: Array.isArray(parsed.decisions) ? parsed.decisions.map(String) : [],
    issues: Array.isArray(parsed.issues) ? parsed.issues.map(String) : [],
    highlights: Array.isArray(parsed.highlights) ? parsed.highlights.map(String) : [],
    diarizedTranscript: parsed.diarizedTranscript != null ? String(parsed.diarizedTranscript) : undefined,
  };
  const todosRaw = Array.isArray(parsed.todos) ? parsed.todos : [];
  const todos: TodoDraft[] = todosRaw.map((item) => {
    const o = item as Record<string, unknown>;
    return {
      content: String(o.content ?? ''),
      priority: (['low', 'medium', 'high'].includes(String(o.priority))
        ? o.priority
        : 'medium') as TodoDraft['priority'],
      suggestedTime: o.suggestedTime ? String(o.suggestedTime) : undefined,
    };
  });
  return { minutes, todos };
}

export function emptyMinutes(transcript: string): MinutesStructure {
  return {
    summary: transcript.trim()
      ? '（未调用云端）请在设置中填写 DashScope API Key，并关闭「隐私模式」后重新录音。'
      : '暂无转写内容。',
    outline: [],
    conclusions: [],
    decisions: [],
    issues: [],
    highlights: [],
    diarizedTranscript: transcript.trim() || undefined,
  };
}
