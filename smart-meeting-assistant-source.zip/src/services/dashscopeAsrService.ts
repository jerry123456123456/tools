import * as FileSystem from 'expo-file-system/legacy';
import type { AsrQuality, MeetingLanguage } from '../types';

const CHAT_URL = 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions';
const MAX_BYTES = 10 * 1024 * 1024;

export async function transcribeWithDashScope(params: {
  apiKey: string;
  fileUri: string;
  language?: MeetingLanguage;
  quality: AsrQuality;
}): Promise<string> {
  const { apiKey, fileUri, language, quality } = params;
  const info = await FileSystem.getInfoAsync(fileUri);
  if (!info.exists) throw new Error('录音文件不存在');
  const size = info.size ?? 0;
  if (size > MAX_BYTES) {
    throw new Error(`音频超过 ${MAX_BYTES / 1024 / 1024}MB 上限，请缩短录音或使用异步识别`);
  }

  const b64 = await FileSystem.readAsStringAsync(fileUri, {
    encoding: FileSystem.EncodingType.Base64,
  });
  const lower = fileUri.toLowerCase();
  let mime = 'audio/wav';
  if (lower.endsWith('.mp3')) mime = 'audio/mpeg';
  else if (lower.endsWith('.aac')) mime = 'audio/aac';
  else if (lower.endsWith('.wav')) mime = 'audio/wav';
  else if (lower.endsWith('.m4a') || lower.endsWith('.mp4') || lower.endsWith('.caf')) {
    throw new Error(
      '当前文件为 M4A/MP4 等格式，百炼 Qwen3-ASR 同步接口不接受该格式。请使用新版录音（WAV / AAC）后重试，或重新录制一条。'
    );
  }
  const dataUrl = `data:${mime};base64,${b64}`;

  const asr_options: Record<string, unknown> = {
    enable_itn: quality === 'high',
  };
  if (language === 'zh') asr_options.language = 'zh';
  if (language === 'en') asr_options.language = 'en';

  const body = {
    model: 'qwen3-asr-flash',
    messages: [
      {
        role: 'user' as const,
        content: [
          {
            type: 'input_audio',
            input_audio: { data: dataUrl },
          },
        ],
      },
    ],
    asr_options,
  };

  const res = await fetch(CHAT_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`语音识别 HTTP ${res.status}: ${errText.slice(0, 200)}`);
  }
  const data = (await res.json()) as {
    choices?: { message?: { content?: string | null } }[];
  };
  const text = data.choices?.[0]?.message?.content;
  if (text == null || String(text).trim() === '') throw new Error('语音识别返回为空');
  return String(text).trim();
}
