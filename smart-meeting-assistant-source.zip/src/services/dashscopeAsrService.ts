import * as FileSystem from 'expo-file-system/legacy';
import type { AsrQuality, MeetingLanguage } from '../types';

const CHAT_URL = 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions';
/** 与百炼同步 ASR 约定一致：单请求音频不宜过大（含 Base64 膨胀） */
export const MAX_SYNC_AUDIO_BYTES = 10 * 1024 * 1024;
/** 每个分片 PCM / ADTS payload 目标大小，留出 WAV 头与 JSON 余量 */
const CHUNK_PAYLOAD_BYTES = 9 * 1024 * 1024;
/**
 * 同步 qwen3-asr-flash 单次还有「音频时长」上限（官方约 3 分钟），仅按 10MB 分片仍可能一次塞入 10 分钟 AAC 导致 HTTP 400。
 * 按时长切块并与 {@link CHUNK_PAYLOAD_BYTES} 取较小值。
 */
export const MAX_CHUNK_AUDIO_SECONDS = 150;
/** 与 {@link recordingService} 中 Android AAC 64kbps 一致，用于估算时长以便分片 */
const AAC_BYTES_PER_SEC_EST = 64000 / 8;

export type TranscribeDashScopeParams = {
  apiKey: string;
  fileUri: string;
  language?: MeetingLanguage;
  quality: AsrQuality;
  /** 若提供：每完成一段语音转写即把该段文字追加写入此 UTF-8 文件；单次转写则整篇写入。上层可再读此文件交给大模型。 */
  transcriptAppendUri?: string | null;
  /** 仅当总分片数 > 1 时回调，便于 UI 展示进度 */
  onChunkProgress?: (current: number, total: number) => void;
};

function readAscii(buf: Uint8Array, offset: number, len: number): string {
  let s = '';
  for (let i = 0; i < len; i++) s += String.fromCharCode(buf[offset + i]!);
  return s;
}

function readU16LE(buf: Uint8Array, offset: number): number {
  return buf[offset]! | (buf[offset + 1]! << 8);
}

function readU32LE(buf: Uint8Array, offset: number): number {
  return buf[offset]! | (buf[offset + 1]! << 8) | (buf[offset + 2]! << 16) | (buf[offset + 3]! << 24);
}

async function readFileBytes(fileUri: string, position: number, length: number): Promise<Uint8Array> {
  const b64 = await FileSystem.readAsStringAsync(fileUri, {
    encoding: FileSystem.EncodingType.Base64,
    position,
    length,
  });
  return base64ToUint8Array(b64);
}

function base64ToUint8Array(base64: string): Uint8Array {
  const bin = atob(base64);
  const len = bin.length;
  const out = new Uint8Array(len);
  for (let i = 0; i < len; i++) out[i] = bin.charCodeAt(i) & 0xff;
  return out;
}

function uint8ToBase64(data: Uint8Array): string {
  const CHUNK = 0x7000;
  let s = '';
  for (let i = 0; i < data.length; i += CHUNK) {
    const sub = data.subarray(i, Math.min(i + CHUNK, data.length));
    let bin = '';
    for (let j = 0; j < sub.length; j++) bin += String.fromCharCode(sub[j]!);
    s += bin;
  }
  return btoa(s);
}

type FmtInfo = {
  audioFormat: number;
  numChannels: number;
  sampleRate: number;
  bitsPerSample: number;
  blockAlign: number;
};

function parseFmtChunk(data: Uint8Array): FmtInfo {
  return {
    audioFormat: readU16LE(data, 0),
    numChannels: readU16LE(data, 2),
    sampleRate: readU32LE(data, 4),
    blockAlign: readU16LE(data, 12),
    bitsPerSample: readU16LE(data, 14),
  };
}

/** 自文件开头的 buffer 解析 fmt + data 布局；buffer 不足时返回 null 以便扩大读取 */
function parseWavDataLayout(buf: Uint8Array): { fmt: FmtInfo; dataOffset: number; dataSize: number } | null {
  if (buf.length < 12 || readAscii(buf, 0, 4) !== 'RIFF' || readAscii(buf, 8, 4) !== 'WAVE') return null;
  let o = 12;
  let fmt: FmtInfo | undefined;
  while (o + 8 <= buf.length) {
    const id = readAscii(buf, o, 4);
    const chunkSize = readU32LE(buf, o + 4);
    const payloadStart = o + 8;
    if (id === 'fmt ') {
      if (payloadStart + chunkSize > buf.length) return null;
      fmt = parseFmtChunk(buf.subarray(payloadStart, payloadStart + chunkSize));
    } else if (id === 'data') {
      if (!fmt) return null;
      return { fmt, dataOffset: payloadStart, dataSize: chunkSize };
    } else {
      if (payloadStart + chunkSize > buf.length) return null;
    }
    o = payloadStart + chunkSize + (chunkSize % 2);
  }
  return null;
}

async function loadWavLayout(fileUri: string, fileSize: number): Promise<{ fmt: FmtInfo; dataOffset: number; dataSize: number }> {
  let want = Math.min(256 * 1024, fileSize);
  for (let i = 0; i < 10; i++) {
    const buf = await readFileBytes(fileUri, 0, want);
    const layout = parseWavDataLayout(buf);
    if (layout) {
      if (layout.dataOffset + layout.dataSize > fileSize) {
        throw new Error('WAV 文件头与文件大小不一致，可能已损坏');
      }
      return layout;
    }
    if (want >= fileSize) break;
    want = Math.min(want * 2, fileSize);
  }
  throw new Error('无法解析 WAV（未找到 data 块）');
}

function buildWavPcmFile(pcm: Uint8Array, fmt: FmtInfo): Uint8Array {
  if (fmt.audioFormat !== 1) {
    throw new Error('仅支持 PCM 格式 WAV 分片转写（audioFormat=1）');
  }
  const { sampleRate, numChannels, bitsPerSample, blockAlign } = fmt;
  const dataSize = pcm.length;
  const riffChunkSize = 36 + dataSize;
  const out = new Uint8Array(44 + dataSize);
  const w = (pos: number, str: string) => {
    for (let i = 0; i < str.length; i++) out[pos + i] = str.charCodeAt(i) & 0xff;
  };
  const w32 = (pos: number, v: number) => {
    out[pos] = v & 0xff;
    out[pos + 1] = (v >> 8) & 0xff;
    out[pos + 2] = (v >> 16) & 0xff;
    out[pos + 3] = (v >> 24) & 0xff;
  };
  const w16 = (pos: number, v: number) => {
    out[pos] = v & 0xff;
    out[pos + 1] = (v >> 8) & 0xff;
  };
  w(0, 'RIFF');
  w32(4, riffChunkSize);
  w(8, 'WAVE');
  w(12, 'fmt ');
  w32(16, 16);
  w16(20, 1);
  w16(22, numChannels);
  w32(24, sampleRate);
  w32(28, sampleRate * blockAlign);
  w16(32, blockAlign);
  w16(34, bitsPerSample);
  w(36, 'data');
  w32(40, dataSize);
  out.set(pcm, 44);
  return out;
}

function mimeFromPath(fileUri: string): string {
  const lower = fileUri.toLowerCase();
  if (lower.endsWith('.mp3')) return 'audio/mpeg';
  if (lower.endsWith('.aac')) return 'audio/aac';
  if (lower.endsWith('.wav')) return 'audio/wav';
  if (lower.endsWith('.m4a') || lower.endsWith('.mp4') || lower.endsWith('.caf')) {
    throw new Error(
      '当前文件为 M4A/MP4 等格式，百炼 Qwen3-ASR 同步接口不接受该格式。请使用新版录音（WAV / AAC）后重试，或重新录制一条。'
    );
  }
  return 'audio/wav';
}

async function dashScopeAsrRequest(params: {
  apiKey: string;
  fileUri: string;
  language?: MeetingLanguage;
  quality: AsrQuality;
}): Promise<string> {
  const { apiKey, fileUri, language, quality } = params;
  const b64 = await FileSystem.readAsStringAsync(fileUri, {
    encoding: FileSystem.EncodingType.Base64,
  });
  const mime = mimeFromPath(fileUri);
  const dataUrl = `data:${mime};base64,${b64}`;

  const asr_options: Record<string, unknown> = {
    enable_itn: quality === 'high',
  };
  if (language === 'zh') asr_options.language = 'zh';
  if (language === 'en') asr_options.language = 'en';

  const body = {
    model: 'qwen3-asr-flash',
    messages: [
      {
        role: 'user' as const,
        content: [
          {
            type: 'input_audio',
            input_audio: { data: dataUrl },
          },
        ],
      },
    ],
    asr_options,
  };

  const res = await fetch(CHAT_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`语音识别 HTTP ${res.status}: ${errText.slice(0, 200)}`);
  }
  const data = (await res.json()) as {
    choices?: { message?: { content?: string | null } }[];
  };
  const text = data.choices?.[0]?.message?.content;
  if (text == null || String(text).trim() === '') throw new Error('语音识别返回为空');
  return String(text).trim();
}

/** 将本段转写追加到 UTF-8 文本文件（段与段之间空一行），供随后整文件送入大模型 */
async function appendTranscriptToFile(uri: string, segment: string): Promise<void> {
  const t = segment.trim();
  if (!t) return;
  let prev = '';
  try {
    const info = await FileSystem.getInfoAsync(uri);
    if (info.exists) prev = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.UTF8 });
  } catch {
    /* first segment */
  }
  const next = prev.trim() === '' ? t : `${prev.trimEnd()}\n\n${t}`;
  await FileSystem.writeAsStringAsync(uri, next, { encoding: FileSystem.EncodingType.UTF8 });
}

function tryAdtsFrame(buf: Uint8Array, pos: number): { len: number } | null {
  if (pos + 7 > buf.length) return null;
  if (buf[pos] !== 0xff || (buf[pos + 1]! & 0xf0) !== 0xf0) return null;
  const frameLen = ((buf[pos + 3]! & 0x03) << 11) | (buf[pos + 4]! << 3) | ((buf[pos + 5]! & 0xe0) >> 5);
  if (frameLen < 7 || frameLen > 8192 * 6) return null;
  if (pos + frameLen > buf.length) return null;
  return { len: frameLen };
}

function concatUint8(parts: Uint8Array[]): Uint8Array {
  let n = 0;
  for (const p of parts) n += p.length;
  const out = new Uint8Array(n);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

async function transcribeWavInChunks(params: {
  apiKey: string;
  fileUri: string;
  language?: MeetingLanguage;
  quality: AsrQuality;
  transcriptAppendUri?: string | null;
  onChunkProgress?: (current: number, total: number) => void;
}): Promise<string> {
  const { apiKey, fileUri, language, quality, transcriptAppendUri, onChunkProgress } = params;
  const info = await FileSystem.getInfoAsync(fileUri);
  if (!info.exists) throw new Error('录音文件不存在');
  const fileSize = info.size ?? 0;
  const layout = await loadWavLayout(fileUri, fileSize);
  const { fmt, dataOffset, dataSize } = layout;
  const align = Math.max(1, fmt.blockAlign);
  const bytesPerSec = Math.max(1, fmt.sampleRate * fmt.blockAlign);
  const maxPcmByDuration = Math.floor(MAX_CHUNK_AUDIO_SECONDS * bytesPerSec);
  let chunkPayload = Math.min(CHUNK_PAYLOAD_BYTES, maxPcmByDuration);
  chunkPayload -= chunkPayload % align;
  if (chunkPayload < align) chunkPayload = align;

  const numChunks = Math.max(1, Math.ceil(dataSize / chunkPayload));
  if (numChunks > 1) onChunkProgress?.(0, numChunks);

  const pieces: string[] = [];
  const cacheRoot = FileSystem.cacheDirectory;
  if (!cacheRoot) throw new Error('无缓存目录，无法写入分片 WAV');

  for (let i = 0, part = 1; i < dataSize; i += chunkPayload, part++) {
    const len = Math.min(chunkPayload, dataSize - i);
    const pcm = await readFileBytes(fileUri, dataOffset + i, len);
    const wavBytes = buildWavPcmFile(pcm, fmt);
    const chunkPath = `${cacheRoot}asr_chunk_${Date.now()}_${part}.wav`;
    await FileSystem.writeAsStringAsync(chunkPath, uint8ToBase64(wavBytes), {
      encoding: FileSystem.EncodingType.Base64,
    });
    try {
      if (numChunks > 1) onChunkProgress?.(part, numChunks);
      const text = await dashScopeAsrRequest({ apiKey, fileUri: chunkPath, language, quality });
      pieces.push(text);
      if (transcriptAppendUri) await appendTranscriptToFile(transcriptAppendUri, text);
    } finally {
      await FileSystem.deleteAsync(chunkPath, { idempotent: true }).catch(() => undefined);
    }
  }

  if (numChunks <= 1) {
    return pieces[0] ?? '';
  }
  return pieces.join('\n\n');
}

async function transcribeAacAdtsInChunks(params: {
  apiKey: string;
  fileUri: string;
  language?: MeetingLanguage;
  quality: AsrQuality;
  transcriptAppendUri?: string | null;
  onChunkProgress?: (current: number, total: number) => void;
}): Promise<string> {
  const { apiKey, fileUri, language, quality, transcriptAppendUri, onChunkProgress } = params;
  const info = await FileSystem.getInfoAsync(fileUri);
  if (!info.exists) throw new Error('录音文件不存在');
  const fileSize = info.size ?? 0;
  /** 同时满足「约 2.5 分钟」与 9MB 上限，避免仅按字节导致单次仍超长 */
  const chunkPayloadAac = Math.min(
    CHUNK_PAYLOAD_BYTES,
    Math.floor(MAX_CHUNK_AUDIO_SECONDS * AAC_BYTES_PER_SEC_EST)
  );

  const approxChunks = Math.max(1, Math.ceil(fileSize / chunkPayloadAac));

  const windowSize = 2 * 1024 * 1024;
  let filePos = 0;
  let carry = new Uint8Array(0);
  const frameBatch: Uint8Array[] = [];
  let batchBytes = 0;
  const pieces: string[] = [];
  let part = 0;
  const cacheRoot = FileSystem.cacheDirectory;
  if (!cacheRoot) throw new Error('无缓存目录，无法写入分片 AAC');

  const flushBatch = async () => {
    if (!frameBatch.length) return;
    part += 1;
    if (approxChunks > 1) onChunkProgress?.(part, Math.max(approxChunks, part));
    const blob = concatUint8(frameBatch);
    frameBatch.length = 0;
    batchBytes = 0;
    const chunkPath = `${cacheRoot}asr_chunk_${Date.now()}_${part}.aac`;
    await FileSystem.writeAsStringAsync(chunkPath, uint8ToBase64(blob), {
      encoding: FileSystem.EncodingType.Base64,
    });
    try {
      const text = await dashScopeAsrRequest({ apiKey, fileUri: chunkPath, language, quality });
      pieces.push(text);
      if (transcriptAppendUri) await appendTranscriptToFile(transcriptAppendUri, text);
    } finally {
      await FileSystem.deleteAsync(chunkPath, { idempotent: true }).catch(() => undefined);
    }
  };

  if (approxChunks > 1) onChunkProgress?.(0, approxChunks);

  filePos = 0;
  carry = new Uint8Array(0);
  while (filePos < fileSize) {
    const wlen = Math.min(windowSize, fileSize - filePos);
    const win = await readFileBytes(fileUri, filePos, wlen);
    filePos += wlen;
    const buf = carry.length ? concatUint8([carry, win]) : win;
    let consumed = 0;
    while (consumed + 7 <= buf.length) {
      const fr = tryAdtsFrame(buf, consumed);
      if (!fr) {
        consumed += 1;
        continue;
      }
      const frame = buf.subarray(consumed, consumed + fr.len);
      if (batchBytes + frame.length > chunkPayloadAac && frameBatch.length > 0) {
        await flushBatch();
      }
      frameBatch.push(frame);
      batchBytes += frame.length;
      consumed += fr.len;
    }
    carry = Uint8Array.from(buf.subarray(consumed));
  }

  if (carry.length) {
    let c = 0;
    while (c + 7 <= carry.length) {
      const fr = tryAdtsFrame(carry, c);
      if (!fr) {
        c += 1;
        continue;
      }
      const frame = carry.subarray(c, c + fr.len);
      if (batchBytes + frame.length > chunkPayloadAac && frameBatch.length > 0) {
        await flushBatch();
      }
      frameBatch.push(frame);
      batchBytes += frame.length;
      c += fr.len;
    }
  }

  if (frameBatch.length) {
    await flushBatch();
  }

  if (!pieces.length) {
    throw new Error('未从 AAC 文件中解析出 ADTS 帧，请确认文件为录音导出的 .aac');
  }
  const total = pieces.length;
  if (total > 1) onChunkProgress?.(total, total);
  return pieces.join('\n\n');
}

/**
 * DashScope Qwen3-ASR：单次请求受约 10MB 与约 3 分钟时长限制。
 * 超出任一则按 WAV PCM 或 AAC(ADTS) 分片转写；若提供 {@link TranscribeDashScopeParams.transcriptAppendUri}，
 * 每段结果会追加写入该 UTF-8 文件，返回值为全文（与文件内容一致）。
 */
export async function transcribeWithDashScope(params: TranscribeDashScopeParams): Promise<string> {
  const { apiKey, fileUri, language, quality, transcriptAppendUri, onChunkProgress } = params;
  const info = await FileSystem.getInfoAsync(fileUri);
  if (!info.exists) throw new Error('录音文件不存在');
  const size = info.size ?? 0;
  const lower = fileUri.toLowerCase();

  let useChunks = size > MAX_SYNC_AUDIO_BYTES;
  if (!useChunks && lower.endsWith('.wav')) {
    try {
      const layout = await loadWavLayout(fileUri, size);
      const bps = Math.max(1, layout.fmt.sampleRate * layout.fmt.blockAlign);
      if (layout.dataSize / bps > MAX_CHUNK_AUDIO_SECONDS) useChunks = true;
    } catch {
      /* 头解析失败则走单次请求 */
    }
  }
  if (!useChunks && lower.endsWith('.aac')) {
    const estSec = size / AAC_BYTES_PER_SEC_EST;
    if (estSec > MAX_CHUNK_AUDIO_SECONDS) useChunks = true;
  }

  if (!useChunks) {
    const text = await dashScopeAsrRequest({ apiKey, fileUri, language, quality });
    if (transcriptAppendUri) {
      await FileSystem.writeAsStringAsync(transcriptAppendUri, text, {
        encoding: FileSystem.EncodingType.UTF8,
      });
    }
    return text;
  }

  if (lower.endsWith('.wav')) {
    return transcribeWavInChunks({
      apiKey,
      fileUri,
      language,
      quality,
      transcriptAppendUri,
      onChunkProgress,
    });
  }
  if (lower.endsWith('.aac')) {
    return transcribeAacAdtsInChunks({
      apiKey,
      fileUri,
      language,
      quality,
      transcriptAppendUri,
      onChunkProgress,
    });
  }
  throw new Error(
    `音频过长或超过 ${MAX_SYNC_AUDIO_BYTES / 1024 / 1024}MB，且当前格式不支持自动分片。请使用 iOS 录音（WAV）或 Android 录音（AAC）。`
  );
}
