import * as Calendar from 'expo-calendar';
import * as Clipboard from 'expo-clipboard';
import * as Notifications from 'expo-notifications';
import { Linking, Platform, Share } from 'react-native';

export async function createSystemReminder(params: {
  title: string;
  notes?: string;
  dueDate: Date;
  /** 与日历相同逻辑，用于区分：事件提醒 / 通知提醒 / 闹钟提醒 */
  sourceTextForReminder?: string;
}): Promise<string> {
  const hint = `${params.title}\n${params.notes ?? ''}\n${params.sourceTextForReminder ?? ''}`;
  const mode = resolveCalendarReminderMode(hint);

  if (Platform.OS === 'ios') {
    const { status } = await Calendar.requestRemindersPermissionsAsync();
    if (status !== 'granted') throw new Error('REMINDER_DENIED');
    const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.REMINDER);
    const cal = calendars.find((c) => c.allowsModifications) ?? calendars[0];
    const due = params.dueDate;
    return Calendar.createReminderAsync(cal?.id ?? null, {
      title: params.title,
      notes: params.notes,
      dueDate: due,
      allDay: false,
      alarms: buildIosReminderAlarms(due),
    });
  }
  await scheduleLocalReminder({
    title: params.title,
    body: params.notes ?? '',
    fireDate: params.dueDate,
  });
  if (mode === 'alarm') {
    await tryOpenAndroidClockAlarm(params.dueDate, params.title);
  }
  return 'android-notification';
}

/** 尝试打开系统「时钟」新建闹钟界面（需用户点保存）；与通知提醒并行 */
async function tryOpenAndroidClockAlarm(due: Date, message: string): Promise<void> {
  if (Platform.OS !== 'android') return;
  const hour = due.getHours();
  const minute = due.getMinutes();
  const msg = encodeURIComponent(message.slice(0, 80)).replace(/'/g, '%27');
  const uri = `intent:#Intent;action=android.intent.action.SET_ALARM;S.android.intent.extra.alarm.MESSAGE=${msg};i.android.intent.extra.alarm.HOUR=${hour};i.android.intent.extra.alarm.MINUTES=${minute};end`;
  try {
    await Linking.openURL(uri);
  } catch {
    /* 部分机型 / 策略不支持 Intent URI */
  }
}

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

async function ensureCalendarPermission(): Promise<boolean> {
  const { status } = await Calendar.requestCalendarPermissionsAsync();
  return status === 'granted';
}

/** 日程提醒策略：事件（默认）| 仅通知 | 闹钟（强） */
export type CalendarReminderMode = 'event' | 'notification' | 'alarm';

/** 用户明确要「通知提醒」、不要响铃式闹钟 */
export function prefersNotificationOnlyReminder(text: string): boolean {
  return /仅通知|只要通知|通知即可|不要闹钟|无需闹钟|不用闹钟|别用闹钟|不要响铃|静音提醒|通知提醒即可|notification only|no alarm|silent reminder/i.test(
    text
  );
}

/** 用户明确要「闹钟 / 定时器」类响铃提醒（优先于默认事件提醒） */
export function prefersClockAlarmReminder(text: string): boolean {
  return /闹钟|闹铃|定时器|秒表|定闹钟|用闹钟|设置闹钟|闹钟提醒|叫醒|倒计时.*提醒|clock\s*alarm|set\s+an?\s+alarm|timer\b/i.test(
    text
  );
}

/**
 * 默认「事件提醒」；仅当正文明确要求「仅通知」→ 通知提醒；明确要求「闹钟/定时器」→ 闹钟提醒。
 */
export function resolveCalendarReminderMode(text: string): CalendarReminderMode {
  if (prefersNotificationOnlyReminder(text)) return 'notification';
  if (prefersClockAlarmReminder(text)) return 'alarm';
  return 'event';
}

function androidAlarmMethodForMode(mode: CalendarReminderMode): Calendar.AlarmMethod {
  switch (mode) {
    case 'alarm':
      return Calendar.AlarmMethod.ALARM;
    case 'notification':
      return Calendar.AlarmMethod.ALERT;
    case 'event':
    default:
      return Calendar.AlarmMethod.DEFAULT;
  }
}

/** @deprecated 使用 resolveCalendarReminderMode + androidAlarmMethodForMode */
export function resolveAndroidCalendarAlarmMethod(sourceText: string): Calendar.AlarmMethod {
  return androidAlarmMethodForMode(resolveCalendarReminderMode(sourceText));
}

type ExpoEventCalendar = Awaited<ReturnType<typeof Calendar.getCalendarsAsync>>[number];

/** Android：优先选支持闹钟提醒的本地日历，避免 METHOD_ALARM 被静默丢弃 */
function pickWritableCalendar(calendars: ExpoEventCalendar[], mode: CalendarReminderMode): ExpoEventCalendar | undefined {
  const list = calendars.filter((c) => c.allowsModifications);
  if (list.length === 0) return undefined;
  if (Platform.OS !== 'android') return list[0];
  if (mode === 'alarm') {
    const withAlarm = list.find(
      (c) => Array.isArray(c.allowedReminders) && c.allowedReminders.includes(Calendar.AlarmMethod.ALARM)
    );
    if (withAlarm) return withAlarm;
  }
  return list.find((c) => c.isPrimary) ?? list[0];
}

/** 当前日历不支持 ALARM 时降级，避免写入无效提醒 */
function coerceReminderMethodForAndroidCalendar(
  desired: Calendar.AlarmMethod,
  cal: ExpoEventCalendar
): Calendar.AlarmMethod {
  if (Platform.OS !== 'android') return desired;
  const ar = cal.allowedReminders;
  if (!Array.isArray(ar) || ar.length === 0) return desired;
  if (desired === Calendar.AlarmMethod.ALARM && !ar.includes(Calendar.AlarmMethod.ALARM)) {
    if (ar.includes(Calendar.AlarmMethod.DEFAULT)) return Calendar.AlarmMethod.DEFAULT;
    return Calendar.AlarmMethod.ALERT;
  }
  return desired;
}

/**
 * Android expo-calendar：原生用 MINUTES = -relativeOffset；**relativeOffset 为 0 → MINUTES=0**，
 * 多数国产系统会显示「无提醒」。因此只使用 **严格为负** 的提前量（分钟）。
 */
function buildAndroidCalendarAlarms(method: Calendar.AlarmMethod): Calendar.Alarm[] {
  return [
    { relativeOffset: -15, method },
    { relativeOffset: -5, method },
    { relativeOffset: -1, method },
  ];
}

/** iOS 提醒事项：必有提醒（到时点 + 提前 5 分钟），避免「无提醒」 */
function buildIosReminderAlarms(dueDate: Date): Calendar.Alarm[] {
  return [{ absoluteDate: dueDate.toISOString() }, { relativeOffset: -5 }];
}

function buildCalendarEventAlarms(
  startDate: Date,
  sourceText: string,
  androidCalendar?: ExpoEventCalendar
): Calendar.Alarm[] {
  if (Platform.OS === 'android') {
    const mode = resolveCalendarReminderMode(sourceText);
    const base = androidAlarmMethodForMode(mode);
    const method =
      androidCalendar != null ? coerceReminderMethodForAndroidCalendar(base, androidCalendar) : base;
    return buildAndroidCalendarAlarms(method);
  }
  return [{ absoluteDate: startDate.toISOString() }, { relativeOffset: -5 }];
}

export async function addCalendarEvent(params: {
  title: string;
  notes?: string;
  startDate: Date;
  endDate: Date;
  /** 待办/会议相关文案，用于判断闹钟 vs 仅通知 */
  sourceTextForReminder?: string;
}): Promise<string> {
  const ok = await ensureCalendarPermission();
  if (!ok) throw new Error('CALENDAR_DENIED');
  const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
  const hint = `${params.title}\n${params.notes ?? ''}\n${params.sourceTextForReminder ?? ''}`;
  const mode = resolveCalendarReminderMode(hint);
  const cal =
    pickWritableCalendar(calendars, mode) ??
    calendars.find((c) => c.allowsModifications) ??
    calendars[0];
  if (!cal?.id) throw new Error('NO_CALENDAR');
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const id = await Calendar.createEventAsync(cal.id, {
    title: params.title,
    notes: params.notes,
    startDate: params.startDate,
    endDate: params.endDate,
    timeZone,
    alarms: buildCalendarEventAlarms(params.startDate, hint, cal),
  });
  return id;
}

export async function scheduleLocalReminder(params: {
  title: string;
  body: string;
  fireDate: Date;
}): Promise<string> {
  const perm = await Notifications.requestPermissionsAsync();
  if (perm.status !== 'granted') throw new Error('NOTIFICATION_DENIED');
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('todos', {
      name: '待办提醒',
      importance: Notifications.AndroidImportance.HIGH,
    });
  }
  const trigger: Notifications.DateTriggerInput = {
    type: Notifications.SchedulableTriggerInputTypes.DATE,
    date: params.fireDate,
    ...(Platform.OS === 'android' ? { channelId: 'todos' } : {}),
  };
  return Notifications.scheduleNotificationAsync({
    content: {
      title: params.title,
      body: params.body,
    },
    trigger,
  });
}

export async function copyToClipboard(text: string): Promise<void> {
  await Clipboard.setStringAsync(text);
}

export async function shareText(title: string, text: string): Promise<void> {
  await Share.share({ title, message: text });
}

/** 仅 ISO / 常见机器格式；不处理中文 */
export function parseSuggestedDate(s?: string | null): Date | null {
  if (!s?.trim()) return null;
  const raw = s.trim();
  let normalized = raw;
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?Z$/i.test(raw)) {
    normalized = raw.replace(/Z$/i, '');
  }
  const d = new Date(normalized);
  if (Number.isNaN(d.getTime())) return null;
  return d;
}

function combineLocalDayAndClock(day: Date, hour: number, minute: number): Date {
  return new Date(day.getFullYear(), day.getMonth(), day.getDate(), hour, minute, 0, 0);
}

function bumpPastToNextDayIfNeeded(candidate: Date, text: string, now: Date): Date {
  if (candidate.getTime() >= now.getTime() - 5 * 60 * 1000) return candidate;
  const next = new Date(candidate);
  next.setDate(next.getDate() + 1);
  return next;
}

const CN_DIGIT: Record<string, number> = {
  零: 0,
  一: 1,
  二: 2,
  三: 3,
  四: 4,
  五: 5,
  六: 6,
  七: 7,
  八: 8,
  九: 9,
  十: 10,
};

function cnTokenToHourOrMinute(tok: string, max: number): number | null {
  const t = tok.trim();
  if (!t) return null;
  if (t === '半') return null;
  if (/^\d+$/.test(t)) {
    const n = parseInt(t, 10);
    return n >= 0 && n <= max ? n : null;
  }
  if (t === '十') return 10;
  if (t === '十一') return 11;
  if (t === '十二') return 12;
  if (t === '二十') return 20;
  if (t === '三十') return 30;
  if (t === '四十') return 40;
  if (t === '五十') return 50;
  if (t.length === 2 && t[0] === '十') {
    const u = CN_DIGIT[t[1]];
    return u != null ? 10 + u : null;
  }
  if (t.length === 1) {
    const v = CN_DIGIT[t];
    return v != null && v <= max ? v : null;
  }
  return null;
}

const MAX_REL_MS = 48 * 60 * 60 * 1000;

/** 「10 秒后」「5 分钟」「in 20 seconds」等相对当前时刻的提醒 */
function tryRelativeOffset(text: string, now: Date): Date | null {
  const mEn = text.match(
    /\b(?:in\s+)?(\d{1,5})\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\b/i
  );
  if (mEn) {
    const n = parseInt(mEn[1], 10);
    if (n <= 0) return null;
    const u = mEn[2].toLowerCase();
    let ms = 0;
    if (/^s(ec)?/.test(u)) ms = n * 1000;
    else if (/^m(in)?/.test(u)) ms = n * 60 * 1000;
    else if (/^h(r)?/.test(u)) ms = n * 60 * 60 * 1000;
    if (ms > 0 && ms <= MAX_REL_MS) return new Date(now.getTime() + ms);
  }

  let m = text.match(/(\d{1,5})\s*(?:小时|钟头)(?:之后|以后|后)?/);
  if (m) {
    const h = parseInt(m[1], 10);
    if (h > 0 && h <= 48) return new Date(now.getTime() + h * 60 * 60 * 1000);
  }
  m = text.match(/(\d{1,5})\s*(?:分钟|分)(?:之后|以后|后|钟)?/);
  if (m) {
    const min = parseInt(m[1], 10);
    if (min > 0 && min <= 48 * 60) return new Date(now.getTime() + min * 60 * 1000);
  }
  m = text.match(/(\d{1,5})\s*(?:秒钟|秒)(?:之后|以后|后|钟)?/);
  if (m) {
    const sec = parseInt(m[1], 10);
    if (sec > 0 && sec <= 48 * 3600) return new Date(now.getTime() + sec * 1000);
  }
  m = text.match(/(\d{1,5})\s*s(?:ec(?:onds?)?)?(?:\s*钟)?(?:之后|以后|后)?(?=\s|[^\w]|$)/i);
  if (m) {
    const sec = parseInt(m[1], 10);
    if (sec > 0 && sec <= 48 * 3600) return new Date(now.getTime() + sec * 1000);
  }

  const mCnSec = text.match(/([一二三四五六七八九十]{1,3})\s*秒后/);
  if (mCnSec) {
    const sec = cnTokenToHourOrMinute(mCnSec[1], 3600);
    if (sec != null && sec > 0 && sec * 1000 <= MAX_REL_MS) return new Date(now.getTime() + sec * 1000);
  }
  const mCnMin = text.match(/([一二三四五六七八九十]{1,3})\s*分钟后/);
  if (mCnMin) {
    const min = cnTokenToHourOrMinute(mCnMin[1], 120);
    if (min != null && min > 0 && min * 60 * 1000 <= MAX_REL_MS) return new Date(now.getTime() + min * 60 * 1000);
  }

  return null;
}

/** 从待办正文 + suggestedTime 推断日程时间；避免误用「当前时间+1小时」 */
export function resolveTodoWhen(params: { content: string; suggestedTime?: string | null }, now = new Date()): Date | null {
  const textRaw = `${params.content ?? ''} ${params.suggestedTime ?? ''}`.replace(/\s+/g, ' ');
  const text = textRaw.replace(/明年(?=\s*(下午|上午|晚上|今早|今晚|明|\d))/g, '明天');

  const rel = tryRelativeOffset(text, now);
  if (rel) return rel;

  const day0 = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  let day = new Date(day0);
  if (/明天|翌日|明儿/.test(text)) day.setDate(day.getDate() + 1);
  else if (/后天/.test(text)) day.setDate(day.getDate() + 2);
  else if (/昨天|昨日/.test(text)) day.setDate(day.getDate() - 1);
  else if (/下周|下星期/.test(text)) day.setDate(day.getDate() + 7);

  const tryChinese = (): Date | null => {
    let m = text.match(/(?:下午|晚上|傍晚)\s*(\d{1,2})\s*[:：]\s*(\d{1,2})/);
    if (m) {
      let h = parseInt(m[1], 10);
      const mi = parseInt(m[2], 10);
      if (h < 12) h += 12;
      return bumpPastToNextDayIfNeeded(combineLocalDayAndClock(day, h, mi), text, now);
    }
    m = text.match(/(?:上午|早上|凌晨|清早)\s*(\d{1,2})\s*[:：]\s*(\d{1,2})/);
    if (m) {
      let h = parseInt(m[1], 10);
      const mi = parseInt(m[2], 10);
      if (h === 12) h = 0;
      return bumpPastToNextDayIfNeeded(combineLocalDayAndClock(day, h, mi), text, now);
    }
    m = text.match(/(?:下午|晚上)\s*([一二三四五六七八九十]{1,3})点半/);
    if (m) {
      const hCn = cnTokenToHourOrMinute(m[1], 12);
      if (hCn == null) return null;
      const h = hCn < 12 ? hCn + 12 : hCn;
      return bumpPastToNextDayIfNeeded(combineLocalDayAndClock(day, h, 30), text, now);
    }
    m = text.match(
      /(?:下午|晚上)\s*([一二三四五六七八九十]{1,3})\s*点(?:\s*(半|[一二三四五六七八九十]{1,3})\s*分?|\s*(半))?/
    );
    if (m) {
      const hCn = cnTokenToHourOrMinute(m[1], 12);
      if (hCn == null) return null;
      let h = hCn < 12 ? hCn + 12 : hCn;
      let mi = 0;
      if (m[2] === '半' || m[3] === '半') mi = 30;
      else if (m[2] && m[2] !== '半') {
        const mv = cnTokenToHourOrMinute(m[2], 59);
        if (mv != null) mi = mv;
      }
      return bumpPastToNextDayIfNeeded(combineLocalDayAndClock(day, h, mi), text, now);
    }
    m = text.match(
      /(?:上午|早上)\s*([一二三四五六七八九十]{1,3})\s*点(?:\s*(半|[一二三四五六七八九十]{1,3})\s*分?|\s*(半))?/
    );
    if (m) {
      let h = cnTokenToHourOrMinute(m[1], 12) ?? 0;
      if (h === 12) h = 0;
      let mi = 0;
      if (m[2] === '半' || m[3] === '半') mi = 30;
      else if (m[2] && m[2] !== '半') {
        const mv = cnTokenToHourOrMinute(m[2], 59);
        if (mv != null) mi = mv;
      }
      return bumpPastToNextDayIfNeeded(combineLocalDayAndClock(day, h, mi), text, now);
    }
    m = text.match(/(\d{1,2})\s*[:：]\s*(\d{1,2})\s*[pP]\.?\s*[mM]\.?/i);
    if (m) {
      let h = parseInt(m[1], 10);
      const mi = parseInt(m[2], 10);
      if (h < 12) h += 12;
      return bumpPastToNextDayIfNeeded(combineLocalDayAndClock(day, h, mi), text, now);
    }
    m = text.match(/(\d{1,2})\s*[:：]\s*(\d{1,2})\s*(?:下午)/);
    if (m) {
      let h = parseInt(m[1], 10);
      const mi = parseInt(m[2], 10);
      if (h < 12) h += 12;
      return bumpPastToNextDayIfNeeded(combineLocalDayAndClock(day, h, mi), text, now);
    }
    m = text.match(/(\d{1,2})\s*[:：]\s*(\d{1,2})\s*(?:a\.?\s*m\.?|上午)/i);
    if (m) {
      let h = parseInt(m[1], 10);
      const mi = parseInt(m[2], 10);
      if (h === 12) h = 0;
      return bumpPastToNextDayIfNeeded(combineLocalDayAndClock(day, h, mi), text, now);
    }
    return null;
  };

  const cn = tryChinese();
  if (cn) return cn;

  const isoFromSuggested = parseSuggestedDate(params.suggestedTime);
  if (isoFromSuggested && isoFromSuggested.getTime() >= now.getTime() - 60 * 60 * 1000) {
    return isoFromSuggested;
  }

  const isoInContent = text.match(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?([Z+-]\d{2}:?\d{2})?/);
  if (isoInContent) {
    const d2 = parseSuggestedDate(isoInContent[0]);
    if (d2 && d2.getTime() >= now.getTime() - 60 * 60 * 1000) return d2;
  }

  return null;
}
