import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useApp } from '../context/AppContext';
import { t } from '../i18n/strings';
import { colors } from '../theme/colors';
import type { MainTabParamList } from '../navigation/types';
import type { RootStackParamList } from '../navigation/types';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

type Props = BottomTabScreenProps<MainTabParamList, 'Home'>;

export function HomeScreen({ navigation }: Props) {
  const { settings } = useApp();
  const lang = settings.uiLanguage;
  const openRecording = () => {
    const parent = navigation.getParent<NativeStackNavigationProp<RootStackParamList>>();
    parent?.navigate('Recording');
  };
  return (
    <View style={styles.wrap}>
      <Text style={styles.title}>{t(lang, 'appName')}</Text>
      <Text style={styles.sub}>{t(lang, 'liveHint')}</Text>
      <Pressable
        style={({ pressed }) => [styles.recordBtn, pressed && styles.recordBtnPressed]}
        onPress={openRecording}
      >
        <View style={styles.innerCircle} />
        <Text style={styles.btnLabel}>{t(lang, 'startRecord')}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flex: 1,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.primary,
    marginBottom: 8,
  },
  sub: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 40,
    lineHeight: 20,
  },
  recordBtn: {
    width: 168,
    height: 168,
    borderRadius: 84,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  recordBtnPressed: { opacity: 0.92 },
  innerCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: colors.surface,
    marginBottom: 10,
  },
  btnLabel: {
    color: colors.surface,
    fontSize: 15,
    fontWeight: '600',
  },
});
