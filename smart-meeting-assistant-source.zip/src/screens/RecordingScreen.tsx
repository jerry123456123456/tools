import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { randomUUID } from 'expo-crypto';
import { useCallback, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Waveform } from '../components/Waveform';
import { useApp } from '../context/AppContext';
import { insertMeeting, insertTodos, updateMeeting } from '../db/meetingRepository';
import { t } from '../i18n/strings';
import { emptyMinutes, generateMinutesAndTodos } from '../services/aiMinutesService';
import {
  getActiveRecording,
  pauseRecording,
  persistRecording,
  resumeRecording,
  startRecording,
  stopRecording,
} from '../services/recordingService';
import { transcribeWithDashScope } from '../services/dashscopeAsrService';
import { colors } from '../theme/colors';
import type { Meeting, MeetingLanguage, TodoItem } from '../types';
import type { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'Recording'>;

type Marker = { t: number; label: string };

export function RecordingScreen({ navigation }: Props) {
  const { settings } = useApp();
  const lang = settings.uiLanguage;
  const [phase, setPhase] = useState<'idle' | 'recording' | 'processing'>('idle');
  const [metering, setMetering] = useState(-160);
  const [elapsed, setElapsed] = useState(0);
  const [liveLine, setLiveLine] = useState('');
  const [markers, setMarkers] = useState<Marker[]>([]);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const meetingIdRef = useRef<string>('');

  const clearTick = () => {
    if (tickRef.current) clearInterval(tickRef.current);
    tickRef.current = null;
  };

  const beginRecording = useCallback(async () => {
    try {
      meetingIdRef.current = randomUUID();
      setMarkers([]);
      setElapsed(0);
      setLiveLine(settings.privacyLocalOnly ? t(lang, 'privacyNoCloud') : t(lang, 'liveHint'));
      await startRecording((db) => setMetering(db));
      setPhase('recording');
      const started = Date.now();
      tickRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - started) / 1000));
      }, 500);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg === 'MIC_DENIED') Alert.alert(t(lang, 'error'), t(lang, 'permissionMic'));
      else Alert.alert(t(lang, 'error'), msg);
    }
  }, [lang, settings.privacyLocalOnly]);

  const onPause = async () => {
    await pauseRecording();
    clearTick();
  };

  const onResume = async () => {
    await resumeRecording();
    const started = Date.now() - elapsed * 1000;
    tickRef.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - started) / 1000));
    }, 500);
  };

  const onMark = () => {
    const rec = getActiveRecording();
    const tMs = elapsed * 1000;
    setMarkers((m) => [...m, { t: tMs, label: `重点 ${m.length + 1}` }]);
  };

  const formatClock = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const finalize = async () => {
    setPhase('processing');
    clearTick();
    const id = meetingIdRef.current;
    const { uri, durationMillis } = await stopRecording();
    const durationSec = Math.max(1, Math.round(durationMillis / 1000));
    const storedUri = await persistRecording(uri, id);
    const meetingLanguage: MeetingLanguage = 'auto';
    const now = Date.now();
    const base: Meeting = {
      id,
      title: `${t(lang, 'recording')} ${new Date(now).toLocaleString()}`,
      createdAt: now,
      updatedAt: now,
      transcript: '',
      minutesJson: JSON.stringify(emptyMinutes('')),
      audioUri: storedUri,
      durationSec,
      language: meetingLanguage,
      markersJson: JSON.stringify(markers),
    };
    await insertMeeting(base);

    let transcript = '';
    try {
      if (!settings.privacyLocalOnly && settings.dashscopeApiKey.trim() && storedUri) {
        transcript = await transcribeWithDashScope({
          apiKey: settings.dashscopeApiKey.trim(),
          fileUri: storedUri,
          language: meetingLanguage === 'auto' ? undefined : meetingLanguage,
          quality: settings.asrQuality,
        });
      }
    } catch (e) {
      transcript = `[转写失败] ${e instanceof Error ? e.message : String(e)}`;
    }

    let minutesJson = JSON.stringify(emptyMinutes(transcript));
    const todoRows: TodoItem[] = [];
    try {
      if (!settings.privacyLocalOnly && settings.dashscopeApiKey.trim() && transcript.trim()) {
        const bundle = await generateMinutesAndTodos({
          apiKey: settings.dashscopeApiKey.trim(),
          transcript,
          style: settings.aiStyle,
          meetingLanguage,
        });
        minutesJson = JSON.stringify(bundle.minutes);
        for (const td of bundle.todos) {
          if (!td.content.trim()) continue;
          todoRows.push({
            id: randomUUID(),
            meetingId: id,
            content: td.content.trim(),
            priority: td.priority,
            suggestedTime: td.suggestedTime?.trim() || null,
            done: 0,
          });
        }
      }
    } catch (e) {
      minutesJson = JSON.stringify({
        ...emptyMinutes(transcript),
        summary: `${emptyMinutes(transcript).summary} AI:${e instanceof Error ? e.message : ''}`,
      });
    }

    const titleFromJson = (() => {
      try {
        const m = JSON.parse(minutesJson) as { summary?: string };
        const line = m.summary?.split('\n')[0]?.trim();
        if (line && line.length > 2) return line.slice(0, 48);
      } catch {
        /* ignore */
      }
      return base.title;
    })();

    await updateMeeting({
      id,
      transcript,
      minutesJson,
      title: titleFromJson,
      updatedAt: Date.now(),
    });
    if (todoRows.length) await insertTodos(todoRows);

    if (settings.autoSync && todoRows.length && !settings.privacyLocalOnly) {
      /* 用户可在纪要页一键同步；此处仅保留开关语义，避免未授权批量写入 */
    }

    navigation.replace('MeetingDetail', { meetingId: id });
  };

  const onStop = () => {
    Alert.alert(
      lang === 'zh' ? '结束录制' : 'Stop',
      lang === 'zh' ? '将保存录音并生成纪要。' : 'Save audio and generate minutes?',
      [
        { text: lang === 'zh' ? '取消' : 'Cancel', style: 'cancel' },
        { text: lang === 'zh' ? '确定' : 'OK', onPress: () => void finalize() },
      ]
    );
  };

  return (
    <View style={styles.root}>
      {phase === 'processing' ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.proc}>{t(lang, 'transcribing')}</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scroll}>
          <Waveform metering={phase === 'recording' ? metering : -160} />
          <Text style={styles.clock}>{formatClock(elapsed)}</Text>
          <View style={styles.captionBox}>
            <Text style={styles.captionTitle}>{lang === 'zh' ? '实时字幕 / 提示' : 'Live / hint'}</Text>
            <Text style={styles.caption}>{liveLine}</Text>
          </View>
          {markers.length > 0 && (
            <View style={styles.markBox}>
              <Text style={styles.markTitle}>{t(lang, 'markKey')}</Text>
              {markers.map((mk, i) => (
                <Text key={i} style={styles.markItem}>
                  {formatClock(Math.floor(mk.t / 1000))} — {mk.label}
                </Text>
              ))}
            </View>
          )}
          <View style={styles.row}>
            {phase === 'idle' ? (
              <Pressable style={styles.primaryBtn} onPress={() => void beginRecording()}>
                <Text style={styles.primaryTxt}>{t(lang, 'startRecord')}</Text>
              </Pressable>
            ) : (
              <>
                <Pressable style={styles.secondaryBtn} onPress={() => void onPause()}>
                  <Text style={styles.secondaryTxt}>{t(lang, 'pause')}</Text>
                </Pressable>
                <Pressable style={styles.secondaryBtn} onPress={() => void onResume()}>
                  <Text style={styles.secondaryTxt}>{t(lang, 'resume')}</Text>
                </Pressable>
                <Pressable style={styles.secondaryBtn} onPress={onMark}>
                  <Text style={styles.secondaryTxt}>{t(lang, 'markKey')}</Text>
                </Pressable>
                <Pressable style={styles.dangerBtn} onPress={onStop}>
                  <Text style={styles.primaryTxt}>{t(lang, 'stopAndSave')}</Text>
                </Pressable>
              </>
            )}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  scroll: { padding: 20, paddingBottom: 40, gap: 16 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  proc: { color: colors.textSecondary, marginTop: 8 },
  clock: { fontSize: 36, fontWeight: '200', color: colors.primary, textAlign: 'center' },
  captionBox: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: colors.border,
  },
  captionTitle: { fontSize: 12, color: colors.textSecondary, marginBottom: 6 },
  caption: { fontSize: 15, color: colors.text, lineHeight: 22 },
  markBox: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  markTitle: { fontWeight: '600', color: colors.primary, marginBottom: 6 },
  markItem: { color: colors.textSecondary, fontSize: 13, marginBottom: 4 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'center', marginTop: 12 },
  primaryBtn: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    paddingHorizontal: 28,
    borderRadius: 10,
  },
  primaryTxt: { color: colors.surface, fontWeight: '600' },
  secondaryBtn: {
    borderWidth: 1,
    borderColor: colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 10,
    backgroundColor: colors.surface,
  },
  secondaryTxt: { color: colors.primary, fontWeight: '600' },
  dangerBtn: {
    backgroundColor: colors.danger,
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: 10,
  },
});
