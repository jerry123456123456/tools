import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Audio } from 'expo-av';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { deleteMeeting, getMeeting, listTodosForMeeting, updateMeeting } from '../db/meetingRepository';
import { useApp } from '../context/AppContext';
import { t } from '../i18n/strings';
import { playUri } from '../services/recordingService';
import {
  addCalendarEvent,
  copyToClipboard,
  createSystemReminder,
  resolveTodoWhen,
} from '../services/syncService';
import { colors } from '../theme/colors';
import type { MinutesStructure, Meeting, TodoItem } from '../types';
import type { RootStackParamList } from '../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'MeetingDetail'>;

export function MeetingDetailScreen({ route, navigation }: Props) {
  const { meetingId } = route.params;
  const { settings } = useApp();
  const lang = settings.uiLanguage;
  const [meeting, setMeeting] = useState<Meeting | null>(null);
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [titleDraft, setTitleDraft] = useState('');
  const soundRef = useRef<Audio.Sound | null>(null);

  const load = useCallback(async () => {
    const m = await getMeeting(meetingId);
    setMeeting(m);
    setTitleDraft(m?.title ?? '');
    setTodos(await listTodosForMeeting(meetingId));
  }, [meetingId]);

  useFocusEffect(
    useCallback(() => {
      void load();
    }, [load])
  );

  useEffect(
    () => () => {
      void soundRef.current?.unloadAsync();
    },
    []
  );

  const saveTitle = async () => {
    if (!meeting) return;
    await updateMeeting({ id: meeting.id, title: titleDraft, updatedAt: Date.now() });
    await load();
  };

  const play = async () => {
    if (!meeting?.audioUri) return;
    try {
      await soundRef.current?.unloadAsync();
      soundRef.current = await playUri(meeting.audioUri);
    } catch (e) {
      Alert.alert(t(lang, 'error'), e instanceof Error ? e.message : String(e));
    }
  };

  let minutes: MinutesStructure | null = null;
  try {
    minutes = meeting ? (JSON.parse(meeting.minutesJson) as MinutesStructure) : null;
  } catch {
    minutes = null;
  }

  const exportText = () => {
    if (!meeting || !minutes) return '';
    const parts = [
      meeting.title,
      '',
      '---',
      minutes.summary,
      '',
      ...(minutes.outline?.map((o) => o) ?? []),
    ];
    return parts.join('\n');
  };

  const onExport = async () => {
    const txt = exportText();
    await Share.share({ message: txt, title: meeting?.title });
  };

  const onDeleteMeeting = () => {
    Alert.alert(
      t(lang, 'deleteMeeting'),
      t(lang, 'deleteMeetingConfirm'),
      [
        { text: lang === 'zh' ? '取消' : 'Cancel', style: 'cancel' },
        {
          text: t(lang, 'deleteMeetingOk'),
          style: 'destructive',
          onPress: () => {
            void (async () => {
              try {
                await deleteMeeting(meetingId);
                navigation.navigate('Main', { screen: 'History' });
              } catch (e) {
                Alert.alert(t(lang, 'error'), e instanceof Error ? e.message : String(e));
              }
            })();
          },
        },
      ]
    );
  };

  const syncAll = async () => {
    const skipped: string[] = [];
    const errors: string[] = [];
    for (const td of todos) {
      if (td.done) continue;
      const when = resolveTodoWhen({ content: td.content, suggestedTime: td.suggestedTime });
      if (!when) {
        skipped.push(td.content);
        continue;
      }
      try {
        const end = new Date(when.getTime() + 30 * 60000);
        await addCalendarEvent({
          title: td.content,
          notes: meeting?.title,
          startDate: when,
          endDate: end,
          sourceTextForReminder: `${td.content} ${meeting?.title ?? ''}`,
        });
        await createSystemReminder({
          title: td.content,
          dueDate: when,
          sourceTextForReminder: `${td.content} ${meeting?.title ?? ''}`,
        });
      } catch (e) {
        errors.push(`${td.content.slice(0, 20)}… ${e instanceof Error ? e.message : String(e)}`);
      }
    }
    const parts: string[] = [];
    if (skipped.length) {
      parts.push(
        lang === 'zh'
          ? `未解析到时间的待办已跳过（请补充具体时间或编辑待办）：\n${skipped.join('\n')}`
          : `Skipped (no parseable time):\n${skipped.join('\n')}`
      );
    }
    if (errors.length) {
      parts.push(lang === 'zh' ? `部分失败：\n${errors.join('\n')}` : `Some failed:\n${errors.join('\n')}`);
    }
    if (!parts.length) {
      parts.push(lang === 'zh' ? '已同步到日历与提醒（需系统授权）' : 'Synced to calendar & reminders');
    }
    Alert.alert('', parts.join('\n\n'));
  };

  if (!meeting) {
    return (
      <View style={styles.center}>
        <Text style={styles.muted}>…</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.pad}>
      <TextInput style={styles.titleIn} value={titleDraft} onChangeText={setTitleDraft} onEndEditing={() => void saveTitle()} />
      <View style={styles.row}>
        {meeting.audioUri ? (
          <Pressable style={styles.btn} onPress={() => void play()}>
            <Text style={styles.btnTxt}>{lang === 'zh' ? '播放录音' : 'Play'}</Text>
          </Pressable>
        ) : null}
        <Pressable style={styles.btn} onPress={() => void onExport()}>
          <Text style={styles.btnTxt}>{t(lang, 'exportMinutes')}</Text>
        </Pressable>
        <Pressable style={styles.btn} onPress={() => void copyToClipboard(exportText())}>
          <Text style={styles.btnTxt}>{t(lang, 'copyMemo')}</Text>
        </Pressable>
        <Pressable style={styles.btnDanger} onPress={onDeleteMeeting}>
          <Text style={styles.btnTxt}>{t(lang, 'deleteMeeting')}</Text>
        </Pressable>
      </View>
      {minutes && (
        <>
          <Section title={lang === 'zh' ? '摘要' : 'Summary'} body={minutes.summary} />
          <BulletSection title={lang === 'zh' ? '大纲' : 'Outline'} items={minutes.outline} />
          <BulletSection title={lang === 'zh' ? '结论' : 'Conclusions'} items={minutes.conclusions} />
          <BulletSection title={lang === 'zh' ? '决策' : 'Decisions'} items={minutes.decisions} />
          <BulletSection title={lang === 'zh' ? '问题' : 'Issues'} items={minutes.issues} />
          <BulletSection title={lang === 'zh' ? '重点' : 'Highlights'} items={minutes.highlights} />
        </>
      )}
      <Text style={styles.h2}>{t(lang, 'transcript')}</Text>
      <Text style={styles.block}>{minutes?.diarizedTranscript || meeting.transcript || '—'}</Text>
      <View style={styles.todoHead}>
        <Text style={styles.h2}>{t(lang, 'todos')}</Text>
        {todos.length > 0 && (
          <Pressable style={styles.syncAll} onPress={() => void syncAll()}>
            <Text style={styles.syncAllTxt}>{lang === 'zh' ? '一键同步全部' : 'Sync all'}</Text>
          </Pressable>
        )}
      </View>
      {todos.map((td) => (
        <View key={td.id} style={styles.todoCard}>
          <Text style={styles.todoTxt}>{td.content}</Text>
          <Text style={styles.meta}>
            {td.priority} {td.suggestedTime ? `· ${td.suggestedTime}` : ''}
          </Text>
        </View>
      ))}
    </ScrollView>
  );
}

function Section({ title, body }: { title: string; body: string }) {
  return (
    <View style={styles.section}>
      <Text style={styles.h2}>{title}</Text>
      <Text style={styles.block}>{body}</Text>
    </View>
  );
}

function BulletSection({ title, items }: { title: string; items: string[] }) {
  if (!items?.length) return null;
  return (
    <View style={styles.section}>
      <Text style={styles.h2}>{title}</Text>
      {items.map((x, i) => (
        <Text key={i} style={styles.li}>
          • {x}
        </Text>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  pad: { padding: 16, paddingBottom: 48 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  muted: { color: colors.textSecondary },
  titleIn: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    padding: 12,
    backgroundColor: colors.surface,
    marginBottom: 12,
  },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  btn: {
    backgroundColor: colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  btnTxt: { color: colors.surface, fontWeight: '600', fontSize: 13 },
  btnDanger: {
    backgroundColor: colors.danger,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  section: { marginBottom: 14 },
  h2: { fontSize: 16, fontWeight: '700', color: colors.primary, marginBottom: 6 },
  block: { fontSize: 15, color: colors.text, lineHeight: 24 },
  li: { fontSize: 14, color: colors.text, lineHeight: 22, marginBottom: 4 },
  todoHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  syncAll: { padding: 8, backgroundColor: colors.accent, borderRadius: 8 },
  syncAllTxt: { color: colors.primary, fontWeight: '700', fontSize: 12 },
  todoCard: {
    backgroundColor: colors.surface,
    padding: 12,
    borderRadius: 10,
    marginTop: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  todoTxt: { fontSize: 15, color: colors.text },
  meta: { fontSize: 12, color: colors.textSecondary, marginTop: 4 },
});
