import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useCallback, useState } from 'react';
import {
  Alert,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { deleteTodo, listTodos, updateTodo } from '../db/meetingRepository';
import { useApp } from '../context/AppContext';
import { t } from '../i18n/strings';
import {
  addCalendarEvent,
  copyToClipboard,
  createSystemReminder,
  resolveTodoWhen,
  shareText,
} from '../services/syncService';
import { colors } from '../theme/colors';
import type { MainTabParamList, RootStackParamList } from '../navigation/types';
import type { TodoItem } from '../types';

type Props = BottomTabScreenProps<MainTabParamList, 'Todos'>;

function priorityLabel(lang: 'zh' | 'en', p: TodoItem['priority']) {
  if (p === 'high') return t(lang, 'priorityHigh');
  if (p === 'low') return t(lang, 'priorityLow');
  return t(lang, 'priorityMedium');
}

export function TodosScreen({ navigation }: Props) {
  const { settings } = useApp();
  const lang = settings.uiLanguage;
  const [rows, setRows] = useState<TodoItem[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [draft, setDraft] = useState('');

  const load = useCallback(async () => {
    setRows(await listTodos());
  }, []);

  useFocusEffect(
    useCallback(() => {
      void load();
    }, [load])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const toggleDone = async (item: TodoItem) => {
    await updateTodo(item.id, { done: item.done ? 0 : 1 });
    await load();
  };

  const saveEdit = async (id: string) => {
    await updateTodo(id, { content: draft });
    setEditing(null);
    await load();
  };

  const remove = (id: string) => {
    Alert.alert(lang === 'zh' ? '删除' : 'Delete', lang === 'zh' ? '确定删除该待办？' : 'Remove this task?', [
      { text: lang === 'zh' ? '取消' : 'Cancel', style: 'cancel' },
      {
        text: lang === 'zh' ? '删除' : 'Delete',
        style: 'destructive',
        onPress: async () => {
          await deleteTodo(id);
          await load();
        },
      },
    ]);
  };

  const syncRow = async (item: TodoItem, kind: 'cal' | 'rem' | 'copy' | 'share') => {
    try {
      if (kind === 'copy') {
        await copyToClipboard(item.content);
        Alert.alert('', lang === 'zh' ? '已复制' : 'Copied');
        return;
      }
      if (kind === 'share') {
        await shareText(item.content, item.content);
        return;
      }
      const when = resolveTodoWhen({ content: item.content, suggestedTime: item.suggestedTime });
      if (!when) {
        Alert.alert(
          t(lang, 'error'),
          lang === 'zh'
            ? '无法从待办中解析出时间（请写清「明天下午3:30」等，或编辑待办补充 suggestedTime）。'
            : 'Could not parse a date/time from this task.'
        );
        return;
      }
      const end = new Date(when.getTime() + 30 * 60000);
      if (kind === 'cal') {
        await addCalendarEvent({
          title: item.content,
          notes: `来自智能会议纪要\n会议: ${item.meetingId}`,
          startDate: when,
          endDate: end,
          sourceTextForReminder: item.content,
        });
        Alert.alert('', lang === 'zh' ? '已写入日历' : 'Calendar event created');
      }
      if (kind === 'rem') {
        await createSystemReminder({
          title: item.content,
          dueDate: when,
          sourceTextForReminder: item.content,
        });
        Alert.alert(
          '',
          lang === 'zh'
            ? '已安排通知提醒；若弹出系统「时钟」，请确认保存闹钟。'
            : 'Notification scheduled; confirm the alarm in Clock if it opens.'
        );
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      Alert.alert(t(lang, 'error'), msg);
    }
  };

  const goMeeting = (meetingId: string) => {
    navigation.getParent<NativeStackNavigationProp<RootStackParamList>>()?.navigate('MeetingDetail', {
      meetingId,
    });
  };

  return (
    <FlatList
      data={rows}
      keyExtractor={(x) => x.id}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void onRefresh()} />}
      contentContainerStyle={styles.list}
      renderItem={({ item }) => (
        <View style={[styles.card, item.done ? styles.doneCard : undefined]}>
          <Pressable onPress={() => toggleDone(item)} style={styles.check}>
            <Text style={styles.checkTxt}>{item.done ? '✓' : '○'}</Text>
          </Pressable>
          <View style={styles.body}>
            {editing === item.id ? (
              <TextInput
                style={styles.input}
                value={draft}
                onChangeText={setDraft}
                onBlur={() => void saveEdit(item.id)}
              />
            ) : (
              <Pressable onPress={() => goMeeting(item.meetingId)}>
                <Text style={[styles.content, item.done ? styles.doneTxt : undefined]}>{item.content}</Text>
              </Pressable>
            )}
            <Text style={styles.meta}>
              {priorityLabel(lang, item.priority)}
              {item.suggestedTime ? ` · ${t(lang, 'suggestedTime')}: ${item.suggestedTime}` : ''}
            </Text>
            <View style={styles.actions}>
              <MiniBtn label={t(lang, 'syncCalendar')} onPress={() => void syncRow(item, 'cal')} />
              <MiniBtn label={t(lang, 'syncReminder')} onPress={() => void syncRow(item, 'rem')} />
              <MiniBtn label={t(lang, 'copyMemo')} onPress={() => void syncRow(item, 'copy')} />
              <MiniBtn label={t(lang, 'share')} onPress={() => void syncRow(item, 'share')} />
              <MiniBtn
                label={lang === 'zh' ? '编辑' : 'Edit'}
                onPress={() => {
                  setEditing(item.id);
                  setDraft(item.content);
                }}
              />
              <MiniBtn label={lang === 'zh' ? '删' : 'Del'} onPress={() => remove(item.id)} danger />
            </View>
          </View>
        </View>
      )}
    />
  );
}

function MiniBtn({
  label,
  onPress,
  danger,
}: {
  label: string;
  onPress: () => void;
  danger?: boolean;
}) {
  return (
    <Pressable onPress={onPress} style={[styles.mini, danger && styles.miniDanger]}>
      <Text style={[styles.miniTxt, danger && styles.miniTxtDanger]} numberOfLines={1}>
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  list: { padding: 12, paddingBottom: 40, backgroundColor: colors.background },
  card: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  doneCard: { opacity: 0.65 },
  check: { width: 36, alignItems: 'center', justifyContent: 'flex-start', paddingTop: 4 },
  checkTxt: { fontSize: 22, color: colors.primary },
  body: { flex: 1 },
  content: { fontSize: 15, color: colors.text, lineHeight: 22 },
  doneTxt: { textDecorationLine: 'line-through', color: colors.textSecondary },
  meta: { fontSize: 12, color: colors.textSecondary, marginTop: 4 },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  mini: {
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    maxWidth: '48%',
  },
  miniDanger: { borderColor: colors.danger },
  miniTxt: { fontSize: 11, color: colors.primary },
  miniTxtDanger: { color: colors.danger },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 8,
    color: colors.text,
  },
});
