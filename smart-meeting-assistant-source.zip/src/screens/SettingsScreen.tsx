import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { useCallback, useState, type ReactNode } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useApp } from '../context/AppContext';
import { t } from '../i18n/strings';
import { colors } from '../theme/colors';
import type { MainTabParamList } from '../navigation/types';
import type { AiStyle, AsrQuality } from '../types';

type Props = BottomTabScreenProps<MainTabParamList, 'Settings'>;

export function SettingsScreen(_props: Props) {
  const { settings, saveSettings } = useApp();
  const lang = settings.uiLanguage;
  const [draft, setDraft] = useState(settings);

  useFocusEffect(
    useCallback(() => {
      setDraft(settings);
    }, [settings])
  );

  const row = (label: string, child: ReactNode) => (
    <View style={styles.row}>
      <Text style={styles.label}>{label}</Text>
      {child}
    </View>
  );

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.pad}>
      {row(t(lang, 'languageUi'), (
        <View style={styles.toggleRow}>
          <Chip active={draft.uiLanguage === 'zh'} label="中文" onPress={() => setDraft({ ...draft, uiLanguage: 'zh' })} />
          <Chip active={draft.uiLanguage === 'en'} label="EN" onPress={() => setDraft({ ...draft, uiLanguage: 'en' })} />
        </View>
      ))}
      {row(t(lang, 'asrQuality'), (
        <View style={styles.toggleRow}>
          <Chip
            active={draft.asrQuality === 'standard'}
            label={lang === 'zh' ? '标准' : 'Std'}
            onPress={() => setDraft({ ...draft, asrQuality: 'standard' as AsrQuality })}
          />
          <Chip
            active={draft.asrQuality === 'high'}
            label={lang === 'zh' ? '高' : 'High'}
            onPress={() => setDraft({ ...draft, asrQuality: 'high' as AsrQuality })}
          />
        </View>
      ))}
      {row(t(lang, 'aiStyle'), (
        <View style={styles.toggleRow}>
          <Chip
            active={draft.aiStyle === 'concise'}
            label={lang === 'zh' ? '简洁' : 'Short'}
            onPress={() => setDraft({ ...draft, aiStyle: 'concise' as AiStyle })}
          />
          <Chip
            active={draft.aiStyle === 'detailed'}
            label={lang === 'zh' ? '详细' : 'Long'}
            onPress={() => setDraft({ ...draft, aiStyle: 'detailed' as AiStyle })}
          />
          <Chip
            active={draft.aiStyle === 'professional'}
            label={lang === 'zh' ? '专业' : 'Pro'}
            onPress={() => setDraft({ ...draft, aiStyle: 'professional' as AiStyle })}
          />
        </View>
      ))}
      {row(t(lang, 'autoSync'), (
        <Switch value={draft.autoSync} onValueChange={(v) => setDraft({ ...draft, autoSync: v })} />
      ))}
      {row(t(lang, 'privacy'), (
        <Switch value={draft.privacyLocalOnly} onValueChange={(v) => setDraft({ ...draft, privacyLocalOnly: v })} />
      ))}
      <Text style={styles.hint}>{t(lang, 'apiKey')}</Text>
      <TextInput
        style={styles.input}
        secureTextEntry
        value={draft.dashscopeApiKey}
        onChangeText={(dashscopeApiKey) => setDraft({ ...draft, dashscopeApiKey })}
        placeholder={lang === 'zh' ? 'sk-…（百炼控制台创建）' : 'sk-…'}
        placeholderTextColor={colors.textSecondary}
      />
      <Pressable
        style={styles.save}
        onPress={() => {
          void (async () => {
            try {
              await saveSettings(draft);
              Alert.alert('', t(lang, 'settingsSaved'));
            } catch (e) {
              Alert.alert(t(lang, 'error'), e instanceof Error ? e.message : String(e));
            }
          })();
        }}
      >
        <Text style={styles.saveTxt}>{t(lang, 'saveSettings')}</Text>
      </Pressable>
    </ScrollView>
  );
}

function Chip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.chip, active && styles.chipOn]}>
      <Text style={[styles.chipTxt, active && styles.chipTxtOn]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  pad: { padding: 16, paddingBottom: 40 },
  row: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 10,
  },
  label: { fontSize: 15, fontWeight: '600', color: colors.text },
  toggleRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.background,
  },
  chipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipTxt: { color: colors.primary, fontWeight: '600' },
  chipTxtOn: { color: colors.surface },
  hint: { fontSize: 13, color: colors.textSecondary, marginBottom: 6 },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    padding: 12,
    backgroundColor: colors.surface,
    color: colors.text,
    marginBottom: 20,
  },
  save: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  saveTxt: { color: colors.surface, fontWeight: '700', fontSize: 16 },
});
