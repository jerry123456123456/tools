import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useCallback, useEffect, useState } from 'react';
import {
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { listMeetings } from '../db/meetingRepository';
import { useApp } from '../context/AppContext';
import { t } from '../i18n/strings';
import { colors } from '../theme/colors';
import type { MainTabParamList, RootStackParamList } from '../navigation/types';
import type { Meeting } from '../types';

type Props = BottomTabScreenProps<MainTabParamList, 'History'>;

export function HistoryScreen({ navigation }: Props) {
  const { settings } = useApp();
  const lang = settings.uiLanguage;
  const [q, setQ] = useState('');
  const [rows, setRows] = useState<Meeting[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    setRows(await listMeetings(q));
  }, [q]);

  useFocusEffect(
    useCallback(() => {
      void load();
    }, [load])
  );

  useEffect(() => {
    const id = setTimeout(() => void load(), 400);
    return () => clearTimeout(id);
  }, [q, load]);

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const openDetail = (id: string) => {
    navigation.getParent<NativeStackNavigationProp<RootStackParamList>>()?.navigate('MeetingDetail', {
      meetingId: id,
    });
  };

  return (
    <View style={styles.root}>
      <TextInput
        style={styles.search}
        placeholder={t(lang, 'search')}
        placeholderTextColor={colors.textSecondary}
        value={q}
        onChangeText={setQ}
        onSubmitEditing={() => void load()}
        returnKeyType="search"
      />
      <FlatList
        data={rows}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void onRefresh()} />}
        ListEmptyComponent={
          <Text style={styles.empty}>{t(lang, 'noMeetings')}</Text>
        }
        renderItem={({ item }) => (
          <Pressable style={styles.card} onPress={() => openDetail(item.id)}>
            <Text style={styles.cardTitle}>{item.title}</Text>
            <Text style={styles.meta}>
              {new Date(item.updatedAt).toLocaleString()} · {Math.floor(item.durationSec / 60)}m
            </Text>
          </Pressable>
        )}
        contentContainerStyle={styles.list}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  search: {
    margin: 12,
    padding: 12,
    borderRadius: 10,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.text,
  },
  list: { paddingHorizontal: 12, paddingBottom: 24 },
  card: {
    backgroundColor: colors.surface,
    padding: 14,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardTitle: { fontSize: 16, fontWeight: '600', color: colors.text },
  meta: { marginTop: 6, fontSize: 12, color: colors.textSecondary },
  empty: { textAlign: 'center', color: colors.textSecondary, marginTop: 40, paddingHorizontal: 24 },
});
