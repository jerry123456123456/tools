import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { colors } from '../theme/colors';
import { useApp } from '../context/AppContext';
import { t } from '../i18n/strings';
import type { MainTabParamList, RootStackParamList } from './types';
import { HomeScreen } from '../screens/HomeScreen';
import { HistoryScreen } from '../screens/HistoryScreen';
import { TodosScreen } from '../screens/TodosScreen';
import { SettingsScreen } from '../screens/SettingsScreen';
import { RecordingScreen } from '../screens/RecordingScreen';
import { MeetingDetailScreen } from '../screens/MeetingDetailScreen';

const RootStack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();

const navTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: colors.background,
    primary: colors.primary,
    card: colors.surface,
    text: colors.text,
    border: colors.border,
  },
};

function MainTabs() {
  const { settings } = useApp();
  const lang = settings.uiLanguage;
  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: colors.surface },
        headerTintColor: colors.primary,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: t(lang, 'tabHome'),
          tabBarLabel: t(lang, 'tabHome'),
          tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 18 }}>●</Text>,
        }}
      />
      <Tab.Screen
        name="History"
        component={HistoryScreen}
        options={{
          title: t(lang, 'tabHistory'),
          tabBarLabel: t(lang, 'tabHistory'),
          tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 18 }}>≡</Text>,
        }}
      />
      <Tab.Screen
        name="Todos"
        component={TodosScreen}
        options={{
          title: t(lang, 'tabTodos'),
          tabBarLabel: t(lang, 'tabTodos'),
          tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 18 }}>☑</Text>,
        }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          title: t(lang, 'tabSettings'),
          tabBarLabel: t(lang, 'tabSettings'),
          tabBarIcon: ({ color }) => <Text style={{ color, fontSize: 18 }}>⚙</Text>,
        }}
      />
    </Tab.Navigator>
  );
}

export function RootNavigator() {
  const { settings } = useApp();
  const lang = settings.uiLanguage;
  return (
    <NavigationContainer theme={navTheme}>
      <RootStack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: colors.surface },
          headerTintColor: colors.primary,
          contentStyle: { backgroundColor: colors.background },
        }}
      >
        <RootStack.Screen name="Main" component={MainTabs} options={{ headerShown: false }} />
        <RootStack.Screen
          name="Recording"
          component={RecordingScreen}
          options={{
            title: t(lang, 'recording'),
            presentation: 'fullScreenModal',
          }}
        />
        <RootStack.Screen name="MeetingDetail" component={MeetingDetailScreen} options={{ title: t(lang, 'minutes') }} />
      </RootStack.Navigator>
    </NavigationContainer>
  );
}
