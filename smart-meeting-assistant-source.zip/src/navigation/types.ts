export type MainTabParamList = {
  Home: undefined;
  History: undefined;
  Todos: undefined;
  Settings: undefined;
};

export type RootStackParamList = {
  Main: { screen?: keyof MainTabParamList } | undefined;
  Recording: undefined;
  MeetingDetail: { meetingId: string };
};
