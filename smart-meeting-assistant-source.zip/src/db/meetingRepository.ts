import * as FileSystem from 'expo-file-system/legacy';
import type { Meeting, TodoItem } from '../types';
import { getDatabase } from './database';

export async function insertMeeting(m: Meeting): Promise<void> {
  const db = await getDatabase();
  await db.runAsync(
    `INSERT INTO meetings (id, title, created_at, updated_at, transcript, minutes_json, audio_uri, duration_sec, language, markers_json)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      m.id,
      m.title,
      m.createdAt,
      m.updatedAt,
      m.transcript,
      m.minutesJson,
      m.audioUri,
      m.durationSec,
      m.language,
      m.markersJson,
    ]
  );
}

export async function updateMeeting(m: Partial<Meeting> & { id: string }): Promise<void> {
  const db = await getDatabase();
  const fields: string[] = [];
  const values: (string | number | null)[] = [];
  if (m.title !== undefined) {
    fields.push('title = ?');
    values.push(m.title);
  }
  if (m.updatedAt !== undefined) {
    fields.push('updated_at = ?');
    values.push(m.updatedAt);
  }
  if (m.transcript !== undefined) {
    fields.push('transcript = ?');
    values.push(m.transcript);
  }
  if (m.minutesJson !== undefined) {
    fields.push('minutes_json = ?');
    values.push(m.minutesJson);
  }
  if (m.audioUri !== undefined) {
    fields.push('audio_uri = ?');
    values.push(m.audioUri);
  }
  if (m.durationSec !== undefined) {
    fields.push('duration_sec = ?');
    values.push(m.durationSec);
  }
  if (m.markersJson !== undefined) {
    fields.push('markers_json = ?');
    values.push(m.markersJson);
  }
  if (fields.length === 0) return;
  values.push(m.id);
  await db.runAsync(`UPDATE meetings SET ${fields.join(', ')} WHERE id = ?`, values);
}

export async function listMeetings(query?: string): Promise<Meeting[]> {
  const db = await getDatabase();
  if (query?.trim()) {
    const q = `%${query.trim()}%`;
    const sql = `SELECT * FROM meetings WHERE title LIKE ? OR transcript LIKE ? OR minutes_json LIKE ? ORDER BY updated_at DESC`;
    const rows = await db.getAllAsync<Record<string, unknown>>(sql, [q, q, q]);
    return rows.map(rowFromDb);
  }
  const rows = await db.getAllAsync<Record<string, unknown>>(
    `SELECT * FROM meetings ORDER BY updated_at DESC`
  );
  return rows.map(rowFromDb);
}

export async function getMeeting(id: string): Promise<Meeting | null> {
  const db = await getDatabase();
  const row = await db.getFirstAsync<Record<string, unknown>>('SELECT * FROM meetings WHERE id = ?', [id]);
  if (!row) return null;
  return rowFromDb(row);
}

export async function deleteMeeting(id: string): Promise<void> {
  const m = await getMeeting(id);
  if (m?.audioUri) {
    try {
      await FileSystem.deleteAsync(m.audioUri, { idempotent: true });
    } catch {
      /* ignore missing file */
    }
  }
  const db = await getDatabase();
  await db.runAsync('DELETE FROM todos WHERE meeting_id = ?', [id]);
  await db.runAsync('DELETE FROM meetings WHERE id = ?', [id]);
}

function rowFromDb(row: Record<string, unknown>): Meeting {
  return {
    id: String(row.id),
    title: String(row.title),
    createdAt: Number(row.created_at),
    updatedAt: Number(row.updated_at),
    transcript: String(row.transcript ?? ''),
    minutesJson: String(row.minutes_json ?? '{}'),
    audioUri: row.audio_uri != null ? String(row.audio_uri) : null,
    durationSec: Number(row.duration_sec ?? 0),
    language: (row.language as Meeting['language']) ?? 'auto',
    markersJson: String(row.markers_json ?? '[]'),
  };
}

export async function insertTodos(items: TodoItem[]): Promise<void> {
  const db = await getDatabase();
  for (const t of items) {
    await db.runAsync(
      `INSERT OR REPLACE INTO todos (id, meeting_id, content, priority, suggested_time, done) VALUES (?, ?, ?, ?, ?, ?)`,
      [t.id, t.meetingId, t.content, t.priority, t.suggestedTime, t.done]
    );
  }
}

export async function listTodos(): Promise<TodoItem[]> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<Record<string, unknown>>(
    `SELECT * FROM todos ORDER BY done ASC, id DESC`
  );
  return rows.map((r) => ({
    id: String(r.id),
    meetingId: String(r.meeting_id),
    content: String(r.content),
    priority: r.priority as TodoItem['priority'],
    suggestedTime: r.suggested_time != null ? String(r.suggested_time) : null,
    done: Number(r.done ?? 0),
  }));
}

export async function listTodosForMeeting(meetingId: string): Promise<TodoItem[]> {
  const db = await getDatabase();
  const rows = await db.getAllAsync<Record<string, unknown>>(
    `SELECT * FROM todos WHERE meeting_id = ? ORDER BY done ASC`,
    [meetingId]
  );
  return rows.map((r) => ({
    id: String(r.id),
    meetingId: String(r.meeting_id),
    content: String(r.content),
    priority: r.priority as TodoItem['priority'],
    suggestedTime: r.suggested_time != null ? String(r.suggested_time) : null,
    done: Number(r.done ?? 0),
  }));
}

export async function updateTodo(
  id: string,
  patch: Partial<Pick<TodoItem, 'content' | 'priority' | 'suggestedTime' | 'done'>>
): Promise<void> {
  const db = await getDatabase();
  const fields: string[] = [];
  const values: (string | number | null)[] = [];
  if (patch.content !== undefined) {
    fields.push('content = ?');
    values.push(patch.content);
  }
  if (patch.priority !== undefined) {
    fields.push('priority = ?');
    values.push(patch.priority);
  }
  if (patch.suggestedTime !== undefined) {
    fields.push('suggested_time = ?');
    values.push(patch.suggestedTime);
  }
  if (patch.done !== undefined) {
    fields.push('done = ?');
    values.push(patch.done);
  }
  if (!fields.length) return;
  values.push(id);
  await db.runAsync(`UPDATE todos SET ${fields.join(', ')} WHERE id = ?`, values);
}

export async function deleteTodo(id: string): Promise<void> {
  const db = await getDatabase();
  await db.runAsync('DELETE FROM todos WHERE id = ?', [id]);
}
