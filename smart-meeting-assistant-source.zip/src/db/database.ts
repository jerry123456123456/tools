import * as SQLite from 'expo-sqlite';

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) {
    dbPromise = SQLite.openDatabaseAsync('meeting_assistant.db');
  }
  return dbPromise;
}

export async function initDatabase(): Promise<void> {
  const db = await getDatabase();
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS meetings (
      id TEXT PRIMARY KEY NOT NULL,
      title TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      transcript TEXT NOT NULL DEFAULT '',
      minutes_json TEXT NOT NULL DEFAULT '{}',
      audio_uri TEXT,
      duration_sec INTEGER NOT NULL DEFAULT 0,
      language TEXT NOT NULL DEFAULT 'auto',
      markers_json TEXT NOT NULL DEFAULT '[]'
    );
    CREATE TABLE IF NOT EXISTS todos (
      id TEXT PRIMARY KEY NOT NULL,
      meeting_id TEXT NOT NULL,
      content TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'medium',
      suggested_time TEXT,
      done INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (meeting_id) REFERENCES meetings(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_meetings_updated ON meetings(updated_at DESC);
    CREATE INDEX IF NOT EXISTS idx_todos_meeting ON todos(meeting_id);
  `);
}
