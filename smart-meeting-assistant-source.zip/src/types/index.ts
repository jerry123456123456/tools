export type AiStyle = 'concise' | 'detailed' | 'professional';
export type AsrQuality = 'standard' | 'high';
export type UiLanguage = 'zh' | 'en';
export type MeetingLanguage = 'zh' | 'en' | 'auto';

export interface MinutesStructure {
  summary: string;
  outline: string[];
  conclusions: string[];
  decisions: string[];
  issues: string[];
  highlights: string[];
  diarizedTranscript?: string;
}

export interface TodoDraft {
  content: string;
  priority: 'low' | 'medium' | 'high';
  suggestedTime?: string;
}

export interface Meeting {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  transcript: string;
  minutesJson: string;
  audioUri: string | null;
  durationSec: number;
  language: MeetingLanguage;
  markersJson: string;
}

export interface TodoItem {
  id: string;
  meetingId: string;
  content: string;
  priority: 'low' | 'medium' | 'high';
  suggestedTime: string | null;
  done: number;
}

export interface AppSettings {
  uiLanguage: UiLanguage;
  asrQuality: AsrQuality;
  autoSync: boolean;
  aiStyle: AiStyle;
  privacyLocalOnly: boolean;
  /** 阿里云百炼 / DashScope API Key（通义千问），仅存本机 */
  dashscopeApiKey: string;
}

export const defaultSettings: AppSettings = {
  uiLanguage: 'zh',
  asrQuality: 'high',
  autoSync: false,
  aiStyle: 'concise',
  privacyLocalOnly: false,
  dashscopeApiKey: '',
};
