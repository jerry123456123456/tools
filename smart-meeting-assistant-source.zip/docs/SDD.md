# 软件设计说明书（SDD）— 智能会议纪要助手

**文档版本**：1.0  
**框架**：Expo SDK 54 / React Native 0.81（Android + iOS）  
**编制说明**：本文档按 SDD 常规结构描述需求、架构、模块、数据、接口、安全与演进路径；实现代码位于仓库 `smart-meeting-assistant/`。

---

## 1. 引言

### 1.1 编写目的

界定「智能会议纪要助手」的系统边界、逻辑架构与实现约束，作为开发、测试、上架与后续迭代的基线文档。

### 1.2 项目范围

面向会议、访谈、听课等**长时语音场景**：录音 → 语音识别（ASR）→ 大模型生成结构化纪要 → 提取待办 → 在用户授权下同步至系统日历、提醒、剪贴板/分享（备忘录/日记类 App 无统一公开 API，通过系统分享与剪贴板完成）。

### 1.3 术语

| 术语 | 含义 |
|------|------|
| ASR | 自动语音识别 |
| 隐私模式 | 关闭云端上传，仅本地存储与展示 |
| 一键同步 | 用户对单条或全部待办确认后写入系统能力 |

---

## 2. 引用与约束

- Apple：EventKit（日历/提醒）、无公开「备忘录」写入 API。  
- Google：Calendar Provider；无统一「Keep 备忘录」API。  
- 长时录音：依赖系统与 `expo-av` 行为；后台持续录音需在原生层配置 `UIBackgroundModes` / 前台服务等（本仓库已预留 iOS `audio` 说明，上架前需按业务审核）。  
- **边录边转**：工业级流式 ASR 需 Azure Speech / Google Speech-to-Text 等流式服务或原生 SDK；当前实现为**停录后**调用 OpenAI Whisper 高精度转写，并在 SDD 中明确差异。

---

## 3. 需求规格摘要

### 3.1 功能需求（与需求书映射）

| 编号 | 需求 | 实现策略 |
|------|------|----------|
| F1 | 长时录音、暂停/继续、重点标记、本地回放 | `expo-av` 录音；SQLite 存 markers；纪要详情页播放 |
| F2 | 中英 ASR、说话人区分、长语音稳定 | Whisper 转写 + LLM 生成 `diarizedTranscript`（启发式说话人，可替换为带 diarization 的云 ASR） |
| F3 | AI 纪要：摘要、大纲、结论/决策/问题/重点 | `gpt-4o-mini` JSON 输出，写入 `minutes_json` |
| F4 | 待办：内容+优先级+建议时间，可编辑勾选 | `todos` 表 + 待办页 CRUD |
| F5 | 同步日历/提醒/备忘录/日记 | `expo-calendar` 写日历；iOS `createReminderAsync` 写提醒；Android 提醒用本地通知近似；备忘录/日记 = 剪贴板 + 系统 `Share` |
| F6 | 纪要列表、标题、编辑导出搜索 | SQLite + `LIKE` 搜索；`Share` 导出 |
| F7 | 设置：语言、ASR 质量、自动同步、AI 风格、隐私 | AsyncStorage 持久化 |

### 3.2 非功能需求

- **性能**：转写与总结在停录后异步执行；UI 显示处理中状态。  
- **安全**：API Key 仅存本机 AsyncStorage；隐私模式禁止外发。  
- **可维护**：服务层 `whisperService` / `aiMinutesService` / `syncService` 可替换为自有后端。

---

## 4. 系统架构

### 4.1 逻辑分层

```
┌─────────────────────────────────────────┐
│  UI（Screens + Components）              │
├─────────────────────────────────────────┤
│  状态：AppContext（设置）                 │
├─────────────────────────────────────────┤
│  数据：SQLite（meetings / todos）        │
├─────────────────────────────────────────┤
│  领域服务：录音 / Whisper / LLM / 同步    │
└─────────────────────────────────────────┘
         │ 隐私关              │ 隐私开
         ▼                    ▼
   OpenAI API            仅本地 DB + 占位纪要
```

### 4.2 技术选型

| 层级 | 技术 |
|------|------|
| 跨平台 UI | React Native + Expo |
| 导航 | React Navigation（Root Stack + Bottom Tabs） |
| 录音 | expo-av |
| 本地文件 | expo-file-system/legacy（复制录音至 document） |
| 数据库 | expo-sqlite |
| 日历/提醒 | expo-calendar（事件 + iOS 提醒） |
| 本地通知 | expo-notifications |
| 剪贴板/分享 | expo-clipboard / expo-sharing（待办页「分享」） |

### 4.3 部署形态

- 开发：`npx expo start`，真机安装 Expo Go 或 Dev Client。  
- 生产：建议 `eas build` 生成独立 APK/IPA，以便完整日历/麦克风/通知权限与后台策略。

---

## 5. 详细设计

### 5.1 录音子系统

- **开始**：请求麦克风、`setAudioModeAsync` 允许录音、创建 `Recording`（高质量预设 + `isMeteringEnabled`）。  
- **暂停/继续**：`pauseAsync` / `startAsync`。  
- **重点标记**：内存数组 `{ t, label }`，停录后写入 `markers_json`。  
- **停止**：取 `durationMillis` → `stopAndUnloadAsync` → 复制 URI 至 `documentDirectory/recordings/{id}.m4a`。  
- **波形**：`RecordingStatus.metering` 映射为条形 UI（`Waveform`）。

### 5.2 ASR 子系统

- **在线**：`POST https://api.openai.com/v1/audio/transcriptions`（`whisper-1`），表单上传 m4a。  
- **语言**：设置 `language` 为 zh/en 或自动。  
- **质量**：映射为同一模型（预留扩展更高码率/分片上传）。  
- **隐私模式**：跳过 Whisper，转写为空或错误提示由上层处理。

### 5.3 AI 纪要子系统

- **输入**：完整转写文本（截断至模型安全长度，当前约 120k 字符级策略由服务层控制）。  
- **输出**：严格 JSON：`summary`、`outline[]`、`conclusions[]`、`decisions[]`、`issues[]`、`highlights[]`、`diarizedTranscript`、`todos[]`。  
- **风格**：system prompt 根据简洁/详细/专业切换。

### 5.4 待办子系统

- 每条待办：`id`、`meeting_id`、`content`、`priority`、`suggested_time`、`done`。  
- 与纪要一对多；删除会议级联删除待办（应用层先删 todos）。

### 5.5 同步子系统

- **日历**：`requestCalendarPermissionsAsync` → 选取可写日历 → `createEventAsync`。  
- **iOS 提醒事项**：`requestRemindersPermissionsAsync` → `getCalendarsAsync(REMINDER)` → `createReminderAsync`。  
- **Android「提醒」**：无系统级 Reminders 同源 API，使用 `expo-notifications` 在建议时间触发本地通知。  
- **备忘录/日记**：`copyToClipboard` + `Share.share`，用户选择目标 App。

### 5.6 权限与设置

- 麦克风、日历、提醒、通知（Android 13+）在 `app.json` 与插件中声明；运行时逐项申请。  
- **自动同步**：设置项保留语义；批量写入敏感，默认在纪要页由用户触发「一键同步全部」。

---

## 6. 数据设计

### 6.1 ER 概要

- `Meeting` 1 — N `Todo`  
- `Meeting` 含 `markers_json`、`minutes_json`、`transcript`、`audio_uri`

### 6.2 表结构（SQLite）

**meetings**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | TEXT PK | UUID |
| title | TEXT | 可编辑；默认由 AI 摘要首行生成 |
| created_at / updated_at | INTEGER | Unix ms |
| transcript | TEXT | 纯文本或错误信息 |
| minutes_json | TEXT | MinutesStructure JSON |
| audio_uri | TEXT | 本地 file URI |
| duration_sec | INTEGER | 录音时长 |
| language | TEXT | zh/en/auto |
| markers_json | TEXT | 重点标记 JSON 数组 |

**todos**

| 字段 | 类型 | 说明 |
|------|------|------|
| id | TEXT PK | UUID |
| meeting_id | TEXT FK | 关联 meetings.id |
| content | TEXT | 待办正文 |
| priority | TEXT | low/medium/high |
| suggested_time | TEXT | ISO8601 或空 |
| done | INTEGER | 0/1 |

### 6.3 设置存储（AsyncStorage）

键 `app_settings_v1`：`uiLanguage`、`asrQuality`、`autoSync`、`aiStyle`、`privacyLocalOnly`、`openaiApiKey`。

---

## 7. 接口设计（外部）

| 接口 | 方法 | 用途 |
|------|------|------|
| OpenAI Whisper | POST /v1/audio/transcriptions | 语音转文字 |
| OpenAI Chat | POST /v1/chat/completions | 纪要 + 待办 JSON |

*可选演进：自有网关隐藏 Key、计费、审计日志。*

---

## 8. UI/UX 设计要点

- **主色** `#1B365D` 商务蓝，背景 `#F4F6F8`。  
- **首页**：大号圆形「一键录音」。  
- **录制页**：波形、计时、提示文案、暂停/继续/标记/停止。  
- **纪要详情**：分区展示摘要/大纲/维度要点/说话人文本；播放录音；导出与复制。  
- **待办**：卡片 + 紧凑操作条（日历、提醒、复制、分享、编辑、删除）。

---

## 9. 安全与隐私

- 隐私模式：不调 Whisper/Chat。  
- API Key：不入库、不上传仓库；用户自担泄露风险。  
- 录音文件：仅存应用沙箱目录。  
- 合规：上架前补充隐私政策、数据出境说明、未成年人条款等法务文本。

---

## 10. 测试建议

- 单元：解析 `minutes_json`、日期解析 `parseSuggestedDate`。  
- 集成：录音 → 停录 → DB 写入 → 详情页读取。  
- 真机：日历/提醒/通知权限路径；60+ 分钟压力与电量（单独用例）。  
- 弱网：Whisper/Chat 失败降级文案。

---

## 11. 风险与后续迭代

| 风险 | 缓解 |
|------|------|
| 流式字幕需求与当前停录转写不一致 | 接入流式 ASR 或分片上传 pipeline |
| 真说话人分离不准 | 换用带 diarization 的云服务 |
| iOS 后台录音审核 | 明确使用场景说明、可降级为前台录音 |
| OpenAI 区域与合规 | 企业可替换为 Azure OpenAI / 国内模型 |

---

## 12. 文档与代码索引

| 路径 | 说明 |
|------|------|
| `App.tsx` | 启动、Provider、导航门闸 |
| `src/navigation/RootNavigator.tsx` | 主导航 |
| `src/screens/RecordingScreen.tsx` | 录制与停录后流水线 |
| `src/services/*` | Whisper、LLM、同步、录音 |
| `src/db/*` | SQLite 初始化与仓储 |

---

*本文档与实现版本一致时可作为交付物之一；需求变更应同步修订版本号与第 3、5、6 节。*
