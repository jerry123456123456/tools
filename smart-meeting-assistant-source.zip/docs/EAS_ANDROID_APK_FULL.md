# 方案 A：完整步骤（EAS 云端打 APK，手机直接安装，无需 Expo Go）

适用于 **Android 手机**。全程在 **Expo 云端** 编译，你的电脑不需要安装 Android Studio。

---

## 零、你需要提前准备

| 项目 | 说明 |
|------|------|
| 网络 | 能访问 `expo.dev`、`npm`  registry（若在国内网络不稳定，自备代理更稳） |
| 账号 | 一个 **Expo 账号**（免费即可）[https://expo.dev/signup](https://expo.dev/signup) |
| 电脑 | 已安装 **Node.js**（你已有） |
| 手机 | Android，能安装「非应用商店」来源的 APK（安装时按系统提示允许浏览器/文件管理器安装应用） |

> **iPhone**：不能通过「随便一个 APK」安装。不走 Expo Go 时通常要走 **TestFlight / App Store** 或 Xcode 安装到指定设备，步骤另算。本文只覆盖 **Android APK**。

---

## 一、PowerShell 若无法运行 `npm` / `npx`（你之前遇到过）

出现「禁止运行脚本」时，在命令里用 **`.cmd`**，例如：

```powershell
npm.cmd install -g eas-cli
```

下文若仍报错，可把 `npm` 换成 `npm.cmd`，`npx` 换成 `npx.cmd`。

或先执行（仅当前用户、一次即可）：

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

---

## 二、安装 EAS 命令行工具

在 **任意目录** 打开 PowerShell，执行：

```powershell
npm.cmd install -g eas-cli
```

验证：

```powershell
eas --version
```

能输出版本号即可。

---

## 三、进入项目目录

```powershell
cd c:\Users\jerry\Desktop\app\smart-meeting-assistant
```

建议先确保依赖已装好（若未装过）：

```powershell
npm.cmd install
```

---

## 四、登录 Expo 账号

```powershell
eas login
```

按提示输入 **Expo 注册邮箱** 与 **密码**（或浏览器 OAuth）。  
登录成功后，你的项目会与该账号下的 **EAS 项目** 绑定。

---

## 五、首次为项目启用 EAS Build（生成 projectId）

在项目根目录执行：

```powershell
eas build:configure
```

常见情况：

1. 若询问 **Would you like to create a project?** → 选 **Yes**。  
2. 工具可能会在 **`app.json`**（或 `app.config.js`）里写入类似：

   ```json
   "extra": {
     "eas": {
       "projectId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
     }
   }
   ```

3. **请保留这次修改**（建议用 Git 提交），否则下次构建可能找不到项目。

> 本仓库已包含 **`eas.json`**，其中 **`preview`** 配置为输出 **APK**。若 `eas build:configure` 提示已配置，可跳过冲突项，以提示为准。

---

## 六、发起云端构建（生成 APK）

仍在项目根目录执行：

```powershell
eas build --platform android --profile preview
```

第一次可能会问：

- **生成 Keystore**：选 **Yes**（由 Expo 托管签名，最简单）。  
- 其他选项一般用默认即可。

之后构建会在 **云端队列** 执行，终端里会给出一个 **构建详情页链接**（形如 `https://expo.dev/accounts/.../projects/.../builds/...`）。

---

## 七、等待构建结束

- 终端会显示 **Building…**，成功后会显示 **Finished**。  
- 也可在浏览器打开 [https://expo.dev](https://expo.dev) → 登录 → **Your projects** → 选中本项目 → **Builds** → 点进对应 Android 构建。

失败时：同一页面查看 **Logs**，根据报错修改配置或依赖后重新执行第六节。

---

## 八、下载 APK 到电脑

在浏览器该构建页面中：

1. 状态为 **Finished** 后，找到 **Download** / **Install** 类按钮。  
2. 下载得到 **`*.apk`** 文件（保存到你能找到的位置，例如桌面）。

---

## 九、把 APK 装到手机（任选一种）

**方式 1：数据线**  
手机连电脑，把 APK 复制到手机「下载」文件夹，在手机文件管理器中点开安装。

**方式 2：微信 / QQ / 网盘**  
把 APK 发到「文件传输助手」或网盘，在手机上下载后点开（若微信拦截，用「用其他应用打开」或保存到系统下载目录再安装）。

**方式 3：同一 WiFi 传文件工具**  
如 LocalSend、LANDrop 等，把 APK 发到手机。

---

## 十、手机上允许安装

首次安装非商店 APK 时，Android 会提示：

- 允许 **该浏览器 / 文件管理器 / 微信**「安装未知应用」，按系统引导打开开关即可。  
- 若提示「禁止安装」或包冲突，可先卸载旧版本同名包再装（注意：**会清空该 App 数据**，除非你已备份）。

安装完成后，桌面会出现 **「智能会议纪要助手」**（与 `app.json` 里 `name` 一致），**不需要 Expo Go**。

---

## 十一、以后更新版本再打一版

1. 改功能或修 Bug 后，可适当修改 **`app.json`** 里的 **`version`**（如 `1.0.0` → `1.0.1`），便于区分安装包。  
2. 再执行：

   ```powershell
   eas build --platform android --profile preview
   ```

3. 下载新 APK，按第九节覆盖安装（或先卸载再装）。

---

## 十二、费用与限制（心里有数）

- Expo / EAS 对个人账户有 **免费构建额度**（政策以官网为准），一般足够个人学习与内测。  
- 构建在云端排队，高峰期可能略慢。

官方文档入口（英文，可随时对照）：  
[https://docs.expo.dev/build/introduction/](https://docs.expo.dev/build/introduction/)

---

## 十三、命令速查（复制用）

```powershell
cd c:\Users\jerry\Desktop\app\smart-meeting-assistant
npm.cmd install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```

构建完成后：**expo.dev → 项目 → Builds → 下载 APK → 传到手机安装**。

---

若某一步报错，把 **终端完整报错** 或 **expo.dev 上 Build 的 Log 截图文字** 发出来，可以针对性排查。
