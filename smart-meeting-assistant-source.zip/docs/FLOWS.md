# 界面结构与关键流程

以下使用 Mermaid 描述主要用户路径与导航结构。

## 1. 信息架构（导航）

```mermaid
flowchart TB
  subgraph RootStack["根栈 RootStack"]
    Main["Main 底部导航"]
    Rec["Recording 全屏录制"]
    Det["MeetingDetail 纪要详情"]
  end
  subgraph Tabs["底部导航 MainTabs"]
    Home["Home 一键录音"]
    Hist["History 纪要列表"]
    Todo["Todos 待办"]
    Set["Settings 设置"]
  end
  Main --> Tabs
  Home -->|getParent| Rec
  Hist -->|getParent| Det
  Todo -->|getParent| Det
  Rec -->|replace| Det
```

## 2. 主流程：录音 → 纪要

```mermaid
sequenceDiagram
  participant U as 用户
  participant R as RecordingScreen
  participant AV as expo-av
  participant FS as FileSystem
  participant DB as SQLite
  participant W as Whisper API
  participant L as Chat API

  U->>R: 开始录音
  R->>AV: createAsync + metering
  loop 录制中
    AV-->>R: metering 更新波形
  end
  U->>R: 停止并保存
  R->>AV: stopAndUnloadAsync
  R->>FS: copy 至 document/recordings
  R->>DB: insertMeeting 草稿
  alt 非隐私且已配置 Key
    R->>W: transcribe 音频
    W-->>R: transcript
    R->>L: generateMinutesAndTodos
    L-->>R: minutes + todos
    R->>DB: updateMeeting + insertTodos
  else 隐私模式或无 Key
    R->>DB: updateMeeting 占位纪要
  end
  R->>U: replace MeetingDetail
```

## 3. 待办同步流程（单条）

```mermaid
flowchart LR
  A[选择待办操作] --> B{类型}
  B -->|日历| C[expo-calendar createEvent]
  B -->|提醒| D{iOS?}
  D -->|是| E[createReminderAsync]
  D -->|否| F[expo-notifications 定时]
  B -->|备忘录/日记| G[Clipboard 或 Share]
```

## 4. 界面布局示意（文字线框）

**首页 Home**

```
+----------------------------------+
|        智能会议纪要助手            |
|   （提示：停录后高精度转写）      |
|                                  |
|          ( 大圆录音钮 )          |
|           一键录音               |
+----------------------------------+
```

**录制 Recording**

```
+----------------------------------+
|  [ 波形条 ================== ]   |
|           00:42                 |
|  +----------------------------+ |
|  | 实时字幕 / 隐私提示         | |
|  +----------------------------+ |
|  [暂停][继续][标记][停止并生成]   |
+----------------------------------+
```

**纪要详情 MeetingDetail**

```
+----------------------------------+
| [标题……………………]                  |
| [播放][导出][复制]               |
| 摘要 / 大纲 / 结论…            |
| 原文与说话人                    |
| 待办列表 [一键同步全部]         |
+----------------------------------+
```
