# Run in local PowerShell. Same SSH as: ssh root@192.168.60.142 (no BatchMode).
# Uploads project via temp .tgz + scp (avoids PowerShell binary pipe corruption).
param(
    [string]$VmHost = "192.168.60.142",
    [string]$SshUser = "root",
    [string]$RemoteDir = "/home/jerry/Document/note",
    [string]$LinuxOwner = "jerry:jerry",
    [switch]$SkipTestRun
)

$ErrorActionPreference = "Stop"
$ProjectRoot = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$remoteHost = "${SshUser}@${VmHost}"
$tgz = Join-Path ([System.IO.Path]::GetTempPath()) ("note-deploy-{0}.tgz" -f [Guid]::NewGuid().ToString("N").Substring(0, 8))

Write-Host "Project: $ProjectRoot"
Write-Host "Target:  $remoteHost : $RemoteDir"

Set-Location $ProjectRoot
Write-Host "Creating archive..."
& tar.exe -czf $tgz `
    --exclude=".venv" `
    --exclude="__pycache__" `
    --exclude=".git" `
    --exclude="note-remote.zip" `
    --exclude="deploy-to-vm.ps1" `
    --exclude="pack-for-remote.ps1" `
    .

if ($LASTEXITCODE -ne 0) {
    Write-Error "tar failed."
    exit 1
}

Write-Host "Uploading via scp..."
$remoteTgz = "/tmp/note-deploy.tgz"
& scp.exe $tgz "${remoteHost}:${remoteTgz}"
if ($LASTEXITCODE -ne 0) {
    Remove-Item -Force $tgz -ErrorAction SilentlyContinue
    Write-Error "scp failed. Check: ssh $remoteHost"
    exit 1
}

Remove-Item -Force $tgz

# Unix parent path (Split-Path on Windows can turn / into \ and break remote mkdir)
$lastSlash = $RemoteDir.LastIndexOf('/')
$parent = if ($lastSlash -gt 0) { $RemoteDir.Substring(0, $lastSlash) } else { '/' }
$remoteShell = "mkdir -p $parent && rm -rf $RemoteDir && mkdir -p $RemoteDir && tar -xzf $remoteTgz -C $RemoteDir && rm -f $remoteTgz && chown -R $LinuxOwner $RemoteDir && find $RemoteDir -name '*.sh' -exec sed -i 's/\r$//' {} + && sed -i 's/\r$//' $RemoteDir/main.py && chmod +x $RemoteDir/scripts/remote-setup.sh"
Write-Host "Extracting on server..."
& ssh.exe $remoteHost $remoteShell
if ($LASTEXITCODE -ne 0) {
    Write-Error "ssh extract/chown failed."
    exit 1
}

Write-Host "Running remote-setup.sh as jerry..."
& ssh.exe $remoteHost "su - jerry -c 'bash $RemoteDir/scripts/remote-setup.sh'"
$setupOk = ($LASTEXITCODE -eq 0)
if (-not $setupOk) {
    Write-Warning "remote-setup exited non-zero (often: no Python 3.10+ on Ubuntu 16). Follow the Miniconda lines printed above, then re-run: ssh ... su - jerry -c 'bash $RemoteDir/scripts/remote-setup.sh'"
}

if (-not $SkipTestRun -and $setupOk) {
    Write-Host "Test run main.py..."
    & ssh.exe $remoteHost "su - jerry -c 'cd $RemoteDir && ./.venv/bin/python main.py --url https://example.com'"
}
elseif (-not $SkipTestRun -and -not $setupOk) {
    Write-Host "Skip test run (remote-setup did not create .venv)."
}

Write-Host "Done."
