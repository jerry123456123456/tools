#!/usr/bin/env bash
# 在「已上传到服务器的项目根目录」内执行（建议用户 jerry，不要用 root 跑主程序）。
# Ubuntu 16.04 自带 Python 过旧，本脚本优先使用 Miniconda 安装的 Python 3.11。

set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PY=""
for c in python3.11 python3.12 python3.10 python3; do
  if ! command -v "$c" &>/dev/null; then
    continue
  fi
  # 兼容 Ubuntu 16 自带的 Python 3.5（无 f-string），失败则跳过该解释器
  ver="$($c -c "import sys; print('%d.%d' % (sys.version_info.major, sys.version_info.minor))" 2>/dev/null)" || continue
  major="${ver%%.*}"
  minor="${ver#*.}"
  if [[ "$major" -eq 3 && "$minor" -ge 10 ]]; then
    PY="$c"
    break
  fi
done

if [[ -z "$PY" ]]; then
  echo "未找到 Python 3.10+。"
  echo "Ubuntu 16.04 请安装 Miniconda（示例，安装到当前用户主目录）："
  echo "  wget -q https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh -O /tmp/miniconda.sh"
  echo "  bash /tmp/miniconda.sh -b -p \"\$HOME/miniconda3\""
  echo "  source \"\$HOME/miniconda3/bin/activate\""
  echo "  conda create -n note python=3.11 -y && conda activate note"
  echo "  pip install -r \"$ROOT/requirements.txt\""
  exit 1
fi

echo "使用解释器: $PY ($($PY --version))"
"$PY" -m venv .venv
./.venv/bin/pip install -U pip
./.venv/bin/pip install -r requirements.txt

if [[ ! -f .env ]]; then
  if [[ -f .env.example ]]; then
    cp .env.example .env
  fi
  echo "请编辑 .env 填入 DASHSCOPE_API_KEY："
  echo "  nano \"$ROOT/.env\""
fi

echo "安装完成。运行示例："
echo "  cd \"$ROOT\" && ./.venv/bin/python main.py --url https://example.com"
