#!/usr/bin/env python3
"""清除缓存类无关文件，将项目打包到桌面（不含 .env、.git、虚拟环境、__pycache__）。"""
from __future__ import annotations

import os
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DESKTOP = Path.home() / "Desktop"
EXCLUDE_DIR_NAMES = {".git", ".venv", "venv", "__pycache__", ".pytest_cache"}


def clean_junk(root: Path) -> None:
    for p in root.rglob("__pycache__"):
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
    for p in root.rglob("*.pyc"):
        if p.is_file():
            p.unlink(missing_ok=True)
    pc = root / ".pytest_cache"
    if pc.is_dir():
        shutil.rmtree(pc, ignore_errors=True)


def should_skip(rel: Path) -> bool:
    for part in rel.parts:
        if part in EXCLUDE_DIR_NAMES:
            return True
    if rel.name == ".env":
        return True
    if rel.suffix.lower() == ".pyc":
        return True
    return False


def main() -> None:
    clean_junk(PROJECT_ROOT)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
    zip_path = DESKTOP / f"note-{stamp}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, dirnames, filenames in os.walk(PROJECT_ROOT):
            dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIR_NAMES]
            for fn in filenames:
                fp = Path(dirpath) / fn
                try:
                    rel = fp.relative_to(PROJECT_ROOT)
                except ValueError:
                    continue
                if should_skip(rel):
                    continue
                zf.write(fp, rel.as_posix())
    print(f"已生成: {zip_path}")
    print(f"大小: {zip_path.stat().st_size // 1024} KB")


if __name__ == "__main__":
    main()
