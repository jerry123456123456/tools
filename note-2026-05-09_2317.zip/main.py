#!/usr/bin/env python3
"""
URL 内容爬取与通义千问驱动的结构化笔记聚合（本地 + DashScope API）。
多 URL 优先并入「知识体系」下同一学习单元（增厚少文件）；`notes/核心要点树.md` 随索引刷新。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import time
import uuid
from dataclasses import dataclass
from datetime import date
from http import HTTPStatus
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv
import os

# DashScope（通义千问）
import dashscope
from dashscope import Generation

try:
    import json_repair
except ImportError:
    json_repair = None  # type: ignore[misc, assignment]

# -----------------------------------------------------------------------------
# 路径与常量
# -----------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent
NOTES_DIR = PROJECT_ROOT / "notes"
URLS_FILE = PROJECT_ROOT / "urls.txt"
INDEX_FILE = PROJECT_ROOT / "knowledge_index.json"
# 程序友好侧车：仅含 id / 路径 / URL / 标签 / 核心要点等，便于聚类、生成要点树而不解析 Markdown
KEY_POINTS_INDEX_FILE = PROJECT_ROOT / "key_points_index.json"
KEY_POINTS_MAX = 40
# 默认归入「知识体系」目录，多 URL 增厚同一批 md，而不是散落到「…/网页摘录」一条一文
KNOWLEDGE_CORPUS_ROOT = "知识体系"
# 相对项目根，供 Obsidian 链接与自动生成树
CORE_POINTS_TREE_REL = "notes/核心要点树.md"

DEFAULT_MAX_BODY_CHARS = 56_000
DEFAULT_API_INTERVAL = 1.2
REQUEST_TIMEOUT = 25
CRAWL_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

_last_api_call = 0.0


def ensure_project_layout() -> None:
    NOTES_DIR.mkdir(parents=True, exist_ok=True)
    if not URLS_FILE.exists():
        URLS_FILE.write_text("", encoding="utf-8")
    if not INDEX_FILE.exists():
        INDEX_FILE.write_text(
            json.dumps({"version": 1, "entries": []}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


def warn_if_cwd_not_project_root() -> None:
    try:
        cwd = Path.cwd().resolve()
        if cwd != PROJECT_ROOT:
            print(
                f"[提示] 当前工作目录为 {cwd}，数据将写入项目根目录：{PROJECT_ROOT}",
                file=sys.stderr,
            )
    except OSError:
        pass


def load_config() -> tuple[str, str, float, int]:
    load_dotenv(PROJECT_ROOT / ".env")
    key = (os.getenv("DASHSCOPE_API_KEY") or os.getenv("QWEN_API_KEY") or "").strip()
    model = (os.getenv("QWEN_MODEL") or "qwen-turbo").strip()
    interval = float(os.getenv("API_CALL_INTERVAL_SEC") or DEFAULT_API_INTERVAL)
    max_body = int(os.getenv("MAX_BODY_CHARS") or DEFAULT_MAX_BODY_CHARS)
    if not key:
        raise RuntimeError(
            "未找到 API Key：请在项目根目录 .env 中设置 DASHSCOPE_API_KEY（或 QWEN_API_KEY）。"
        )
    dashscope.api_key = key
    return key, model, interval, max_body


def rate_limited_sleep(interval: float) -> None:
    global _last_api_call
    now = time.monotonic()
    elapsed = now - _last_api_call
    if elapsed < interval:
        time.sleep(interval - elapsed)
    _last_api_call = time.monotonic()


def call_qwen(
    messages: list[dict[str, str]],
    model: str,
    interval: float,
    max_tokens: int = 4096,
    temperature: float = 0.3,
) -> str:
    rate_limited_sleep(interval)
    try:
        resp = Generation.call(
            model=model,
            messages=messages,
            result_format="message",
            max_tokens=max_tokens,
            temperature=temperature,
        )
    except Exception as e:  # noqa: BLE001 — 明确提示网络/SDK 异常
        raise RuntimeError(f"通义千问 SDK 调用异常：{e}") from e

    if resp.status_code != HTTPStatus.OK:
        raise RuntimeError(
            f"通义千问 API 错误：status={resp.status_code} code={getattr(resp, 'code', '')} "
            f"message={getattr(resp, 'message', '')}"
        )
    try:
        return resp.output.choices[0].message.content.strip()
    except (AttributeError, IndexError, KeyError) as e:
        raise RuntimeError(f"无法解析模型返回内容：{resp}") from e


# -----------------------------------------------------------------------------
# URL 校验与 urls.txt
# -----------------------------------------------------------------------------


def is_valid_url(url: str) -> bool:
    u = url.strip()
    try:
        p = urlparse(u)
    except ValueError:
        return False
    return p.scheme in ("http", "https") and bool(p.netloc)


def check_url_reachable(url: str) -> None:
    try:
        r = requests.head(
            url,
            timeout=REQUEST_TIMEOUT,
            allow_redirects=True,
            headers={"User-Agent": CRAWL_USER_AGENT},
        )
        if r.status_code >= 400:
            requests.get(
                url,
                timeout=REQUEST_TIMEOUT,
                headers={"User-Agent": CRAWL_USER_AGENT},
            )
    except requests.RequestException as e:
        raise RuntimeError(f"URL 网络不可达或超时：{url} — {e}") from e


def load_urls_file() -> set[str]:
    if not URLS_FILE.exists():
        return set()
    lines = URLS_FILE.read_text(encoding="utf-8").splitlines()
    return {ln.strip() for ln in lines if ln.strip()}


def append_url_record(url: str) -> None:
    seen = load_urls_file()
    if url in seen:
        return
    with URLS_FILE.open("a", encoding="utf-8") as f:
        f.write(url + "\n")


def purge_url_from_project(url: str) -> list[str]:
    """从索引与磁盘删除包含该 URL 的笔记条目，并从 urls.txt 去掉该行，便于 --force 重新生成。"""
    idx = load_index()
    entries = idx.get("entries", [])
    removed_paths: list[str] = []
    kept: list[dict[str, Any]] = []
    for e in entries:
        urls_e = list(e.get("urls") or [])
        if url in urls_e:
            for pth in e.get("paths") or []:
                fp = PROJECT_ROOT / pth.replace("/", os.sep)
                if fp.is_file():
                    fp.unlink(missing_ok=True)
                removed_paths.append(pth)
            continue
        kept.append(e)
    idx["entries"] = kept
    save_index(idx)
    if URLS_FILE.exists():
        lines = [ln for ln in URLS_FILE.read_text(encoding="utf-8").splitlines() if ln.strip() and ln.strip() != url]
        URLS_FILE.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return removed_paths


# -----------------------------------------------------------------------------
# 爬取与清洗
# -----------------------------------------------------------------------------


def _meta_content(soup: BeautifulSoup, prop: str | None, name: str | None) -> str | None:
    for sel_prop, sel_name in ((prop, None), (None, name)):
        if sel_prop:
            tag = soup.find("meta", property=sel_prop)
        else:
            tag = soup.find("meta", attrs={"name": sel_name})
        if tag and tag.get("content"):
            return str(tag["content"]).strip()
    return None


def strip_boilerplate(soup: BeautifulSoup, page_url: str = "") -> None:
    for tag in soup(["script", "style", "noscript", "iframe", "svg"]):
        tag.decompose()
    for sel in ["nav", "footer", "header", "aside", "form"]:
        for t in soup.find_all(sel):
            t.decompose()
    for cls in ["sidebar", "advertisement", "ads", "comment", "comments"]:
        for t in soup.find_all(class_=re.compile(cls, re.I)):
            t.decompose()
    host = urlparse(page_url).netloc.lower() if page_url else ""
    if "csdn.net" in host:
        for sel in (
            "#blogColumn",
            "#rightAside",
            ".recommend-right-aside",
            ".aside-box",
            ".aside-box-word",
            ".recommend-box",
            ".template-box",
            ".edu-promotion",
            ".hide-article-box",
            ".tool-box",
            "#recommendAdBox",
            ".recommend-item-box",
            "[id*='recommend']",
            "[class*='recommend-item']",
            ".column-box",
        ):
            for t in soup.select(sel):
                t.decompose()


def extract_main_text(soup: BeautifulSoup, page_url: str = "") -> str:
    host = urlparse(page_url).netloc.lower() if page_url else ""
    if "csdn.net" in host:
        for sel in ("#content_views", "#article_content", "article"):
            node = soup.select_one(sel)
            if node:
                for junk in node.select(
                    ".recommend-box, .template-box, .hide-article-box, aside, "
                    ".edu-promotion, [class*='recommend-item'], #recommendAdBox"
                ):
                    junk.decompose()
                t = node.get_text("\n", strip=True)
                if t.strip():
                    return t
    candidates = []
    for sel in ["article", "main", '[role="main"]']:
        node = soup.select_one(sel)
        if node:
            candidates.append(node.get_text("\n", strip=True))
    if soup.body:
        candidates.append(soup.body.get_text("\n", strip=True))
    else:
        candidates.append(soup.get_text("\n", strip=True))
    return max(candidates, key=len) if candidates else ""


def clean_crawl_noise(text: str) -> str:
    """去掉 CSDN 等站残留的侧栏/互动/推荐文案行。"""
    drop_sub = (
        "最新推荐文章于",
        "原创文章标签",
        "CC 4.0 BY-SA",
        "版权声明：本文为博主",
        "福利倒计时",
        "普通VIP",
        "立减",
        "立即使用",
        "确定要放弃",
        "一键收藏",
        "复制链接",
        "分享到",
        "扫一扫",
        "觉得还不错",
        "0voice",
        "· GitHub",
        "的博客",
        "一键获取完整项目代码",
    )
    ui_only = frozenset(
        {
            "关注",
            "点赞",
            "踩",
            "收藏",
            "举报",
            "分享",
            "确定要放弃本次机会？",
        }
    )
    lines_out: list[str] = []
    for raw in text.splitlines():
        s = raw.strip()
        if not s:
            lines_out.append("")
            continue
        if s in ui_only and len(s) <= 20:
            continue
        if any(x in s for x in drop_sub):
            continue
        if re.match(r"^\d{1,4}$", s) and len(s) <= 4:
            continue
        if re.match(r"^\d{2}-\d{2}$", s):
            continue
        if re.match(r"^\d+\s*阅读", s) and len(s) < 40:
            continue
        lines_out.append(raw.rstrip())
    text2 = "\n".join(lines_out)
    return re.sub(r"\n{3,}", "\n\n", text2).strip()


_BOX_CHARS = frozenset("┌┐└┘│─├┤┬┴┼╔╗╚╝═║╞╡╪╫╬╭╮╯╰")


def _line_has_box_drawing(s: str) -> bool:
    return any(c in _BOX_CHARS for c in s)


def _fence_toggle_line(st: str) -> bool:
    """该行是否为 Markdown 代码围栏（以 ``` 开头）。"""
    return st.startswith("```")


def ensure_closed_code_fences(text: str) -> str:
    """若 ``` 围栏为奇数次（未闭合），在末尾补一个 ```，避免正文与附录之间的 --- 被误解析。"""
    n = sum(1 for line in text.splitlines() if line.strip().startswith("```"))
    if n % 2 == 1:
        return text.rstrip() + "\n```\n"
    return text


def normalize_llm_literal_escapes(text: str) -> str:
    """把模型误写在正文里的字面量 \\n、\\t 转成真实换行/制表（常见于 JSON 里错误转义的框图代码）。"""
    t = text.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\t", "\t")
    t = t.replace("\\r", "\n")
    return t


def repair_malformed_fences(detail: str) -> str:
    """修复模型输出的 ``` + 单独一行 text + ```text 等畸形围栏，避免重复开闭。"""
    t = detail
    t = re.sub(r"```\s*\n\s*text\s*\n\s*```text\s*\n", "```text\n", t, flags=re.I | re.M)
    t = re.sub(r"```\s*\n\s*```text\s*\n", "```text\n", t, flags=re.I | re.M)
    return t


def format_detail_summary_markdown(detail: str) -> str:
    """在围栏外把框线图包进 ```text；已进入围栏的段落不再套第二层。"""
    t = normalize_llm_literal_escapes(repair_malformed_fences(detail))
    lines = t.splitlines()
    out: list[str] = []
    in_fence = False
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        st = line.strip()
        if _fence_toggle_line(st):
            in_fence = not in_fence
            out.append(line.rstrip())
            i += 1
            continue
        if in_fence:
            out.append(line.rstrip())
            i += 1
            continue
        if _line_has_box_drawing(line):
            block: list[str] = []
            j = i
            while j < n:
                st2 = lines[j].strip()
                if _fence_toggle_line(st2):
                    break
                if _line_has_box_drawing(lines[j]) or not lines[j].strip():
                    if lines[j].strip():
                        block.append(lines[j].rstrip())
                    j += 1
                else:
                    break
            if block:
                out.append("```text")
                out.extend(block)
                out.append("```")
                out.append("")
                while j < n and lines[j].strip() == "```":
                    j += 1
                i = j
                continue
        out.append(line.rstrip())
        i += 1
    s = "\n".join(out)
    s = re.sub(r"\n{3,}", "\n\n", s).strip()
    s = ensure_closed_code_fences(s)
    return promote_cn_section_headings(s)


def promote_cn_section_headings(detail: str) -> str:
    """将「一、」「二、」等抬升为 ##（仅在代码围栏外，避免破坏框图内的字面量）。"""
    lines = detail.splitlines()
    out: list[str] = []
    in_fence = False
    for line in lines:
        st = line.strip()
        if _fence_toggle_line(st):
            in_fence = not in_fence
            out.append(line.rstrip())
            continue
        if in_fence:
            out.append(line.rstrip())
            continue
        if st and not st.startswith("#"):
            if re.match(r"^[一二三四五六七八九十百千]+、\S", st):
                pad = line[: len(line) - len(line.lstrip())]
                out.append(f"{pad}## {st}")
                continue
            if re.match(r"^\d+\.\d+\s+\S", st):
                pad = line[: len(line) - len(line.lstrip())]
                out.append(f"{pad}### {st}")
                continue
        out.append(line.rstrip())
    return "\n".join(out).strip()


@dataclass
class CrawlResult:
    url: str
    title: str
    author: str | None
    published: str | None
    text: str
    text_hash: str

    def fingerprint(self) -> str:
        return hashlib.sha256(self.text.encode("utf-8", errors="ignore")).hexdigest()[:16]


def fetch_page(url: str, max_body_chars: int) -> CrawlResult:
    r = requests.get(
        url,
        timeout=REQUEST_TIMEOUT,
        headers={"User-Agent": CRAWL_USER_AGENT},
    )
    r.raise_for_status()
    ctype = (r.headers.get("Content-Type") or "").lower()
    if "text/html" not in ctype and "application/xhtml" not in ctype:
        raise RuntimeError(f"非 HTML 页面，跳过：{ctype}")

    soup = BeautifulSoup(r.content, "lxml")
    strip_boilerplate(soup, url)

    title = (
        _meta_content(soup, "og:title", None)
        or (soup.title.string.strip() if soup.title and soup.title.string else "")
        or "未命名页面"
    )
    author = _meta_content(soup, None, "author") or _meta_content(soup, "article:author", None)
    published = _meta_content(soup, "article:published_time", None) or _meta_content(
        soup, None, "date"
    )

    text = extract_main_text(soup, url)
    text = clean_crawl_noise(text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if len(text) > max_body_chars:
        text = text[:max_body_chars] + "\n\n[内容已截断以符合 API 输入长度限制]"

    th = hashlib.sha256(text.encode("utf-8", errors="ignore")).hexdigest()
    return CrawlResult(
        url=url,
        title=title.strip(),
        author=author,
        published=published,
        text=text,
        text_hash=th,
    )


# -----------------------------------------------------------------------------
# 索引
# -----------------------------------------------------------------------------


def load_index() -> dict[str, Any]:
    if not INDEX_FILE.exists():
        return {"version": 1, "entries": []}
    return json.loads(INDEX_FILE.read_text(encoding="utf-8"))


def derive_key_points_for_entry(entry: dict[str, Any]) -> list[str]:
    """每条笔记对应一组核心要点：优先用索引字段，否则从 snippet 行拆分，供程序与侧车索引使用。"""
    k = entry.get("key_points")
    if isinstance(k, list) and k:
        out = [str(x).strip() for x in k if str(x).strip()]
        if out:
            return out[:KEY_POINTS_MAX]
    sn = entry.get("snippet") or ""
    lines = [ln.strip() for ln in str(sn).splitlines() if ln.strip() and len(ln.strip()) > 2]
    if lines:
        return lines[:KEY_POINTS_MAX]
    return ["（索引中暂无分条要点；请打开 paths 下 Markdown 的「核心要点」小节）"]


def hydrate_entries_key_points(data: dict[str, Any]) -> None:
    """保证 knowledge_index 每条 entries 均含非空的 key_points 列表。"""
    entries = data.get("entries")
    if not isinstance(entries, list):
        return
    for e in entries:
        if isinstance(e, dict):
            e["key_points"] = derive_key_points_for_entry(e)


def obsidian_link_stem(rel_from_project: str) -> str:
    """notes/foo/bar.md -> notes/foo/bar，用于 [[...]] 链接。"""
    r = rel_from_project.replace("\\", "/").strip()
    if r.lower().endswith(".md"):
        r = r[:-3]
    return r


def write_core_points_tree_md(data: dict[str, Any]) -> None:
    """在 notes 根目录生成「核心要点树」：按 category 分组，链向各学习单元 md，列出要点摘要。"""
    lines = [
        "# 核心要点树",
        "",
        "> 本文件由程序根据 `knowledge_index.json` **自动生成**，保存索引时会覆盖；请勿手工长期维护于此。",
        "",
    ]
    entries = [e for e in (data.get("entries") or []) if isinstance(e, dict) and e.get("id")]
    by_cat: dict[str, list[dict[str, Any]]] = {}
    for e in entries:
        cat = str(e.get("category") or "未分类")
        by_cat.setdefault(cat, []).append(e)
    for cat in sorted(by_cat.keys()):
        lines.append(f"## {cat}")
        lines.append("")
        for e in sorted(by_cat[cat], key=lambda x: str(x.get("title") or "")):
            rel = (e.get("paths") or [""])[0]
            title = str(e.get("title") or rel or "未命名")
            stem = obsidian_link_stem(rel) if rel else title
            n_url = len(e.get("urls") or [])
            lines.append(f"- [[{stem}|{title}]] — 来源 {n_url} 条")
            for i, kp in enumerate(derive_key_points_for_entry(e)[:10], 1):
                lines.append(f"  {i}. {kp}")
            lines.append("")
        lines.append("")
    out_path = PROJECT_ROOT / CORE_POINTS_TREE_REL
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def write_key_points_index_file(data: dict[str, Any]) -> None:
    """写入 key_points_index.json：扁平、稳定字段，供外部脚本做主题聚类 / MOC 生成。"""
    items: list[dict[str, Any]] = []
    for e in data.get("entries") or []:
        if not isinstance(e, dict):
            continue
        eid = e.get("id")
        if not eid:
            continue
        kps = derive_key_points_for_entry(e)
        items.append(
            {
                "id": str(eid),
                "title": str(e.get("title") or ""),
                "category": str(e.get("category") or ""),
                "paths": list(e.get("paths") or []),
                "urls": list(e.get("urls") or []),
                "tags": list(e.get("tags") or []),
                "key_points": kps,
                "text_hash": e.get("text_hash"),
            }
        )
    out = {
        "version": 1,
        "schema": "key_points_index.v1",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()),
        "entries": items,
    }
    KEY_POINTS_INDEX_FILE.write_text(
        json.dumps(out, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def save_index(data: dict[str, Any]) -> None:
    hydrate_entries_key_points(data)
    INDEX_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    write_key_points_index_file(data)
    write_core_points_tree_md(data)


def _entry_paths_exist(e: dict[str, Any]) -> bool:
    paths = e.get("paths") or []
    if not paths:
        return False
    return any((PROJECT_ROOT / str(p).replace("/", os.sep)).is_file() for p in paths if p)


def prune_stale_index_entries_for_url(idx: dict[str, Any], url: str) -> list[str]:
    """若某 URL 仍在索引中但对应 .md 已被删除，移除这些孤儿条目，避免误判「已在库中」。"""
    entries = idx.get("entries", [])
    if not isinstance(entries, list):
        return []
    removed_titles: list[str] = []
    new_entries: list[dict[str, Any]] = []
    for e in entries:
        if not isinstance(e, dict):
            continue
        if url not in (e.get("urls") or []):
            new_entries.append(e)
            continue
        if _entry_paths_exist(e):
            new_entries.append(e)
        else:
            removed_titles.append(str(e.get("title") or e.get("id") or ""))
    if len(new_entries) != len(entries):
        idx["entries"] = new_entries
        save_index(idx)
    return removed_titles


def prune_all_stale_index_entries(idx: dict[str, Any]) -> list[str]:
    """移除所有 paths 所指文件均不存在的索引条（手工清空 notes 后可用）。"""
    entries = idx.get("entries", [])
    if not isinstance(entries, list):
        return []
    removed: list[str] = []
    new_entries: list[dict[str, Any]] = []
    for e in entries:
        if not isinstance(e, dict):
            continue
        if _entry_paths_exist(e):
            new_entries.append(e)
        else:
            removed.append(str(e.get("title") or e.get("id") or ""))
    if len(new_entries) != len(entries):
        idx["entries"] = new_entries
        save_index(idx)
    return removed


# -----------------------------------------------------------------------------
# Prompt 与 JSON 解析
# -----------------------------------------------------------------------------


def extract_json_block(text: str) -> Any:
    """解析模型输出中的 JSON；长 Markdown 字段易含未转义引号/换行，失败时用 json_repair 兜底。"""
    t = text.strip()
    if t.startswith("```"):
        t = re.sub(r"^```(?:json)?\s*", "", t, flags=re.I)
        t = re.sub(r"\s*```$", "", t)
    candidates: list[str] = [t]
    m = re.search(r"\{[\s\S]*\}", t)
    if m and m.group(0) != t:
        candidates.append(m.group(0))
    errs: list[str] = []
    for cand in candidates:
        if not cand.strip():
            continue
        try:
            return json.loads(cand)
        except json.JSONDecodeError as e:
            errs.append(str(e)[:200])
        if json_repair is not None:
            try:
                repaired = json_repair.loads(cand)  # type: ignore[union-attr]
                if isinstance(repaired, (dict, list)):
                    return repaired
            except Exception as e2:  # noqa: BLE001
                errs.append(f"json_repair:{e2!s}"[:200])
    raise RuntimeError(
        "无法解析模型返回的 JSON（常为 detail_summary 内含未转义引号/换行）。"
        "请执行: pip install json-repair 后重试。详情: " + (" | ".join(errs[:4]) if errs else "")
    )


def _infer_knowledge_subpath(s: dict[str, Any]) -> str:
    """当模型未给多级路径时，按标题/标签/大类推断「知识体系」下的子路径（大类/细类）。"""
    title = str(s.get("article_title") or "").lower()
    tc = str(s.get("theme_category") or "").lower()
    tags = [str(t).lower() for t in (s.get("tags") or [])]
    blob = " ".join([title, tc, " ".join(tags)])

    c_lang = (
        ("c语言" in blob or " c " in f" {blob} " or "pointer" in blob or "指针" in blob)
        and "c++" not in blob
        and "cpp" not in blob
        and "csharp" not in blob
    )
    if c_lang:
        return "语言/C"

    if "python" in blob and any(x in blob for x in ("入门", "基础", "语法", "教程")):
        return "语言/Python"

    lb = any(
        x in blob
        for x in (
            "负载均衡",
            "lvs",
            "nginx",
            "dpvs",
            "upstream",
            "四层负载",
            "七层负载",
            "反向代理",
            "网关",
            "keepalived",
        )
    )
    if lb:
        return "网络/负载均衡"

    net_kernel = any(
        x in blob
        for x in (
            "网卡",
            "napi",
            "sk_buff",
            "skb",
            "协议栈",
            "收包",
            "发包",
            "xdp",
            "igb",
            "e1000",
            "netdev",
            "probe",
            "软中断",
            "ksoftirq",
            "socket",
            "dma ",
            "ring buffer",
            "ringbuffer",
        )
    ) or ("内核" in blob and "网络" in blob)
    if net_kernel:
        return "网络/Linux内核"

    mem = any(x in blob for x in ("内存管理", "页表", "mm ", "buddy", "slab", "匿名页", "page fault", "pagetable"))
    if mem:
        return "系统/内存管理"

    safe = re.sub(r'[\\/:*?"<>|#\s]+', "_", str(s.get("theme_category") or "综合"))[:24].strip("_") or "综合"
    return f"综合/{safe}"


def _should_normalize_obsidian_folder(folder: str) -> bool:
    """是否应改写到「知识体系/大类/细类」：空、仅根、或泛用的「…/网页摘录」等。"""
    f = folder.replace("\\", "/").strip("/")
    if not f:
        return True
    if f == KNOWLEDGE_CORPUS_ROOT:
        return True
    if f.endswith("/网页摘录") or f.endswith("网页摘录"):
        return True
    if f.count("/") == 0:
        return True
    return False


def coerce_summarize_struct(raw: Any, crawl: CrawlResult) -> dict[str, Any]:
    """补全/纠正模型 JSON，避免因漏字段 obsidian_folder 等导致整条管线失败。"""
    if not isinstance(raw, dict):
        raise RuntimeError("模型返回的 JSON 根类型必须是对象")
    s: dict[str, Any] = dict(raw)

    if not str(s.get("theme_category", "")).strip():
        s["theme_category"] = "未分类"
    if not str(s.get("article_title", "")).strip():
        s["article_title"] = crawl.title

    tags = s.get("tags")
    if not isinstance(tags, list):
        s["tags"] = []
    else:
        s["tags"] = [str(t).strip() for t in tags if str(t).strip()]

    kps = s.get("key_points")
    if not isinstance(kps, list) or not kps:
        s["key_points"] = ["（模型未返回分条要点，请直接阅读文末附录中的清洗正文）"]
    else:
        s["key_points"] = [str(p).strip() for p in kps if str(p).strip()]

    if not str(s.get("detail_summary", "")).strip():
        s["detail_summary"] = "（模型未返回详细总结；事实与全文请以文末「附录 · 清洗正文全文」为准。）"

    folder = str(s.get("obsidian_folder", "")).strip()
    if not folder:
        for alt in ("folder", "path", "obsidian_path", "directory", "vault_path"):
            v = s.get(alt)
            if v and str(v).strip():
                folder = str(v).strip()
                break
    folder = folder.replace("\\", "/").strip("/")
    if _should_normalize_obsidian_folder(folder):
        folder = f"{KNOWLEDGE_CORPUS_ROOT}/{_infer_knowledge_subpath(s)}"
    elif not folder.startswith(f"{KNOWLEDGE_CORPUS_ROOT}/"):
        # 模型给了「技术/…」等旧习惯路径：若落在泛用「网页摘录」则迁入知识体系子树
        if "网页摘录" in folder:
            folder = f"{KNOWLEDGE_CORPUS_ROOT}/{_infer_knowledge_subpath(s)}"
    s["obsidian_folder"] = folder.strip("/")

    return s


SYSTEM_BASE = (
    "你是专业的知识整理助手。必须严格基于给定原文事实进行提炼，不编造信息。"
    "输出仅包含用户要求的 JSON，不要 Markdown 说明文字。"
    "JSON 必须严格合法：字符串值里如需换行一律用反斜杠加字母 n 表示；"
    "如需双引号一律用反斜杠加双引号表示；反斜杠本身用双反斜杠。禁止在字符串值里出现未转义的换行或双引号。"
)

APPENDIX_HEADING = "## 📎 附录 · 清洗正文全文"


def _max_append_chars() -> int:
    return int(os.getenv("MAX_APPEND_CHARS") or "200000")


def split_note_core_and_appendix(md: str) -> tuple[str, str]:
    """拆成「正文到详细总结为止」与「附录区（含多来源多段）」。"""
    m = re.search(r"^## 📎 附录", md, re.M)
    if not m:
        return md.rstrip(), ""
    core = md[: m.start()].rstrip()
    tail = md[m.start() :].strip()
    return core, tail


def format_source_appendix(full_text: str, source_url: str) -> str:
    """将清洗后正文放入 fenced block，保证笔记文件内可检索、可对照原文。"""
    cap = _max_append_chars()
    body = clean_crawl_noise(full_text)
    body = body if len(body) <= cap else body[:cap] + "\n\n[附录：正文过长已在此处截断，可增大环境变量 MAX_APPEND_CHARS]"
    fence = ("~~~", "~~~") if "```" in body or body.strip().startswith("```") else ("```text", "```")
    open_f, close_f = fence
    src_line = f"> 来源 URL：{source_url}\n\n" if source_url else ""
    return (
        f"{APPENDIX_HEADING}\n\n"
        f"{src_line}"
        "> 与上文「详细总结」互补；事实以本附录正文为准；便于全文搜索。\n\n"
        f"{open_f}\n{body}\n{close_f}\n"
    )


def prompt_summarize(crawl: CrawlResult) -> list[dict[str, str]]:
    user = f"""根据以下网页正文，输出一个 JSON 对象，字段如下（**整份输出必须是严格合法 JSON**；detail_summary 等所有字符串值内的换行与双引号必须按 JSON 规则转义，禁止在 JSON 字符串值内直接换行或裸写双引号）：
- theme_category: 字符串，用于笔记标题前缀分类，如「技术」「工具」「产品」
- article_title: 字符串，文章标题（可略作润色以适合笔记，不改变事实）
- tags: 字符串数组，3-8 个简短标签，不要带 # 号
- key_points: 字符串数组，5-12 条核心要点，覆盖原文主要小节与结论
- detail_summary: 字符串，**尽量完整**的 Markdown 详细整理，必须满足：
  （1）章节须用 Markdown 标题：`## 一、标题` 下接 `### 1.1 小节`，禁止把「一、」「1.1」当作普通正文挤成一段；
  （2）保留原文中的技术细节：函数名/结构体名/寄存器/命令行/内核 API、Markdown 表格、对比列表；
  （3）凡含框线字符（┌│└等）的 ASCII 示意图，**必须**放在单独一段 ```text 代码围栏内，围栏内**用真实换行排版**，禁止出现字面量反斜杠加字母 n（即禁止写成 \\n 这种两个字符代替换行）；
  （4）禁止编造原文没有的内容；可在不删减信息的前提下合并重复表述；
  （5）与后文「附录」互补：本节重可读结构，附录为清洗原文。
- obsidian_folder: 相对路径片段，正斜杠，不含 notes/ 前缀。**必须至少两级业务子目录**（大类/细类），且主题差距大的文章**不得**共用同一末级目录。
  根目录请使用 **`知识体系`**，下面按领域分叉，例如：
  - C 语言、指针、语法 → `知识体系/语言/C`
  - Python 入门/基础 → `知识体系/语言/Python`
  - 负载均衡、LVS、Nginx、DPVS、四层/七层、反向代理 → `知识体系/网络/负载均衡`
  - Linux 网卡、收包路径、NAPI、协议栈、Socket、驱动 → `知识体系/网络/Linux内核`
  - 内存管理、页表、回收 → `知识体系/系统/内存管理`
  **不要把「C 语言」与「负载均衡」放在同一末级目录**；与同主题已有笔记合并时，路径应与目标笔记一致。
正文标题（参考）：{crawl.title}
作者：{crawl.author or "未知"}
发布时间：{crawl.published or "未知"}

正文：
{crawl.text}
"""
    return [
        {"role": "system", "content": SYSTEM_BASE},
        {"role": "user", "content": user},
    ]


def prompt_semantic_match(
    new_title: str,
    new_tags: list[str],
    new_snippet: str,
    new_key_points: list[str],
    index_snippets: list[dict[str, Any]],
) -> list[dict[str, str]]:
    user = {
        "task": "判断新文章与已有笔记条目的语义关系（请对照双方 key_points 语义重叠度）",
        "policy": (
            "目标：同一技术主题下多篇来源应**增厚同一条笔记**（relation=partial），而不是新建 md。"
            "若 key_points 存在主题交叉（如负载均衡+LVS、网卡驱动+NAPI、内核网络收包等），优先 partial 并入最相关的一条。"
            "仅当新文章与**所有**已有条目在主题域上明显无关（例如「C 语言语法」对比「Linux 内核网络栈」）时才选 new。"
            "若几乎全文等价、仅 URL 不同，选 duplicate。"
        ),
        "new": {
            "title": new_title,
            "tags": new_tags,
            "snippet": new_snippet[:1200],
            "key_points": new_key_points[:28],
        },
        "existing_entries": index_snippets,
        "output_schema": {
            "relation": "duplicate | partial | new",
            "target_entry_id": "若 duplicate 或 partial 则填写已有条目的 id，否则 null",
            "reason": "简短理由",
        },
    }
    return [
        {"role": "system", "content": SYSTEM_BASE},
        {
            "role": "user",
            "content": "请只输出 JSON：\n" + json.dumps(user, ensure_ascii=False, indent=2),
        },
    ]


def prompt_merge_notes(
    existing_markdown: str,
    new_struct: dict[str, Any],
    new_url: str,
    collected_at: str,
    new_page_text: str,
) -> list[dict[str, str]]:
    user = f"""将「已有笔记」与「新网页」合并为一条并集笔记。**禁止删除**已有笔记中的技术事实、表格、ASCII 图、列表层级与代码；在语义不冲突的前提下合并重复表述，并**补充**新网页中尚未覆盖的段落与细节。
「详细总结」部分须逻辑清晰、标题层级便于 Obsidian 搜索；新内容按原文结构并入。输出 JSON：
{{
  "merged_key_points": ["..."],
  "merged_detail_summary": "字符串，Markdown",
  "merged_tags": ["..."],
  "merged_theme_category": "字符串"
}}

已有笔记（仅正文区，不含附录；勿引用附录）：
{existing_markdown[:32000]}

新 URL：{new_url}
新采集时间：{collected_at}

新网页结构化 JSON（来自模型首次提炼）：
{json.dumps(new_struct, ensure_ascii=False, indent=2)}

新网页清洗正文（合并时务必把其中未出现在已有笔记中的要点并入「merged_detail_summary」；保留小节标题风格）：
{new_page_text[:24000]}
"""
    return [
        {"role": "system", "content": SYSTEM_BASE},
        {"role": "user", "content": user},
    ]


# -----------------------------------------------------------------------------
# 笔记 Markdown 生成
# -----------------------------------------------------------------------------


def sanitize_filename(name: str, max_len: int = 80) -> str:
    name = re.sub(r'[\\/:*?"<>|]', "_", name)
    name = re.sub(r"\s+", " ", name).strip()
    if not name:
        name = "note"
    return name[:max_len].rstrip(" .")


def build_markdown(
    theme_category: str,
    article_title: str,
    urls: list[str],
    collected_date: str,
    tags: list[str],
    key_points: list[str],
    detail_summary: str,
    *,
    appendix_blocks: list[tuple[str, str]] | None = None,
) -> str:
    """标题不含【分类】前缀；元数据仅保留来源与时间（标签写入索引，不出现在文首）。"""
    _ = theme_category, tags
    url_block = "\n".join(f"> 来源 URL：{u}" for u in urls) if urls else "> 来源 URL："
    points = "\n".join(f"{i}.  {p}" for i, p in enumerate(key_points, start=1))
    detail_fmt = format_detail_summary_markdown(detail_summary)
    header = f"# {article_title}"
    body = f"""{header}
{url_block}
> 采集时间：{collected_date}

💡 核心要点
{points}

📝 详细总结
{detail_fmt}
"""
    out = body.strip() + "\n"
    if appendix_blocks:
        for u, raw in appendix_blocks:
            out += "\n\n---\n\n" + format_source_appendix(raw, u)
    return out


def unique_note_path(folder_rel: str, filename_base: str) -> Path:
    rel = Path(folder_rel.strip("/\\"))
    base = sanitize_filename(filename_base)
    target_dir = NOTES_DIR / rel
    target_dir.mkdir(parents=True, exist_ok=True)
    path = target_dir / f"{base}.md"
    if not path.exists():
        return path
    for i in range(2, 1000):
        cand = target_dir / f"{base}_{i}.md"
        if not cand.exists():
            return cand
    raise RuntimeError("无法生成唯一文件名")


# -----------------------------------------------------------------------------
# 管线：单 URL 处理
# -----------------------------------------------------------------------------


def index_snippets_for_llm(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for e in entries:
        kps = derive_key_points_for_entry(e) if isinstance(e, dict) else []
        out.append(
            {
                "id": e["id"],
                "title": e.get("title", ""),
                "tags": e.get("tags", []),
                "paths": e.get("paths", []),
                "urls": e.get("urls", []),
                "key_points": kps[:28],
                "snippet": (e.get("snippet") or "")[:800],
                "text_hash": e.get("text_hash"),
            }
        )
    return out


def process_one_url(
    url: str, model: str, interval: float, max_body_chars: int, *, force: bool = False
) -> str:
    url = url.strip()
    if not is_valid_url(url):
        raise RuntimeError(f"无效 URL：{url}")

    if force:
        removed = purge_url_from_project(url)
        if removed:
            print(f"[--force] 已移除旧记录与文件：{', '.join(removed)}", file=sys.stderr)

    idx = load_index()
    stale_titles = prune_stale_index_entries_for_url(idx, url)
    if stale_titles:
        print(
            f"[索引] 已移除文件已删的孤儿条目（{len(stale_titles)}）：{'; '.join(stale_titles[:5])}"
            + ("…" if len(stale_titles) > 5 else ""),
            file=sys.stderr,
            flush=True,
        )
    entries: list[dict[str, Any]] = idx.get("entries", [])

    if not force:
        for e in entries:
            if url in (e.get("urls") or []):
                if _entry_paths_exist(e):
                    p = (e.get("paths") or ["（无路径）"])[0]
                    return f"URL 已在知识库中，跳过：{p}"
                # 理论上已由 prune 清掉，兜底继续走新建流程
                break

    check_url_reachable(url)
    crawl = fetch_page(url, max_body_chars)

    idx = load_index()
    entries = idx.get("entries", [])

    # 文本哈希辅判：完全一致则直接视为重复，减少一次语义调用
    for e in entries:
        if e.get("text_hash") == crawl.text_hash and crawl.text_hash:
            return _handle_exact_hash_duplicate(url, crawl, e, idx)

    sum_tokens = int(os.getenv("QWEN_MAX_TOKENS") or "16384")
    summarize_raw = call_qwen(
        prompt_summarize(crawl), model, interval, max_tokens=sum_tokens, temperature=0.25
    )
    struct = coerce_summarize_struct(extract_json_block(summarize_raw), crawl)

    new_snippet = "\n".join(struct.get("key_points", []))[:600]
    today = date.today().isoformat()

    if not entries:
        return _write_new_note(url, crawl, struct, today, idx, model, interval)

    match_raw = call_qwen(
        prompt_semantic_match(
            struct["article_title"],
            list(struct.get("tags", [])),
            new_snippet,
            list(struct.get("key_points") or []),
            index_snippets_for_llm(entries),
        ),
        model,
        interval,
        temperature=0.1,
    )
    match = extract_json_block(match_raw)
    rel = match.get("relation") or "new"
    target_id = match.get("target_entry_id")

    if rel == "duplicate" and target_id:
        return _merge_duplicate_urls_only(
            url, crawl, struct, target_id, idx, today, model, interval
        )

    if rel == "partial" and target_id:
        return _merge_partial_note(
            url, crawl, struct, target_id, idx, model, interval, today
        )

    return _write_new_note(url, crawl, struct, today, idx, model, interval)


def _note_path_from_entry(e: dict[str, Any]) -> Path:
    p = (e.get("paths") or [None])[0]
    if not p:
        raise RuntimeError("索引条目缺少 paths")
    return PROJECT_ROOT / p


def _handle_exact_hash_duplicate(
    url: str, crawl: CrawlResult, entry: dict[str, Any], idx: dict[str, Any]
) -> str:
    paths = entry.setdefault("urls", [])
    if url not in paths:
        paths.append(url)
    entry["text_hash"] = crawl.text_hash
    save_index(idx)
    append_url_record(url)
    path = _note_path_from_entry(entry)
    _rewrite_note_urls(path, paths)
    return f"文本哈希一致，已合并来源 URL：{path.relative_to(PROJECT_ROOT)}"


def _merge_duplicate_urls_only(
    url: str,
    crawl: CrawlResult,
    struct: dict[str, Any],
    target_id: str,
    idx: dict[str, Any],
    today: str,
    model: str,
    interval: float,
) -> str:
    entries = idx.get("entries", [])
    entry = next((e for e in entries if e.get("id") == target_id), None)
    if not entry:
        return _write_new_note(url, crawl, struct, today, idx, model, interval)

    urls = entry.setdefault("urls", [])
    if url not in urls:
        urls.append(url)
    kps = list(struct.get("key_points") or [])
    entry["snippet"] = "\n".join(kps)[:600]
    entry["key_points"] = kps[:KEY_POINTS_MAX]
    entry["text_hash"] = crawl.text_hash
    save_index(idx)
    append_url_record(url)
    path = _note_path_from_entry(entry)
    _rewrite_note_urls(path, urls)
    return f"语义完全重复，已更新来源列表：{path.relative_to(PROJECT_ROOT)}"


def _rewrite_note_urls(path: Path, urls: list[str]) -> None:
    if not path.exists():
        return
    lines = path.read_text(encoding="utf-8").splitlines()
    out: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("> 来源 URL："):
            while i < len(lines) and lines[i].startswith("> 来源 URL："):
                i += 1
            for u in urls:
                out.append(f"> 来源 URL：{u}")
            continue
        out.append(line)
        i += 1
    path.write_text("\n".join(out) + "\n", encoding="utf-8")


def _merge_partial_note(
    url: str,
    crawl: CrawlResult,
    struct: dict[str, Any],
    target_id: str,
    idx: dict[str, Any],
    model: str,
    interval: float,
    today: str,
) -> str:
    entries = idx.get("entries", [])
    entry = next((e for e in entries if e.get("id") == target_id), None)
    if not entry:
        return _write_new_note(url, crawl, struct, today, idx, model, interval)

    path = _note_path_from_entry(entry)
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    core_for_merge, tail_appendix = split_note_core_and_appendix(existing)

    merge_raw = call_qwen(
        prompt_merge_notes(core_for_merge, struct, url, today, crawl.text),
        model,
        interval,
        max_tokens=int(os.getenv("QWEN_MAX_TOKENS_MERGE") or "12288"),
        temperature=0.2,
    )
    merged = extract_json_block(merge_raw)

    urls = list(dict.fromkeys(entry.get("urls", []) + [url]))
    tags = list(merged.get("merged_tags") or struct.get("tags") or [])
    kps = list(merged.get("merged_key_points") or struct.get("key_points") or [])
    detail = merged.get("merged_detail_summary") or struct.get("detail_summary") or ""
    theme = merged.get("merged_theme_category") or struct.get("theme_category") or "未分类"
    title = struct.get("article_title") or entry.get("title") or crawl.title

    md = build_markdown(theme, title, urls, today, tags, kps, detail)
    if tail_appendix:
        md += "\n\n---\n\n" + tail_appendix
    md += "\n\n---\n\n" + format_source_appendix(crawl.text, url)
    path.write_text(md, encoding="utf-8")

    entry["urls"] = urls
    entry["title"] = title
    entry["tags"] = tags
    entry["snippet"] = "\n".join(kps)[:600]
    entry["key_points"] = kps[:KEY_POINTS_MAX]
    entry["text_hash"] = crawl.text_hash
    save_index(idx)
    append_url_record(url)
    return f"部分重叠已合并：{path.relative_to(PROJECT_ROOT)}"


def _write_new_note(
    url: str,
    crawl: CrawlResult,
    struct: dict[str, Any],
    today: str,
    idx: dict[str, Any],
    _model: str,
    _interval: float,
) -> str:
    folder = str(struct.get("obsidian_folder") or "未分类").replace("\\", "/").strip("/")
    title = str(struct.get("article_title") or crawl.title)
    tags = list(struct.get("tags") or [])
    kps = list(struct.get("key_points") or [])
    detail = str(struct.get("detail_summary") or "")
    theme = str(struct.get("theme_category") or "未分类")

    path = unique_note_path(folder, title)
    md = build_markdown(
        theme, title, [url], today, tags, kps, detail, appendix_blocks=[(url, crawl.text)]
    )
    path.write_text(md, encoding="utf-8")

    entry = {
        "id": str(uuid.uuid4()),
        "paths": [str(path.relative_to(PROJECT_ROOT)).replace("\\", "/")],
        "urls": [url],
        "title": title,
        "tags": tags,
        "snippet": "\n".join(kps)[:600],
        "key_points": kps[:KEY_POINTS_MAX],
        "text_hash": crawl.text_hash,
        "category": folder,
    }
    idx.setdefault("entries", []).append(entry)
    save_index(idx)
    append_url_record(url)
    return f"新建笔记：{path.relative_to(PROJECT_ROOT)}"


# -----------------------------------------------------------------------------
# 全量并集整合 / 知识重组（多 md -> 少 md，增厚主题笔记）
# -----------------------------------------------------------------------------


def _entry_cluster_brief(e: dict[str, Any]) -> dict[str, Any]:
    p = (e.get("paths") or [""])[0]
    fp = PROJECT_ROOT / p.replace("/", os.sep) if p else Path()
    approx = 0
    if p and fp.is_file():
        approx = len(fp.read_text(encoding="utf-8"))
    return {
        "id": e["id"],
        "title": e.get("title"),
        "category": e.get("category"),
        "path": p,
        "url_count": len(e.get("urls") or []),
        "key_points": derive_key_points_for_entry(e)[:20],
        "approx_chars": approx,
    }


def _llm_suggest_merge_groups(
    entries: list[dict[str, Any]],
    model: str,
    interval: float,
    *,
    reorganize: bool,
) -> list[list[str]]:
    brief = [_entry_cluster_brief(e) for e in entries if isinstance(e, dict) and e.get("id")]
    if reorganize:
        user = (
            "你是知识库编委。以下为用户从网页积累的学习单元（每条对应一个 .md，可含多个来源 URL）。\n"
            "目标：**减少独立 .md 数量**，把同一技术主题、适合一起阅读的材料合并为**少数更完整的笔记**；"
            "明显不同主题（例如「C 语言」与「Linux 内核网络」）不要合并。\n"
            "请根据 title、category、key_points、篇幅（approx_chars）分组。只输出 JSON："
            '{"groups":[["id1","id2"],...],"notes":"一句说明"}。\n'
            "每组至少 2 个 id。若认为应保持现状，返回 {\"groups\":[],\"notes\":\"...\"}。\n"
            + json.dumps(brief, ensure_ascii=False, indent=2)
        )
        temp = 0.08
    else:
        user = (
            "根据下列笔记条目的标题、分类与核心要点，将「语义上应合并为同一并集笔记」的条目分为若干组。"
            "只输出 JSON：{\"groups\":[[\"entry_id1\",\"entry_id2\"],...],\"notes\":\"\"}，每组至少 2 个 id。"
            "若无可合并组，返回 {\"groups\": []}。\n"
            + json.dumps(brief, ensure_ascii=False, indent=2)
        )
        temp = 0.05
    raw = call_qwen(
        [{"role": "system", "content": SYSTEM_BASE}, {"role": "user", "content": user}],
        model,
        interval,
        temperature=temp,
    )
    data = extract_json_block(raw)
    groups = data.get("groups") or []
    out: list[list[str]] = []
    for g in groups:
        ids = [str(x).strip() for x in g if str(x).strip()]
        if len(ids) >= 2:
            out.append(ids)
    return out


def _execute_merge_groups(
    idx: dict[str, Any],
    entries: list[dict[str, Any]],
    groups: list[list[str]],
    model: str,
    interval: float,
) -> tuple[list[str], set[str]]:
    """按组合并：正文由模型并集，各来源附录块保留拼接。"""
    reports: list[str] = []
    removed_ids: set[str] = set()

    for group_ids in groups:
        ids = [i for i in group_ids if i not in removed_ids]
        if len(ids) < 2:
            continue
        id_to_e = {str(e.get("id")): e for e in entries if e.get("id")}
        members = [id_to_e[i] for i in ids if i in id_to_e]
        if len(members) < 2:
            continue
        primary = members[0]
        rel_p = primary.get("paths") or [""]
        primary_path = PROJECT_ROOT / str(rel_p[0]).replace("/", os.sep)
        all_urls: list[str] = []
        cores_for_llm: list[str] = []
        appendix_chunks: list[str] = []
        for m in members:
            for u in m.get("urls", []) or []:
                if u not in all_urls:
                    all_urls.append(u)
            mp = PROJECT_ROOT / str((m.get("paths") or [""])[0]).replace("/", os.sep)
            if mp.is_file():
                full = mp.read_text(encoding="utf-8")
                core, tail = split_note_core_and_appendix(full)
                cores_for_llm.append(core.strip() if core.strip() else full)
                if tail.strip():
                    appendix_chunks.append(tail.strip())

        merge_raw = call_qwen(
            [
                {"role": "system", "content": SYSTEM_BASE},
                {
                    "role": "user",
                    "content": "将以下多篇笔记**正文区**（已去掉附录）合并为一篇并集笔记，输出 JSON："
                    '{"title":"...","theme_category":"...","tags":[],"key_points":[],"detail_summary":"Markdown 字符串"}'
                    "\n\n---\n".join(cores_for_llm)[:20000],
                },
            ],
            model,
            interval,
        )
        merged = extract_json_block(merge_raw)
        today = date.today().isoformat()
        md = build_markdown(
            str(merged.get("theme_category") or "综合"),
            str(merged.get("title") or primary.get("title") or "合并笔记"),
            all_urls,
            today,
            list(merged.get("tags") or []),
            list(merged.get("key_points") or []),
            str(merged.get("detail_summary") or ""),
        )
        for tail in appendix_chunks:
            md += "\n\n---\n\n" + tail
        primary_path.write_text(md, encoding="utf-8")

        merged_kps = list(merged.get("key_points") or [])
        primary["urls"] = all_urls
        primary["title"] = merged.get("title") or primary.get("title")
        primary["tags"] = list(merged.get("tags") or primary.get("tags") or [])
        primary["snippet"] = "\n".join(merged_kps)[:600]
        primary["key_points"] = merged_kps[:KEY_POINTS_MAX]
        primary["text_hash"] = hashlib.sha256(md.encode("utf-8")).hexdigest()

        for m in members[1:]:
            mid = m.get("id")
            if isinstance(mid, str):
                removed_ids.add(mid)
            p = PROJECT_ROOT / str((m.get("paths") or [""])[0]).replace("/", os.sep)
            if p.is_file() and p.resolve() != primary_path.resolve():
                p.unlink(missing_ok=True)

        reports.append(str(primary_path.relative_to(PROJECT_ROOT)))

    return reports, removed_ids


def merge_all_notes(model: str, interval: float) -> str:
    idx = load_index()
    entries: list[dict[str, Any]] = idx.get("entries", [])
    if len(entries) < 2:
        return "索引中少于 2 条，跳过全量整合。"

    groups = _llm_suggest_merge_groups(entries, model, interval, reorganize=False)
    if not groups:
        return "全量整合：模型未建议合并组。"

    reports, removed_ids = _execute_merge_groups(idx, entries, groups, model, interval)
    idx["entries"] = [e for e in entries if e.get("id") not in removed_ids]
    save_index(idx)
    return "全量整合完成：\n" + "\n".join(reports)


def reorganize_notes(model: str, interval: float) -> str:
    """编委式归并：在「要点 + 篇幅」提示下主动合并，使主题笔记更厚、文件更少。"""
    idx = load_index()
    entries: list[dict[str, Any]] = idx.get("entries", [])
    if len(entries) < 2:
        return "索引中少于 2 条，跳过知识重组。"

    groups = _llm_suggest_merge_groups(entries, model, interval, reorganize=True)
    if not groups:
        return "知识重组：模型未建议合并；未改文件。"

    reports, removed_ids = _execute_merge_groups(idx, entries, groups, model, interval)
    idx["entries"] = [e for e in entries if e.get("id") not in removed_ids]
    save_index(idx)
    return "知识重组完成（主题增厚、文件减少）：\n" + "\n".join(reports)


# -----------------------------------------------------------------------------
# CLI
# -----------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(
        description="URL 爬取 + 通义千问结构化笔记（Obsidian Markdown）",
    )
    parser.add_argument("--url", action="append", help="单个 URL，可重复传入")
    parser.add_argument("--file", type=Path, help="批量 URL 文本文件，每行一个")
    parser.add_argument(
        "--merge-all",
        action="store_true",
        help="手动触发全量并集整合（基于索引条目的语义分组）",
    )
    parser.add_argument(
        "--reorganize",
        action="store_true",
        help="编委式知识重组：按要点与篇幅合并多笔记，减少 .md 数量并保留各文附录",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="若 URL 已在知识库中：先删除对应索引与笔记文件、urls.txt 记录，再重新爬取生成",
    )
    parser.add_argument(
        "--rebuild-key-points-index",
        action="store_true",
        help="仅根据 knowledge_index.json 补全每条 key_points 并重写 key_points_index.json（不调 API）",
    )
    parser.add_argument(
        "--prune-stale-index",
        action="store_true",
        help="删除索引中「paths 所指 .md 已全部不存在」的条目（手工删了 notes 后清幽灵索引，不调 API）",
    )
    args = parser.parse_args()

    warn_if_cwd_not_project_root()
    ensure_project_layout()

    if args.prune_stale_index:
        idx = load_index()
        removed = prune_all_stale_index_entries(idx)
        print(f"已移除 {len(removed)} 条幽灵索引。", flush=True)
        if removed:
            print("\n".join(removed[:50]) + ("\n…" if len(removed) > 50 else ""), flush=True)
        return 0

    if args.rebuild_key_points_index:
        idx = load_index()
        save_index(idx)
        print(
            f"已更新 {INDEX_FILE.name}（补全 key_points）与 {KEY_POINTS_INDEX_FILE.name}。",
            flush=True,
        )
        return 0

    try:
        _, model, interval, max_body = load_config()
    except RuntimeError as e:
        print(str(e), file=sys.stderr)
        return 1

    if args.merge_all:
        try:
            print(merge_all_notes(model, interval))
        except Exception as e:  # noqa: BLE001
            print(f"[错误] {e}", file=sys.stderr)
            return 1
        return 0

    if args.reorganize:
        try:
            print(reorganize_notes(model, interval))
        except Exception as e:  # noqa: BLE001
            print(f"[错误] {e}", file=sys.stderr)
            return 1
        return 0

    urls: list[str] = []
    if args.url:
        urls.extend(args.url)
    if args.file:
        p = args.file if args.file.is_absolute() else PROJECT_ROOT / args.file
        if not p.exists():
            print(f"文件不存在：{p}", file=sys.stderr)
            return 1
        urls.extend([ln.strip() for ln in p.read_text(encoding="utf-8").splitlines() if ln.strip()])

    if not urls:
        print("交互模式：每行输入一个 URL，空行结束。")
        while True:
            line = input().strip()
            if not line:
                break
            urls.append(line)

    if not urls:
        print("未提供任何 URL。", file=sys.stderr)
        return 1

    exit_code = 0
    for u in urls:
        try:
            print(f"处理中：{u}", file=sys.stderr, flush=True)
            msg = process_one_url(u, model, interval, max_body, force=args.force)
            print(msg)
        except Exception as e:  # noqa: BLE001
            print(f"[错误] {u}\n  {e}", file=sys.stderr)
            exit_code = 1
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
