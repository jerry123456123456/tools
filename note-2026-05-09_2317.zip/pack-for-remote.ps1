# 打包项目供 scp 上传到 Linux（不包含 .env，避免密钥进压缩包）
$ErrorActionPreference = "Stop"
$root = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$zip = Join-Path $root "note-remote.zip"
$items = @(
    "main.py",
    "requirements.txt",
    "README.md",
    ".env.example",
    ".gitignore",
    "knowledge_index.json",
    "urls.txt",
    "scripts\remote-setup.sh"
)
Push-Location $root
try {
    if (Test-Path $zip) { Remove-Item $zip -Force }
    Compress-Archive -Path $items -DestinationPath $zip -CompressionLevel Optimal
    Write-Host "已生成: $zip"
    Write-Host ""
    Write-Host "在本机 PowerShell 上传到虚拟机（会提示输入 root 密码）："
    Write-Host "  scp `"$zip`" root@192.168.60.142:/tmp/"
    Write-Host ""
    Write-Host "SSH 登录后在服务器执行："
    Write-Host "  mkdir -p /home/jerry/Document && unzip -o /tmp/note-remote.zip -d /home/jerry/Document/note"
    Write-Host "  chown -R jerry:jerry /home/jerry/Document/note"
    Write-Host "  su - jerry -c 'cd /home/jerry/Document/note && bash scripts/remote-setup.sh'"
    Write-Host "  # 再把本机 .env 单独拷过去（勿把密钥提交到 git）："
    Write-Host "  # scp .env jerry@192.168.60.142:/home/jerry/Document/note/.env"
}
finally { Pop-Location }
