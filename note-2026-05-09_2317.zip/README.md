# URL 内容爬取与智能结构化笔记聚合系统

本地运行、通义千问（DashScope）驱动的网页采集与 Obsidian 风格 Markdown 笔记工具。所有数据写入本项目目录；仅大模型环节调用云端 API。

## 产品目标：越输入越完善，而不是越输入越碎

你要的是：**网址越加越多，库里的 Markdown 越来越通顺、完整、好读**；分类清楚，整体像**一棵树**（总览 → 若干主题笔记 → 每篇里多来源、厚正文），而不是「每抓一篇就多一个孤零零的 md」。

当前实现朝这个方向靠拢的方式是：

| 环节 | 作用 |
|------|------|
| **在线并入** | 新 URL 提炼后，模型在 `duplicate` / **`partial`（优先）** / `new` 里选择；同技术域、要点可互补时**并入已有 md**，同一文件里堆叠多 URL 的来源与附录，**增厚少增文件**。 |
| **多级目录 `知识体系/大类/细类`** | 提炼时要求模型给出如 `知识体系/语言/C` 与 `知识体系/网络/负载均衡` 等路径；泛用「…/网页摘录」或空路径会由程序**启发式改写到不同子树**，避免 C 与负载均衡挤在同一目录。仍保留模型显式给出的 `技术/…` 等非泛用路径（除非含「网页摘录」则迁移）。 |
| **`notes/核心要点树.md`** | 每次更新索引时**自动生成**：按分类列出每条学习单元、要点摘要和 Obsidian 链接，相当于**笔记树的导航面**（在 Obsidian 里从这一页往下点）。 |
| **`key_points_index.json`** | 给脚本或以后自动化用的**扁平索引**，每条都有 `key_points`，便于以后做更细的聚类或生成子树。 |
| **定期 `python main.py --reorganize`** | 对**已有**多条索引做一次「编委式」归并建议，把过碎的多份 md **合并成更少的主题笔记**，并**保留各文附录**；适合在积累了一批 URL 后偶尔跑一遍，让结构收一收。 |

**尚未自动化、但符合你终极想象的部分**：例如「先并成一篇，后来发现应拆开，再把 A 段与别的篇合并成新主题」这种**动态拆篇 + 再编排**，需要额外的拆分管线与更多交互；当前可以靠 **`--reorganize` 收敛** + **Obsidian 内手工调整** 过渡。

**推荐节奏**：平时只 `python main.py --url ...`；每隔一段时间（或觉得 md 太碎时）执行一次 **`--reorganize`**；日常在 Obsidian 打开 **`核心要点树.md`** 当总目录。

## 环境准备

1. Python 3.10+（建议 3.11）
2. 复制环境变量模板并填写 Key：

```bash
copy .env.example .env
```

在 `.env` 中设置：

- `DASHSCOPE_API_KEY`：阿里云 DashScope / 百炼 API Key  
- `QWEN_MODEL`：如 `qwen-turbo`、`qwen-plus`（可选，默认 `qwen-turbo`）  
- `API_CALL_INTERVAL_SEC`：两次 API 调用最小间隔（可选，默认 `1.2`）  
- `MAX_BODY_CHARS`：送入模型的正文最大字符数（可选，默认约 `56000`）  
- `MAX_APPEND_CHARS`：笔记末尾「附录 · 清洗正文」最大长度（可选，默认 `200000`）  
- `QWEN_MAX_TOKENS` / `QWEN_MAX_TOKENS_MERGE`：提炼与合并时模型输出 token 上限（可选）

3. 安装依赖：

```bash
pip install -r requirements.txt
```

## 使用方法

在项目根目录执行（推荐）：

```bash
python main.py --url https://example.com/article
```

同一 URL 已处理过会提示跳过；若要**强制重新生成**（会删旧笔记与索引中该条）：

```bash
python main.py --force --url "https://..."
```

**Windows CMD**：链接里若有 `&`（CSDN 等分享 URL 很常见），必须把**整条 URL 用英文双引号**包起来，否则 `&` 会被当成「下一条命令」，出现 `xxx 不是内部或外部命令`：

```cmd
python main.py --url "https://blog.csdn.net/...全文含参数..."
```

复制命令时**不要**把上一行提示符里的目录末尾 `>` 一起粘进来；若变成 `...\note>>python` 或 `...\note>python`，`>>` / `>` 在 CMD 里是重定向，整行可能根本没按「运行 python」执行，表现为没有任何正常输出。正确一行应以 `python` 或 `python.exe` 的完整路径开头（可先 `cd` 到项目目录再运行）。

多个 URL：

```bash
python main.py --url https://a.com/1 --url https://b.com/2
```

从文件批量读取（每行一个 URL）：

```bash
python main.py --file urls_batch.txt
```

交互模式（无参数启动，逐行输入 URL，空行结束）：

```bash
python main.py
```

手动触发「全量并集整合」（由模型对索引中的条目分组并合并多篇笔记到一篇）：

```bash
python main.py --merge-all
```

仅根据已有 `knowledge_index.json` **补全每条 `key_points`**（旧数据从 `snippet` 推导）并重写 **`key_points_index.json`**（不调 API、不需 `.env`）：

```bash
python main.py --rebuild-key-points-index
```

若你**手工删了 `notes/` 里的 .md**，但索引里还留着 URL，会导致再次抓取时被误判「已在库中」。可**一次性清掉所有「文件已不存在」的幽灵索引**（不调 API）：

```bash
python main.py --prune-stale-index
```

处理单个 URL 时，程序也会**自动**删掉「仅含该 URL、且对应文件已不存在」的孤儿条目，再决定是否新建。

**知识重组（编委式合并）**：在已有索引上让模型按「要点 + 篇幅」建议把多份笔记并为更少的主题笔记，合并时**保留每篇原有附录块**（适合把历史里拆太碎的 md 收成几本厚书）：

```bash
python main.py --reorganize
```

## 输出说明

| 路径 | 说明 |
|------|------|
| `notes/` | Obsidian 笔记根目录；默认主内容在 **`知识体系/`** |
| `notes/核心要点树.md` | **自动生成**的总览：分类 + 每条条目的要点摘要 + `[[链接]]`（勿手改，保存索引时会覆盖） |
| `urls.txt` | 已成功处理的 URL 列表（去重追加） |
| `knowledge_index.json` | 知识库索引：每条含 `paths`、`urls`、`tags`、`snippet`、`text_hash`、**`key_points`（与正文「核心要点」对应，每篇必有）** 等 |
| `key_points_index.json` | **程序友好侧车索引**：扁平列表，字段稳定，便于脚本做聚类、生成要点树（随 `save_index` 自动刷新） |
| `.env` | 本地密钥，**勿提交**（已列入 `.gitignore`） |

## 笔记格式

生成 Markdown：一级标题为**文章标题**（不含【分类】前缀）；**不在文首**写 blockquote 式的来源与时间（便于多次追加 URL 与补充要点）。正文顺序为：核心要点、详细总结；其后为 **`## 来源与采集记录`**（多行 `- 日期 — URL`）；再经分隔线进入各 URL 的 **`## 📎 附录 · 清洗正文全文`**。标签仅存索引，不写入文首。详细总结经后处理：中文「一、」等抬升为二级标题，框线图包入 text 类型 fenced 代码块。

**只多不少**：模型会在「详细总结」里尽量保留原文层级、表格、ASCII 图与代码要点；文末附录为清洗后的**整段正文**（便于检索与核对）。若语义判定为「部分重叠」并合并进已有笔记，会重写正文与来源表，并在保留旧附录的前提下**再追加**新 URL 对应的一节附录。

**合并 vs 新建**：除正文哈希完全一致外，由模型对照新文章与索引里各条的标题、标签、摘要及 **`key_points`** 判断 `duplicate` / `partial` / `new`；要点高度同主题、可互补时倾向并入同一 `.md`，否则新建另一篇。

## 行为摘要

- **采集**：`requests` 拉取 HTML，`BeautifulSoup` 去除脚本/导航/侧栏等噪声，优先 `article` / `main` 正文。  
- **提炼**：通义千问输出结构化 JSON，再渲染为固定模板笔记。  
- **去重**：正文 SHA256 一致时直接合并来源（更新 `sources` 与「来源与采集记录」）；否则由模型对照 **`key_points` 等**判断 `duplicate` / `partial` / `new`，分别更新来源表、合并正文或新建笔记。旧版文首 `> 来源 URL` 在更新来源时会被去掉。  
- **异常**：单条 URL 失败会打印错误并继续处理后续 URL（批量时）。

## 依赖

见 `requirements.txt`：`requests`、`beautifulsoup4`、`dashscope`、`python-dotenv`、`lxml`、`json-repair`（模型返回超长/含引号的 JSON 时兜底解析）。若遇 JSON 解析错误，请执行：`pip install -r requirements.txt` 确保含 `json-repair`。

## 放到远程 Linux（SSH，例如 `/home/jerry/Document`）

你在自己电脑上配置好 **SSH 公钥登录** 后，`ssh root@192.168.60.142` 可以免密，这是正常的；**用 `scp` / `rsync` 同样一般也不会再要密码**。

若你遇到 **`ssh -o BatchMode=yes ...` 连不上、但普通 `ssh root@IP` 能登录**：请不要用 `BatchMode=yes`（它会禁止一切交互，某些环境下会导致认证失败）；本仓库里的 `deploy-to-vm.ps1` 已按「与日常 `ssh` 一致」的方式调用，不带该选项。

说明：Cursor 里的 AI 终端往往**访问不到你家里的内网 IP**（例如 `192.168.60.142`），也拿不到你本机 `~/.ssh` 里的私钥，所以我不能替你在「云端沙箱」里直接连上你的虚拟机；部署命令需要你在**本机** PowerShell 或终端里执行一次（对你来说是免密的）。

### 1. 在本机项目目录打包（压缩包里**不含** `.env`，DashScope 密钥请单独上传或服务器上编辑）

```powershell
cd C:\Users\jerry\Desktop\note
.\pack-for-remote.ps1
```

### 2. 上传到虚拟机（示例 IP 与路径按你的环境改）

```powershell
scp C:\Users\jerry\Desktop\note\note-remote.zip root@192.168.60.142:/tmp/
```

若已安装 `rsync`（Git Bash 等），也可整目录同步（按需排除 `.venv`）：

```bash
rsync -avz --exclude '.venv' --exclude '__pycache__' /c/Users/jerry/Desktop/note/ root@192.168.60.142:/home/jerry/Document/note/
```

### 3. SSH 登录后在 Ubuntu 上解压并交给用户 `jerry`

```bash
mkdir -p /home/jerry/Document/note
unzip -o /tmp/note-remote.zip -d /home/jerry/Document/note
chown -R jerry:jerry /home/jerry/Document/note
```

### 4. 用 `jerry` 安装依赖并运行（不要用 root 跑主程序）

```bash
su - jerry -c 'cd /home/jerry/Document/note && bash scripts/remote-setup.sh'
```

若提示没有 Python 3.10+：**Ubuntu 16.04 系统自带 Python 太旧**，请按脚本里打印的说明安装 [Miniconda](https://repo.anaconda.com/miniconda/)，用 `conda create -n note python=3.11` 后再 `pip install -r requirements.txt`。

### 5. 把 API Key 放到服务器上的 `.env`

在本机（密钥不要进 git）：

```powershell
scp C:\Users\jerry\Desktop\note\.env jerry@192.168.60.142:/home/jerry/Document/note/.env
```

或在服务器上：`cp .env.example .env` 后 `nano .env` 自行填写。

### 6. 运行

```bash
cd /home/jerry/Document/note
./.venv/bin/python main.py --url https://example.com
```

### Linux 虚拟机里应该有什么

**只需要能跑 Python 项目的那一套**：`main.py`、`requirements.txt`、`scripts/`、`knowledge_index.json`、`urls.txt`、`.env`（或 `.env.example`）、`README.md` 等。

**不要**把 `deploy-to-vm.ps1`、`pack-for-remote.ps1` 留在 Linux 上——那是 **Windows 本机** 用来打包、上传的脚本，在 Linux 里用不了。若已经拷过去了，在服务器上删掉即可：

```bash
rm -f /home/jerry/Document/note/deploy-to-vm.ps1 /home/jerry/Document/note/pack-for-remote.ps1
```

之后请用本机更新过的 `deploy-to-vm.ps1` 再部署一次，这两个文件默认已不再打进上传包。
