package com.buluo.tribe

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.util.TypedValue
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.roundToInt

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager

    private var mainFloatView: TextView? = null
    private var mainParams: WindowManager.LayoutParams? = null

    private val subFloatViews = mutableListOf<TextView>()
    private val subParamsList = mutableListOf<WindowManager.LayoutParams>()

    private var screenOverlayRoot: FrameLayout? = null
    private var screenOverlayParams: WindowManager.LayoutParams? = null
    private var drawingView: DrawingOverlayView? = null

    private var mainSizeCm = DisplayUtil.DEFAULT_FLOAT_CM
    private var menuExpanded = false
    private var currentDrawMode = OverlayDrawMode.NONE

    private var dragStartX = 0
    private var dragStartY = 0
    private var paramStartX = 0
    private var paramStartY = 0
    private var isDragging = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(NOTIFICATION_ID, buildNotification())
        showMainFloat()
    }

    override fun onDestroy() {
        isRunning = false
        removeAllWindows()
        super.onDestroy()
    }

    private fun overlayLayoutParams(
        width: Int,
        height: Int,
        gravity: Int = Gravity.TOP or Gravity.START,
        x: Int = 0,
        y: Int = 0
    ): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        return WindowManager.LayoutParams(
            width,
            height,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            this.x = x
            this.y = y
        }
    }

    private fun showMainFloat() {
        if (mainFloatView != null) return

        val sizePx = DisplayUtil.cmToPx(this, mainSizeCm)
        val view = createCircleLabel("部", R.drawable.bg_float_circle, sizePx)
        val (screenW, screenH) = DisplayUtil.screenSize(this)
        val params = overlayLayoutParams(
            width = sizePx,
            height = sizePx,
            x = screenW / 2 - sizePx / 2,
            y = screenH / 3
        )

        attachFloatTouchHandlers(view, params, isMain = true)
        windowManager.addView(view, params)
        mainFloatView = view
        mainParams = params
    }

    private fun createCircleLabel(
        text: String,
        bgRes: Int,
        sizePx: Int
    ): TextView {
        val textPx = when {
            text.length <= 2 -> sizePx * 0.36f
            text.length <= 4 -> sizePx * 0.22f
            else -> sizePx * 0.16f
        }
        return TextView(this).apply {
            this.text = text
            setTextColor(getColor(R.color.white))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, textPx)
            gravity = Gravity.CENTER
            setBackgroundResource(bgRes)
            layoutParams = FrameLayout.LayoutParams(sizePx, sizePx)
        }
    }

    private fun attachFloatTouchHandlers(
        view: TextView,
        params: WindowManager.LayoutParams,
        isMain: Boolean,
        onClick: (() -> Unit)? = null
    ) {
        val scaleDetector = if (isMain) {
            ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    if (currentDrawMode != OverlayDrawMode.NONE) return false
                    val factor = detector.scaleFactor
                    mainSizeCm = (mainSizeCm * factor)
                        .coerceIn(DisplayUtil.MIN_FLOAT_CM, DisplayUtil.MAX_FLOAT_CM)
                    applyMainSize()
                    return true
                }
            })
        } else null

        view.setOnTouchListener { v, event ->
            scaleDetector?.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = event.rawX.roundToInt()
                    dragStartY = event.rawY.roundToInt()
                    paramStartX = params.x
                    paramStartY = params.y
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (scaleDetector?.isInProgress == true) return@setOnTouchListener true
                    val dx = event.rawX.roundToInt() - dragStartX
                    val dy = event.rawY.roundToInt() - dragStartY
                    if (abs(dx) > 8 || abs(dy) > 8) {
                        isDragging = true
                        params.x = paramStartX + dx
                        params.y = paramStartY + dy
                        windowManager.updateViewLayout(v, params)
                        if (isMain && menuExpanded) updateSubMenuPositions()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        onClick?.invoke() ?: if (isMain) onMainFloatClick()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun onMainFloatClick() {
        if (currentDrawMode != OverlayDrawMode.NONE) {
            Toast.makeText(this, "请先点击右上角取消", Toast.LENGTH_SHORT).show()
            return
        }
        if (menuExpanded) collapseMenu() else expandMenu()
    }

    private fun expandMenu() {
        collapseMenu()
        menuExpanded = true
        val labels = listOf(
            getString(R.string.mode_straight),
            getString(R.string.mode_center),
            getString(R.string.mode_close)
        )
        val backgrounds = listOf(
            R.drawable.bg_float_sub,
            R.drawable.bg_float_sub,
            R.drawable.bg_float_close
        )
        val actions: List<() -> Unit> = listOf(
            { enterDrawMode(OverlayDrawMode.STRAIGHT) },
            { enterDrawMode(OverlayDrawMode.CENTER) },
            { stopSelf() }
        )

        val mainSize = DisplayUtil.cmToPx(this, mainSizeCm)
        val subSize = (mainSize * DisplayUtil.SUB_ICON_SCALE).roundToInt()

        labels.forEachIndexed { index, label ->
            val view = createCircleLabel(label, backgrounds[index], subSize)
            val params = overlayLayoutParams(width = subSize, height = subSize)
            attachFloatTouchHandlers(view, params, isMain = false, onClick = {
                collapseMenu()
                actions[index]()
            })
            windowManager.addView(view, params)
            subFloatViews.add(view)
            subParamsList.add(params)
        }
        updateSubMenuPositions()
        mainFloatView?.visibility = View.VISIBLE
    }

    private fun collapseMenu() {
        menuExpanded = false
        subFloatViews.forEach { windowManager.removeView(it) }
        subFloatViews.clear()
        subParamsList.clear()
    }

    private fun updateSubMenuPositions() {
        val main = mainParams ?: return
        val mainSize = DisplayUtil.cmToPx(this, mainSizeCm)
        val subSize = (mainSize * DisplayUtil.SUB_ICON_SCALE).roundToInt()
        val gap = (mainSize * 0.15f).roundToInt()
        subParamsList.forEachIndexed { index, params ->
            params.x = main.x + mainSize + gap
            params.y = main.y + index * (subSize + gap)
            windowManager.updateViewLayout(subFloatViews[index], params)
        }
    }

    private fun applyMainSize() {
        val sizePx = DisplayUtil.cmToPx(this, mainSizeCm)
        mainFloatView?.let { view ->
            val params = mainParams ?: return
            params.width = sizePx
            params.height = sizePx
            view.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx * 0.36f)
            windowManager.updateViewLayout(view, params)
            if (menuExpanded) {
                collapseMenu()
                expandMenu()
            }
        }
    }

    private fun enterDrawMode(mode: OverlayDrawMode) {
        currentDrawMode = mode
        mainFloatView?.visibility = View.GONE
        showScreenOverlay(mode)
    }

    private fun showScreenOverlay(mode: OverlayDrawMode) {
        if (screenOverlayRoot != null) return

        val root = LayoutInflater.from(this).inflate(R.layout.overlay_screen, null) as FrameLayout
        val drawView = root.findViewById<DrawingOverlayView>(R.id.drawingView)
        val cancelBtn = root.findViewById<TextView>(R.id.cancelButton)

        drawView.drawMode = mode
        drawingView = drawView

        cancelBtn.setOnClickListener { exitDrawMode() }

        val (w, h) = DisplayUtil.screenSize(this)
        val params = overlayLayoutParams(
            width = w,
            height = h,
            gravity = Gravity.TOP or Gravity.START,
            x = 0,
            y = 0
        )
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        windowManager.addView(root, params)
        screenOverlayRoot = root
        screenOverlayParams = params
    }

    private fun exitDrawMode() {
        currentDrawMode = OverlayDrawMode.NONE
        drawingView?.drawMode = OverlayDrawMode.NONE
        drawingView?.reset()

        screenOverlayRoot?.let { windowManager.removeView(it) }
        screenOverlayRoot = null
        screenOverlayParams = null
        drawingView = null

        mainFloatView?.visibility = View.VISIBLE
        collapseMenu()
    }

    private fun removeAllWindows() {
        collapseMenu()
        screenOverlayRoot?.let {
            runCatching { windowManager.removeView(it) }
        }
        screenOverlayRoot = null
        mainFloatView?.let {
            runCatching { windowManager.removeView(it) }
        }
        mainFloatView = null
    }

    private fun buildNotification(): Notification {
        val channelId = "tribe_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
        @Volatile
        var isRunning: Boolean = false
    }
}
