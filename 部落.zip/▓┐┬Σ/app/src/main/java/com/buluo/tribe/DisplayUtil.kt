package com.buluo.tribe

import android.content.Context
import android.util.DisplayMetrics
import android.util.TypedValue
import kotlin.math.roundToInt

object DisplayUtil {
    const val LINE_WIDTH_PX = 3f
    const val DOT_RADIUS_DP = 6f
    const val DEFAULT_FLOAT_CM = 1f
    const val MIN_FLOAT_CM = 0.6f
    const val MAX_FLOAT_CM = 2.5f
    const val SUB_ICON_SCALE = 0.72f

    fun cmToPx(context: Context, cm: Float): Int {
        val metrics = context.resources.displayMetrics
        return (cm * metrics.xdpi / 2.54f).roundToInt().coerceAtLeast(1)
    }

    fun dpToPx(context: Context, dp: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            context.resources.displayMetrics
        )
    }

    fun screenSize(context: Context): Pair<Int, Int> {
        val metrics: DisplayMetrics = context.resources.displayMetrics
        return metrics.widthPixels to metrics.heightPixels
    }
}
