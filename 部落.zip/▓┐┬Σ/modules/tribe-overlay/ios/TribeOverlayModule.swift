import ExpoModulesCore

public class TribeOverlayModule: Module {
  public func definition() -> ModuleDefinition {
    Name("TribeOverlay")
  }
}
