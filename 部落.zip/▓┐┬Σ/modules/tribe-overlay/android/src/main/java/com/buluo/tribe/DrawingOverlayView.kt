package com.buluo.tribe

import expo.modules.tribeoverlay.R
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
enum class OverlayDrawMode {
    NONE,
    STRAIGHT,
    CENTER
}

/**
 * 全屏透明绘制层：拦截触摸，绘制红点与无限延伸红线。
 */
class DrawingOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var drawMode: OverlayDrawMode = OverlayDrawMode.NONE

    /** 为 false 时仅显示已绘内容，触摸穿透到底层应用。 */
    var interactionEnabled: Boolean = true

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FF0000")
    }

    private val midDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = context.getColor(R.color.dot_mid)
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = DisplayUtil.LINE_WIDTH_PX
        color = Color.parseColor("#FF0000")
    }

    private val dotRadius = DisplayUtil.dpToPx(context, DisplayUtil.DOT_RADIUS_DP)

    private val tapPoints = mutableListOf<PointF>()
    private var midpoint: PointF? = null
    private var lineThroughA: PointF? = null
    private var lineThroughB: PointF? = null

    var onDrawingChanged: (() -> Unit)? = null

    fun reset() {
        tapPoints.clear()
        midpoint = null
        lineThroughA = null
        lineThroughB = null
        invalidate()
        onDrawingChanged?.invoke()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!interactionEnabled || drawMode == OverlayDrawMode.NONE) return false
        if (event.action == MotionEvent.ACTION_DOWN) {
            handleTap(event.x, event.y)
            return true
        }
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        when (drawMode) {
            OverlayDrawMode.STRAIGHT -> handleStraightTap(x, y)
            OverlayDrawMode.CENTER -> handleCenterTap(x, y)
            OverlayDrawMode.NONE -> Unit
        }
        invalidate()
        onDrawingChanged?.invoke()
    }

    private fun handleStraightTap(x: Float, y: Float) {
        if (tapPoints.size >= 2 && lineThroughA != null) {
            reset()
            return
        }
        tapPoints.add(PointF(x, y))
        if (tapPoints.size == 2) {
            lineThroughA = tapPoints[0]
            lineThroughB = tapPoints[1]
        }
    }

    private fun handleCenterTap(x: Float, y: Float) {
        if (tapPoints.size >= 3 && lineThroughA != null) {
            reset()
            return
        }
        tapPoints.add(PointF(x, y))
        when (tapPoints.size) {
            2 -> {
                midpoint = PointF(
                    (tapPoints[0].x + tapPoints[1].x) / 2f,
                    (tapPoints[0].y + tapPoints[1].y) / 2f
                )
                lineThroughA = null
                lineThroughB = null
            }
            3 -> {
                val mid = midpoint ?: return
                lineThroughA = mid
                lineThroughB = tapPoints[2]
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        tapPoints.forEach { canvas.drawCircle(it.x, it.y, dotRadius, dotPaint) }
        midpoint?.let { canvas.drawCircle(it.x, it.y, dotRadius * 0.85f, midDotPaint) }
        val a = lineThroughA
        val b = lineThroughB
        if (a != null && b != null) {
            drawInfiniteLine(canvas, a, b, linePaint)
        }
    }

    companion object {
        /** 过两点向屏幕外无限延伸的直线段（裁剪到视图边界）。 */
        fun drawInfiniteLine(canvas: Canvas, p1: PointF, p2: PointF, paint: Paint) {
            val w = canvas.width.toFloat()
            val h = canvas.height.toFloat()
            if (w <= 0f || h <= 0f) return

            val dx = p2.x - p1.x
            val dy = p2.y - p1.y
            if (hypot(dx.toDouble(), dy.toDouble()) < 1e-6) return

            val pts = mutableListOf<PointF>()

            if (dx != 0f) {
                val tLeft = (0f - p1.x) / dx
                val yLeft = p1.y + tLeft * dy
                if (yLeft in 0f..h) pts.add(PointF(0f, yLeft))

                val tRight = (w - p1.x) / dx
                val yRight = p1.y + tRight * dy
                if (yRight in 0f..h) pts.add(PointF(w, yRight))
            }

            if (dy != 0f) {
                val tTop = (0f - p1.y) / dy
                val xTop = p1.x + tTop * dx
                if (xTop in 0f..w) pts.add(PointF(xTop, 0f))

                val tBottom = (h - p1.y) / dy
                val xBottom = p1.x + tBottom * dx
                if (xBottom in 0f..w) pts.add(PointF(xBottom, h))
            }

            val unique = pts.distinctBy { Pair(it.x.toInt(), it.y.toInt()) }
            if (unique.size >= 2) {
                canvas.drawLine(unique[0].x, unique[0].y, unique[1].x, unique[1].y, paint)
            } else if (unique.size == 1) {
                canvas.drawLine(p1.x, p1.y, unique[0].x, unique[0].y, paint)
            } else {
                canvas.drawLine(0f, p1.y, w, p1.y + (dy / dx) * w, paint)
            }
        }
    }
}
