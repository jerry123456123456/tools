package com.buluo.tribe

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout

/**
 * 开启穿透后，仅触摸到指定交互控件时才消费事件，其余区域交给下层 App。
 */
class TouchPassthroughFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    var passthroughEnabled: Boolean = false

    /** 标线模式下可点击的绘制层。 */
    var drawingTarget: DrawingOverlayView? = null

    var interactiveViews: List<View> = emptyList()

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (passthroughEnabled) return false
        return super.onTouchEvent(event)
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (!passthroughEnabled) return super.dispatchTouchEvent(event)
        if (!shouldHandleTouch(event)) return false
        return super.dispatchTouchEvent(event)
    }

    private fun shouldHandleTouch(event: MotionEvent): Boolean {
        val x = event.rawX
        val y = event.rawY
        val draw = drawingTarget
        if (draw != null && draw.visibility == VISIBLE && draw.interactionEnabled && hit(draw, x, y)) {
            return true
        }
        for (view in interactiveViews) {
            if (view.visibility != VISIBLE) continue
            if (hitInteractiveTree(view, x, y)) return true
        }
        return false
    }

    private fun hitInteractiveTree(view: View, rawX: Float, rawY: Float): Boolean {
        if (view.visibility != VISIBLE || view === drawingTarget) return false
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                if (hitInteractiveTree(view.getChildAt(i), rawX, rawY)) return true
            }
            return false
        }
        return hit(view, rawX, rawY)
    }

    private fun hit(view: View, rawX: Float, rawY: Float): Boolean {
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        return rawX >= loc[0] && rawX < loc[0] + view.width &&
            rawY >= loc[1] && rawY < loc[1] + view.height
    }
}
