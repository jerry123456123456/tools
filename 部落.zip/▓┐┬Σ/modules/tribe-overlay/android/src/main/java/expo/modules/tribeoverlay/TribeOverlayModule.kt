package expo.modules.tribeoverlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.buluo.tribe.OverlayService
import expo.modules.kotlin.exception.CodedException
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class TribeOverlayModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("TribeOverlay")

    AsyncFunction("startOverlay") {
      val context = appContext.reactContext
        ?: throw CodedException("E_NO_CONTEXT", "React context unavailable", null)

      if (!Settings.canDrawOverlays(context)) {
        val intent = Intent(
          Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
          Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        throw CodedException("NO_PERMISSION", "需要悬浮窗权限", null)
      }

      val serviceIntent = Intent(context, OverlayService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(serviceIntent)
      } else {
        context.startService(serviceIntent)
      }
      // startForegroundService 返回 ComponentName，不能传回 JS 层
      null
    }

    AsyncFunction("isOverlayRunning") {
      OverlayService.isRunning
    }
  }
}
