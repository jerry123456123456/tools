package com.buluo.tribe

import expo.modules.tribeoverlay.R
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.util.TypedValue
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * 全程一个主悬浮窗；确认保留红线后：
 * - 红线：全屏 + FLAG_NOT_TOUCHABLE（系统级触摸穿透）
 * - 「部」「删除」：两个 WRAP_CONTENT 小窗，不挡屏幕其余区域
 */
class OverlayService : Service() {

    private enum class OverlayPhase {
        NORMAL,
        EDITING,
        PERSISTED
    }

    private lateinit var windowManager: WindowManager

    private var overlayRoot: FrameLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    private var floatChipRoot: FrameLayout? = null
    private var floatChipParams: WindowManager.LayoutParams? = null
    private var deleteChipRoot: FrameLayout? = null
    private var deleteChipParams: WindowManager.LayoutParams? = null

    private var menuRow: LinearLayout? = null
    private var mainFloatView: TextView? = null
    private var drawingView: DrawingOverlayView? = null
    private var topActionBar: View? = null
    private var persistedDeleteBtn: TextView? = null

    private var mainSizeCm = DisplayUtil.DEFAULT_FLOAT_CM
    private var menuExpanded = false
    private var phase = OverlayPhase.NORMAL
    private var floatPosX = 0
    private var floatPosY = 0

    private var dragStartX = 0
    private var dragStartY = 0
    private var paramStartX = 0
    private var paramStartY = 0
    private var isDragging = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(NOTIFICATION_ID, buildNotification())
        showUnifiedOverlay()
    }

    override fun onDestroy() {
        isRunning = false
        removeOverlay()
        super.onDestroy()
    }

    private fun overlayLayoutParams(
        width: Int,
        height: Int,
        x: Int = 0,
        y: Int = 0,
        gravity: Int = Gravity.TOP or Gravity.START,
        touchable: Boolean = true
    ): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        return WindowManager.LayoutParams(
            width,
            height,
            type,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            this.x = x
            this.y = y
        }
    }

    private fun showUnifiedOverlay() {
        if (overlayRoot != null) return

        val sizePx = DisplayUtil.cmToPx(this, mainSizeCm)
        val (screenW, screenH) = DisplayUtil.screenSize(this)
        floatPosX = screenW / 2 - sizePx / 2
        floatPosY = screenH / 3

        val root = LayoutInflater.from(this).inflate(R.layout.overlay_unified, null) as FrameLayout
        val row = root.findViewById<LinearLayout>(R.id.menuRow)
        val drawView = root.findViewById<DrawingOverlayView>(R.id.drawingView)
        val actionBar = root.findViewById<View>(R.id.topActionBar)
        val cancelBtn = root.findViewById<TextView>(R.id.cancelButton)
        val confirmBtn = root.findViewById<TextView>(R.id.confirmButton)

        val main = createCircleLabel("部", R.drawable.bg_float_circle, sizePx)
        row.addView(main)

        cancelBtn.setOnClickListener { cancelEditing() }
        confirmBtn.setOnClickListener { confirmDrawing() }

        val params = overlayLayoutParams(
            width = WindowManager.LayoutParams.WRAP_CONTENT,
            height = WindowManager.LayoutParams.WRAP_CONTENT,
            x = floatPosX,
            y = floatPosY
        )

        attachMainFloatTouchHandlers(params, main)
        windowManager.addView(root, params)

        overlayRoot = root
        overlayParams = params
        menuRow = row
        mainFloatView = main
        drawingView = drawView
        topActionBar = actionBar
        applyNormalLayout()
    }

    private fun showPersistedControls() {
        if (floatChipRoot != null) return
        val main = mainFloatView ?: return
        val overlay = overlayRoot ?: return

        (main.parent as? ViewGroup)?.removeView(main)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(main)

        val floatRoot = FrameLayout(this)
        floatRoot.addView(row)
        val floatParams = overlayLayoutParams(
            width = WindowManager.LayoutParams.WRAP_CONTENT,
            height = WindowManager.LayoutParams.WRAP_CONTENT,
            x = floatPosX,
            y = floatPosY
        )
        attachMainFloatTouchHandlers(floatParams, main)
        windowManager.addView(floatRoot, floatParams)

        val margin = DisplayUtil.dpToPx(this, 16f).roundToInt()
        val deleteBtn = LayoutInflater.from(this).inflate(R.layout.overlay_delete_chip, null) as TextView
        deleteBtn.setOnClickListener { deletePersistedDrawing() }
        val deleteRoot = FrameLayout(this)
        deleteRoot.addView(
            deleteBtn,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = margin
                marginEnd = margin
            }
        )
        val deleteParams = overlayLayoutParams(
            width = WindowManager.LayoutParams.WRAP_CONTENT,
            height = WindowManager.LayoutParams.WRAP_CONTENT,
            gravity = Gravity.TOP or Gravity.END
        )
        windowManager.addView(deleteRoot, deleteParams)

        floatChipRoot = floatRoot
        floatChipParams = floatParams
        deleteChipRoot = deleteRoot
        deleteChipParams = deleteParams
        menuRow = row
        persistedDeleteBtn = deleteBtn
    }

    private fun removePersistedControls() {
        val main = mainFloatView ?: return
        val overlay = overlayRoot ?: return

        floatChipRoot?.let { runCatching { windowManager.removeView(it) } }
        deleteChipRoot?.let { runCatching { windowManager.removeView(it) } }
        floatChipRoot = null
        floatChipParams = null
        deleteChipRoot = null
        deleteChipParams = null
        persistedDeleteBtn = null

        if (main.parent != null) {
            (main.parent as? ViewGroup)?.removeView(main)
        }
        val homeRow = overlay.findViewById<LinearLayout>(R.id.menuRow)
        homeRow.addView(main)
        menuRow = homeRow
        overlayParams?.let { attachMainFloatTouchHandlers(it, main) }
    }

    private fun createCircleLabel(text: String, bgRes: Int, sizePx: Int): TextView {
        val textPx = when {
            text.length <= 2 -> sizePx * 0.36f
            text.length <= 4 -> sizePx * 0.22f
            else -> sizePx * 0.16f
        }
        return TextView(this).apply {
            this.text = text
            setTextColor(getColor(R.color.white))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, textPx)
            gravity = Gravity.CENTER
            setBackgroundResource(bgRes)
            layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                val gap = (sizePx * 0.12f).roundToInt()
                marginEnd = gap
            }
        }
    }

    private fun attachMainFloatTouchHandlers(params: WindowManager.LayoutParams, main: TextView) {
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (phase != OverlayPhase.NORMAL) return false
                mainSizeCm = (mainSizeCm * detector.scaleFactor)
                    .coerceIn(DisplayUtil.MIN_FLOAT_CM, DisplayUtil.MAX_FLOAT_CM)
                applyMainSize()
                return true
            }
        })

        main.setOnTouchListener { _, event ->
            if (phase == OverlayPhase.EDITING) return@setOnTouchListener false
            scaleDetector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = event.rawX.roundToInt()
                    dragStartY = event.rawY.roundToInt()
                    paramStartX = floatPosX
                    paramStartY = floatPosY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (scaleDetector.isInProgress) return@setOnTouchListener true
                    val dx = event.rawX.roundToInt() - dragStartX
                    val dy = event.rawY.roundToInt() - dragStartY
                    if (abs(dx) > 8 || abs(dy) > 8) {
                        isDragging = true
                        val (screenW, screenH) = DisplayUtil.screenSize(this)
                        val panelW = floatChipRoot?.width ?: overlayRoot?.width ?: main.width
                        val panelH = floatChipRoot?.height ?: overlayRoot?.height ?: main.height
                        floatPosX = (paramStartX + dx).coerceIn(0, (screenW - panelW).coerceAtLeast(0))
                        floatPosY = (paramStartY + dy).coerceIn(0, (screenH - panelH).coerceAtLeast(0))
                        params.x = floatPosX
                        params.y = floatPosY
                        val host = floatChipRoot ?: overlayRoot
                        host?.let { windowManager.updateViewLayout(it, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) onMainFloatClick()
                    true
                }
                else -> false
            }
        }
    }

    private fun onMainFloatClick() {
        when (phase) {
            OverlayPhase.EDITING -> {
                Toast.makeText(this, "请先点击右上角取消", Toast.LENGTH_SHORT).show()
            }
            OverlayPhase.PERSISTED -> {
                Toast.makeText(this, "请先点击右上角删除", Toast.LENGTH_SHORT).show()
            }
            OverlayPhase.NORMAL -> {
                if (menuExpanded) collapseMenu() else expandMenu()
            }
        }
    }

    private fun expandMenu() {
        val row = menuRow ?: return
        collapseMenu()
        menuExpanded = true

        val labels = listOf(
            getString(R.string.mode_straight),
            getString(R.string.mode_center),
            getString(R.string.mode_close)
        )
        val backgrounds = listOf(
            R.drawable.bg_float_sub,
            R.drawable.bg_float_sub,
            R.drawable.bg_float_close
        )
        val actions: List<() -> Unit> = listOf(
            { enterDrawMode(OverlayDrawMode.STRAIGHT) },
            { enterDrawMode(OverlayDrawMode.CENTER) },
            { stopSelf() }
        )

        val subSize = (DisplayUtil.cmToPx(this, mainSizeCm) * DisplayUtil.SUB_ICON_SCALE).roundToInt()

        labels.forEachIndexed { index, label ->
            val view = createCircleLabel(label, backgrounds[index], subSize)
            view.setOnClickListener {
                collapseMenu()
                actions[index]()
            }
            row.addView(view, index)
        }
        refreshFloatPanelSize()
    }

    private fun collapseMenu() {
        menuExpanded = false
        val row = menuRow ?: return
        while (row.childCount > 1) {
            row.removeViewAt(0)
        }
        refreshFloatPanelSize()
    }

    private fun refreshFloatPanelSize() {
        if (phase != OverlayPhase.NORMAL) return
        val root = overlayRoot ?: return
        val params = overlayParams ?: return
        root.requestLayout()
        val specW = View.MeasureSpec.makeMeasureSpec(DisplayUtil.screenSize(this).first, View.MeasureSpec.AT_MOST)
        val specH = View.MeasureSpec.makeMeasureSpec(DisplayUtil.screenSize(this).second, View.MeasureSpec.AT_MOST)
        root.measure(specW, specH)
        params.width = root.measuredWidth
        params.height = root.measuredHeight
        params.x = floatPosX
        params.y = floatPosY
        windowManager.updateViewLayout(root, params)
    }

    private fun applyMainSize() {
        val sizePx = DisplayUtil.cmToPx(this, mainSizeCm)
        mainFloatView?.let { view ->
            view.layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                val gap = (sizePx * 0.12f).roundToInt()
                marginEnd = gap
            }
            view.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx * 0.36f)
            if (menuExpanded) {
                collapseMenu()
                expandMenu()
            } else {
                refreshFloatPanelSize()
            }
        }
    }

    private fun applyNormalLayout() {
        phase = OverlayPhase.NORMAL
        removePersistedControls()

        val root = overlayRoot ?: return
        val params = overlayParams ?: return

        drawingView?.visibility = View.GONE
        drawingView?.interactionEnabled = true
        topActionBar?.visibility = View.GONE
        menuRow?.visibility = View.VISIBLE

        params.width = WindowManager.LayoutParams.WRAP_CONTENT
        params.height = WindowManager.LayoutParams.WRAP_CONTENT
        params.x = floatPosX
        params.y = floatPosY
        params.flags = overlayLayoutParams(
            params.width,
            params.height,
            x = floatPosX,
            y = floatPosY,
            touchable = true
        ).flags
        windowManager.updateViewLayout(root, params)
        refreshFloatPanelSize()
    }

    private fun applyEditingLayout(mode: OverlayDrawMode) {
        phase = OverlayPhase.EDITING
        removePersistedControls()

        val root = overlayRoot ?: return
        val params = overlayParams ?: return
        val (screenW, screenH) = DisplayUtil.screenSize(this)

        floatPosX = params.x
        floatPosY = params.y

        drawingView?.apply {
            visibility = View.VISIBLE
            drawMode = mode
            interactionEnabled = true
            reset()
        }
        topActionBar?.visibility = View.VISIBLE
        menuRow?.visibility = View.GONE

        params.width = screenW
        params.height = screenH
        params.x = 0
        params.y = 0
        params.flags = overlayLayoutParams(screenW, screenH, touchable = true).flags
        windowManager.updateViewLayout(root, params)
    }

    private fun applyPersistedLayout() {
        phase = OverlayPhase.PERSISTED
        val root = overlayRoot ?: return
        val params = overlayParams ?: return
        val (screenW, screenH) = DisplayUtil.screenSize(this)

        drawingView?.apply {
            visibility = View.VISIBLE
            interactionEnabled = false
            isClickable = false
        }
        topActionBar?.visibility = View.GONE
        menuRow?.visibility = View.GONE

        params.width = screenW
        params.height = screenH
        params.x = 0
        params.y = 0
        params.flags = overlayLayoutParams(screenW, screenH, touchable = false).flags
        windowManager.updateViewLayout(root, params)

        showPersistedControls()
    }

    private fun enterDrawMode(mode: OverlayDrawMode) {
        if (phase == OverlayPhase.PERSISTED) {
            Toast.makeText(this, "请先点击右上角删除", Toast.LENGTH_SHORT).show()
            return
        }
        collapseMenu()
        applyEditingLayout(mode)
    }

    private fun cancelEditing() {
        drawingView?.drawMode = OverlayDrawMode.NONE
        drawingView?.reset()
        applyNormalLayout()
        collapseMenu()
    }

    private fun confirmDrawing() {
        if (phase != OverlayPhase.EDITING) return
        applyPersistedLayout()
        collapseMenu()
    }

    private fun deletePersistedDrawing() {
        drawingView?.drawMode = OverlayDrawMode.NONE
        drawingView?.reset()
        applyNormalLayout()
        collapseMenu()
    }

    private fun removeOverlay() {
        collapseMenu()
        removePersistedControls()
        overlayRoot?.let { runCatching { windowManager.removeView(it) } }
        overlayRoot = null
        overlayParams = null
        menuRow = null
        mainFloatView = null
        drawingView = null
        topActionBar = null
        persistedDeleteBtn = null
        phase = OverlayPhase.NORMAL
    }

    private fun buildNotification(): Notification {
        val channelId = "tribe_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            ?: Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                setPackage(packageName)
            }
        val openIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
        @Volatile
        var isRunning: Boolean = false
    }
}
