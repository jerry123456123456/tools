import { registerWebModule, NativeModule } from 'expo';

class TribeOverlayModule extends NativeModule<{}> {}

export default registerWebModule(TribeOverlayModule, 'TribeOverlayModule');
