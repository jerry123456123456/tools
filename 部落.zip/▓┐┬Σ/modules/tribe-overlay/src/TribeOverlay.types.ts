export type TribeOverlayModuleEvents = Record<string, never>;

export interface TribeOverlayNativeModule {
  startOverlay(): Promise<void>;
  isOverlayRunning(): Promise<boolean>;
}
