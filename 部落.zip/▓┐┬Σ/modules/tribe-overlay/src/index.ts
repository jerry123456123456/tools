export { default } from './TribeOverlayModule';
export type { TribeOverlayModuleEvents } from './TribeOverlay.types';
