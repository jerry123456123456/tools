import { NativeModule, requireNativeModule } from 'expo';
import type { TribeOverlayNativeModule } from './TribeOverlay.types';

declare class TribeOverlayModule extends NativeModule<TribeOverlayNativeModule> {}

export default requireNativeModule<TribeOverlayModule>('TribeOverlay');
