# 部落 — 悬浮标线工具（Expo + 原生悬浮窗）

在其他 App（如 B 站）上层显示可拖动浮标，支持「直线」「中心对称」标线。

## 重要：不能用 Expo Go

本 App 含**原生悬浮窗模块**，必须用 EAS 打包的 APK 安装，**不要**用 Expo Go 扫码打开，否则会提示「原生模块未加载」。

## Expo 云端打包 + 终端二维码（推荐）

### 一次性准备

```powershell
cd C:\Users\jerry\Desktop\部落
npm install
npm install -g eas-cli
eas login
eas init
```

`eas init` 会关联你的 Expo 账号（与 expo.dev 上 Builds 页面相同）。

### 云端打包命令（与截图一致）

```powershell
cd C:\Users\jerry\Desktop\部落
npx eas-cli build --platform android --profile preview
```

或：

```powershell
npm run build:preview
```

构建结束后，**终端会显示安装链接和二维码**，手机扫码即可安装（Android internal distribution）。

---

## 功能说明

| 操作 | 行为 |
|------|------|
| 打开 App → 启动浮标 | 出现红色圆形主浮标 |
| 双指捏合主浮标 | 缩放（约 0.6～2.5cm） |
| 单击主浮标 | 展开：直线、中心对称、关闭 |
| 直线 | 全屏透明层；点 2 次画无限红线；第 3 次清空 |
| 中心对称 | 点 3 次；显示中点；画无限红线；第 4 次清空 |
| 右上角取消 | 退出标线、恢复操作 |
| 关闭 | 停止服务 |

---

## 本地运行（需 Android Studio）

```powershell
cd C:\Users\jerry\Desktop\部落
npx expo run:android
```

---

## 项目结构

```
├── App.js                 # React Native 启动页
├── app.json / eas.json    # Expo 配置
├── plugins/               # 注入悬浮窗 Service 权限
├── android/               # 原生工程（含 OverlayService 等）
└── app/src/main/...       # 原生源码备份目录（构建用 android/）
```

包名：`com.buluo.tribe`
