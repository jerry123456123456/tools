# 本地/云端构建后：上传蒲公英并在终端打印安装二维码
# 用法见 README「发布与二维码」

param(
    [ValidateSet("debug", "release")]
    [string]$Variant = "debug",
    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"
$Root = Split-Path $PSScriptRoot -Parent
Set-Location $Root

function Find-JavaHome {
    $candidates = @(
        $env:JAVA_HOME,
        "$env:ProgramFiles\Android\Android Studio\jbr",
        "$env:LOCALAPPDATA\Programs\Android\Android Studio\jbr",
        "${env:ProgramFiles(x86)}\Android\Android Studio\jbr"
    ) | Where-Object { $_ -and (Test-Path "$_\bin\java.exe") }
    return $candidates | Select-Object -First 1
}

function Find-AndroidSdk {
    if ($env:ANDROID_HOME -and (Test-Path $env:ANDROID_HOME)) { return $env:ANDROID_HOME }
    if ($env:ANDROID_SDK_ROOT -and (Test-Path $env:ANDROID_SDK_ROOT)) { return $env:ANDROID_SDK_ROOT }
    $default = "$env:LOCALAPPDATA\Android\Sdk"
    if (Test-Path $default) { return $default }
    return $null
}

$javaHome = Find-JavaHome
if (-not $javaHome) {
    Write-Error "未找到 Java。请安装 Android Studio，或设置 JAVA_HOME 指向 JDK 17。"
}
$env:JAVA_HOME = $javaHome

$sdk = Find-AndroidSdk
if (-not $sdk) {
    Write-Error "未找到 Android SDK。请安装 Android Studio 并至少完成一次 SDK 同步。"
}
if (-not (Test-Path "$Root\local.properties")) {
    "sdk.dir=$($sdk -replace '\\','\\')" | Set-Content -Path "$Root\local.properties" -Encoding UTF8
}

$apkName = if ($Variant -eq "release") { "app-release-unsigned.apk" } else { "app-debug.apk" }
$apkPath = Join-Path $Root "app\build\outputs\apk\$Variant\$apkName"

if (-not $SkipBuild) {
    Write-Host ">> 正在编译 $Variant APK ..."
    & "$Root\gradlew.bat" "assemble$(($Variant.Substring(0,1).ToUpper() + $Variant.Substring(1)))" --no-daemon
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

if (-not (Test-Path $apkPath)) {
    Write-Error "找不到 APK: $apkPath"
}

if (-not $env:PGYER_API_KEY) {
    Write-Error "请先设置蒲公英 API Key：`n  `$env:PGYER_API_KEY='你的Key'`n获取：https://www.pgyer.com/account/api"
}

Write-Host ">> 上传到蒲公英 ..."
$uploadJson = npx --yes @pgyer/cli@latest upload $apkPath --json 2>&1 | Out-String
Write-Host $uploadJson
$installUrl = $null
try {
    $obj = $uploadJson | ConvertFrom-Json
    $shortcut = $obj.data.buildShortcutUrl
    if ($shortcut) {
        $installUrl = if ($shortcut -match '^https?://') { $shortcut } else { "https://www.pgyer.com/$shortcut" }
    }
    if (-not $installUrl) { $installUrl = $obj.data.buildQRCodeURL }
} catch {
    if ($uploadJson -match 'https?://[^\s"]+pgyer[^\s"]+') {
        $installUrl = $Matches[0]
    }
}

if ($installUrl) {
    Write-Host "安装链接: $installUrl`n"
    npx --yes qrcode-terminal@latest $installUrl
} else {
    Write-Warning "未能自动解析链接；请使用上方蒲公英页面二维码安装。"
}
