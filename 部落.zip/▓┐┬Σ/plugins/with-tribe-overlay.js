const { withAndroidManifest, AndroidConfig } = require('expo/config-plugins');

const PERMISSIONS = [
  'android.permission.FOREGROUND_SERVICE',
  'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',
  'android.permission.POST_NOTIFICATIONS',
];

function ensurePermission(manifest, name) {
  if (!manifest['uses-permission']) {
    manifest['uses-permission'] = [];
  }
  const list = Array.isArray(manifest['uses-permission'])
    ? manifest['uses-permission']
    : [manifest['uses-permission']];
  const exists = list.some((p) => p.$?.['android:name'] === name);
  if (!exists) {
    list.push({ $: { 'android:name': name } });
  }
  manifest['uses-permission'] = list;
}

function withTribeOverlay(config) {
  return withAndroidManifest(config, (cfg) => {
    const manifest = cfg.modResults.manifest;
    PERMISSIONS.forEach((name) => ensurePermission(manifest, name));

    const app = AndroidConfig.Manifest.getMainApplicationOrThrow(cfg.modResults);
    if (!app.service) {
      app.service = [];
    }
    const serviceName = 'com.buluo.tribe.OverlayService';
    const services = Array.isArray(app.service) ? app.service : [app.service];
    const exists = services.some((s) => s.$?.['android:name'] === serviceName);
    if (!exists) {
      services.push({
        $: {
          'android:name': serviceName,
          'android:exported': 'false',
          'android:foregroundServiceType': 'specialUse',
        },
        property: [
          {
            $: {
              'android:name': 'android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE',
              'android:value': 'screen_overlay_drawing',
            },
          },
        ],
      });
      app.service = services;
    }

    return cfg;
  });
}

module.exports = withTribeOverlay;
