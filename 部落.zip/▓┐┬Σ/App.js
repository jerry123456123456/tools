import { useState } from 'react';
import {
  Alert,
  Button,
  Linking,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Constants from 'expo-constants';
import TribeOverlay from './modules/tribe-overlay/src/TribeOverlayModule';

export default function App() {
  const [running, setRunning] = useState(false);

  const startOverlay = async () => {
    if (Constants.appOwnership === 'expo') {
      Alert.alert(
        '请安装正式版 APK',
        '此 App 含原生悬浮窗，不能用 Expo Go 打开。\n\n请用 EAS 云端打包后扫码安装：\neas build -p android --profile preview'
      );
      return;
    }

    try {
      await TribeOverlay.startOverlay();
      setRunning(true);
      Alert.alert('已启动', '浮标已启动，可切换到 B 站等 App 使用');
    } catch (e) {
      const msg = e?.message ?? String(e);
      // 浮标已起来但桥接误报 ComponentName 时视为成功
      try {
        const already = await TribeOverlay.isOverlayRunning();
        if (already) {
          setRunning(true);
          return;
        }
      } catch (_) {
        /* ignore */
      }
      const code = e?.code ?? e?.cause?.code;
      if (code === 'NO_PERMISSION') {
        Alert.alert(
          '需要悬浮窗权限',
          '请在设置中允许「部落」显示在其他应用上层',
          [
            { text: '去设置', onPress: () => Linking.openSettings() },
            { text: '取消', style: 'cancel' },
          ]
        );
      } else {
        Alert.alert('启动失败', msg);
      }
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>部落</Text>
      <Text style={styles.hint}>
        启动后会出现可拖动的浮标，支持直线与中心对称标线。{'\n'}
        需授予「显示在其他应用上层」权限。
      </Text>
      <Button title="启动浮标" onPress={startOverlay} />
      {running ? (
        <Text style={styles.status}>浮标运行中（点浮标「关闭」可完全退出）</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  hint: {
    fontSize: 14,
    color: '#444',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 22,
  },
  status: {
    marginTop: 16,
    fontSize: 13,
    color: '#2e7d32',
  },
});
